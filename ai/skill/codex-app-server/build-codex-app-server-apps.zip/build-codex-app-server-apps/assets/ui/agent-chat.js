'use strict';

(function () {
  const state = { conversations: new Map(), selected: null, capabilities: { models: [] }, turnThreads: new Map() };
  const tabs = document.getElementById('tabs');
  const messages = document.getElementById('messages');
  const send = document.getElementById('send');
  const usage = document.getElementById('usage');
  const model = document.getElementById('model');
  const effort = document.getElementById('effort');
  const speedWrap = document.getElementById('speed-wrap');
  const speed = document.getElementById('speed');
  const prompt = document.getElementById('prompt');
  const account = document.getElementById('account');
  const quota = document.getElementById('quota');
  const workspace = document.getElementById('workspace');
  const attach = document.getElementById('attach');
  const steer = document.getElementById('steer');
  const threadAction = document.getElementById('thread-action');
  const threadActionRun = document.getElementById('thread-action-run');

  function conversation(id, patch) {
    if (!state.conversations.has(id)) state.conversations.set(id, {
      id,
      name: '新对话',
      status: 'idle',
      activeTurnId: null,
      items: new Map(),
      order: [],
      usage: 0,
      scrollTop: 0,
      followBottom: true,
      renderVersion: 0,
      draft: '',
      attachments: [],
      settings: { model: null, effort: null, speed: null }
    });
    const value = state.conversations.get(id);
    if (patch) Object.assign(value, patch);
    if (value.activeTurnId) state.turnThreads.set(String(value.activeTurnId), id);
    if (!state.selected) state.selected = id;
    return value;
  }

  function bindTurn(threadId, turnId) {
    if (!threadId || !turnId) return false;
    conversation(String(threadId));
    state.turnThreads.set(String(turnId), String(threadId));
    return true;
  }

  function selectConversation(id) {
    // 宿主可先注入/恢复当前对话再选择同一 id；此时不能用尚未渲染的旧控件值覆盖恢复配置。
    if (state.selected !== id) rememberSelectedState();
    state.selected = id;
    const current = state.conversations.get(id);
    prompt.value = current ? current.draft || '' : '';
    const restoreBottom = !!(current && current.followBottom);
    const restoreTop = current ? current.scrollTop : 0;
    renderAll(false);
    requestAnimationFrame(() => { messages.scrollTop = current ? (restoreBottom ? messages.scrollHeight : restoreTop) : 0; });
  }

  function rememberSelectedState() {
    const current = state.conversations.get(state.selected);
    if (!current) return;
    current.scrollTop = messages.scrollTop;
    current.followBottom = nearBottom(messages);
    current.draft = prompt.value;
    current.settings.model = model.value || current.settings.model;
    current.settings.effort = effort.value || current.settings.effort;
    current.settings.speed = speed.value || 'standard';
  }

  function applyEvent(message) {
    const params = message.params || {};
    const turnId = params.turnId || (params.turn && params.turn.id) || (params.item && params.item.turnId);
    const threadId = params.threadId || (params.thread && params.thread.id) || (turnId && state.turnThreads.get(String(turnId)));
    if (!threadId) return;
    if (turnId) state.turnThreads.set(String(turnId), String(threadId));
    const item = params.item;
    const current = conversation(threadId);
    const followsBottom = state.selected === threadId && current.followBottom;

    if (message.method === 'turn/started') {
      current.status = 'generating';
      current.activeTurnId = params.turn && params.turn.id;
    } else if (message.method === 'turn/completed') {
      const status = params.turn && params.turn.status;
      current.status = status === 'failed' ? 'failed' : (status === 'interrupted' ? 'interrupted' : 'idle');
      current.activeTurnId = null;
      const completedTurnId = params.turn && params.turn.id;
      if (status === 'failed' || status === 'interrupted') {
        for (const target of current.items.values()) {
          if (target.turnId === completedTurnId && (target.status === 'inProgress' || target.status === 'waitingForApproval')) target.status = status;
        }
      }
      for (const prefix of ['turn-plan:', 'turn-diff:']) {
        const target = current.items.get(prefix + String(params.turn && params.turn.id || ''));
        if (target) target.status = status === 'failed' ? 'failed' : (status === 'interrupted' ? 'interrupted' : 'completed');
      }
    } else if (message.method === 'item/started' && item && item.type !== 'hookPrompt') {
      upsertItem(current, item, false, params.turnId);
    } else if (message.method === 'item/completed' && item && item.type !== 'hookPrompt') {
      upsertItem(current, item, true, params.turnId);
    } else if (message.method === 'item/reasoning/summaryTextDelta') {
      const target = ensureItem(current, params.itemId, 'reasoning');
      target.turnId = params.turnId || target.turnId;
      const index = Number.isInteger(params.summaryIndex) ? params.summaryIndex : target.steps.length;
      while (target.steps.length <= index) target.steps.push('');
      target.steps[index] += params.delta || '';
    } else if (message.method === 'item/reasoning/summaryPartAdded') {
      const target = ensureItem(current, params.itemId, 'reasoning');
      target.turnId = params.turnId || target.turnId;
      const index = Number.isInteger(params.summaryIndex) ? params.summaryIndex : target.steps.length;
      while (target.steps.length <= index) target.steps.push('');
    } else if (message.method === 'item/agentMessage/delta') {
      const target = ensureItem(current, params.itemId, 'agentMessage');
      target.turnId = params.turnId || target.turnId;
      target.text = (target.text || '') + (params.delta || '');
    } else if (message.method === 'item/plan/delta') {
      const target = ensureItem(current, params.itemId, 'plan');
      target.turnId = params.turnId || target.turnId;
      target.text = (target.text || '') + (params.delta || '');
    } else if (message.method === 'turn/plan/updated') {
      const target = ensureItem(current, 'turn-plan:' + String(params.turnId || ''), 'plan');
      target.explanation = params.explanation || '';
      target.turnId = params.turnId || target.turnId;
      target.plan = Array.isArray(params.plan) ? params.plan.slice() : [];
      target.status = 'inProgress';
    } else if (message.method === 'turn/diff/updated') {
      const target = ensureItem(current, 'turn-diff:' + String(params.turnId || ''), 'diff');
      target.diff = params.diff || '';
      target.turnId = params.turnId || target.turnId;
      target.status = 'inProgress';
    } else if (message.method === 'item/commandExecution/outputDelta') {
      const target = ensureItem(current, params.itemId, 'commandExecution');
      target.turnId = params.turnId || target.turnId;
      target.aggregatedOutput = (target.aggregatedOutput || '') + (params.delta || '');
    } else if (message.method === 'item/fileChange/patchUpdated') {
      const target = ensureItem(current, params.itemId, 'fileChange');
      target.turnId = params.turnId || target.turnId;
      target.patch = params.patch || params.diff || '';
    } else if (message.method === 'item/mcpToolCall/progress') {
      const target = ensureItem(current, params.itemId, 'mcpToolCall');
      target.turnId = params.turnId || target.turnId;
      target.resultSummary = params.message || params.progress || '';
    } else if (message.method === 'serverRequest/resolved') {
      const target = current.items.get('server-request:' + String(params.requestId));
      if (target && (target.status === 'waitingForApproval' || target.status === 'inProgress')) target.status = 'completed';
    } else if (message.method === 'model/rerouted') {
      const target = ensureItem(current, 'model-rerouted:' + String(params.turnId || current.order.length), 'warning');
      target.status = 'completed';
      target.turnId = params.turnId || target.turnId;
      target.message = '模型已从 ' + String(params.fromModel || '原模型') + ' 调整为 ' + String(params.toModel || '其它模型') + (params.reason ? '：' + params.reason : '');
    } else if (message.method === 'model/safetyBuffering/updated') {
      const target = ensureItem(current, 'model-buffering:' + String(params.turnId || ''), 'warning');
      target.status = params.showBufferingUi === false ? 'completed' : 'inProgress';
      target.turnId = params.turnId || target.turnId;
      target.message = params.showBufferingUi === false ? '模型安全缓冲已结束' : '模型正在进行安全缓冲';
    } else if (message.method === 'model/verification') {
      const target = ensureItem(current, 'model-verification:' + String(params.turnId || ''), 'warning');
      target.status = 'waitingForApproval';
      target.turnId = params.turnId || target.turnId;
      target.message = '当前模型请求需要额外账号验证';
    } else if (message.method === 'warning') {
      const target = ensureItem(current, 'warning:' + String(params.turnId || current.order.length), 'warning');
      target.status = 'completed';
      target.turnId = params.turnId || target.turnId;
      target.message = params.message || 'Codex 返回警告';
    } else if (message.method === 'thread/status/changed') {
      const status = params.status || {};
      current.status = status.type === 'active' ? 'generating' : (status.type === 'systemError' ? 'failed' : 'idle');
      if (status.type !== 'active') current.activeTurnId = null;
    } else if (message.method === 'thread/closed') {
      current.status = 'idle';
      current.activeTurnId = null;
    } else if (message.method === 'error') {
      const target = ensureItem(current, 'turn-error:' + String(params.turnId || ''), 'error');
      target.status = 'failed';
      target.turnId = params.turnId || target.turnId;
      target.message = params.error && params.error.message || 'Codex 回合失败';
      target.willRetry = !!params.willRetry;
    } else if (message.method === 'thread/tokenUsage/updated') {
      const total = params.tokenUsage && params.tokenUsage.total;
      const nextUsage = Number(total && (total.totalTokens ?? total.total_tokens));
      if (Number.isFinite(nextUsage) && nextUsage >= 0) current.usage = nextUsage;
    }

    renderTabs();
    if (state.selected === threadId) renderConversation(current, followsBottom);
  }

  function applyServerRequest(message) {
    const params = message.params || {};
    const threadId = params.threadId;
    if (!threadId || message.id === undefined || !message.method) return;
    const current = conversation(threadId);
    const id = 'server-request:' + String(message.id);
    const type = serverRequestCardType(message.method);
    if (params.turnId) state.turnThreads.set(String(params.turnId), String(threadId));
    const target = ensureItem(current, id, type);
    Object.assign(target, {
      requestId: message.id,
      method: message.method,
      status: type === 'serverRequest' ? 'inProgress' : 'waitingForApproval',
      turnId: params.turnId,
      command: params.command,
      cwd: params.cwd,
      reason: params.reason,
      grantRoot: params.grantRoot,
      networkApprovalContext: params.networkApprovalContext,
      permissions: params.permissions || params.requestedPermissions,
      questions: Array.isArray(params.questions) ? params.questions.map(question => ({ id: question.id, header: question.header, question: question.question, isOther: !!question.isOther, isSecret: !!question.isSecret, options: Array.isArray(question.options) ? question.options.map(option => ({ label: option.label, description: option.description })) : null })) : [],
      serverName: params.serverName,
      mode: params.mode,
      message: params.message,
      url: params.url,
      availableDecisions: Array.isArray(params.availableDecisions) ? params.availableDecisions.slice() : defaultApprovalDecisions(message.method)
    });
    renderTabs();
    if (state.selected === threadId) renderConversation(current, nearBottom(messages));
  }

  function resolveServerRequest(threadId, requestId, decision) {
    const current = state.conversations.get(threadId);
    const item = current && current.items.get('server-request:' + String(requestId));
    if (!item) return;
    item.status = decision === 'decline' ? 'declined' : (decision === 'cancel' ? 'cancelled' : 'completed');
    item.decision = decision;
    renderTabs();
    if (state.selected === threadId) renderConversation(current, nearBottom(messages));
  }

  function serverRequestCardType(method) {
    if (method === 'item/tool/requestUserInput') return 'userInputRequest';
    if (method === 'mcpServer/elicitation/request') return 'elicitationRequest';
    if (method === 'item/permissions/requestApproval') return 'permissionRequest';
    if (method === 'item/commandExecution/requestApproval' || method === 'item/fileChange/requestApproval' || method === 'applyPatchApproval' || method === 'execCommandApproval') return 'approval';
    return 'serverRequest';
  }

  function defaultApprovalDecisions(method) {
    return serverRequestCardType(method) === 'approval' ? ['accept', 'acceptForSession', 'decline', 'cancel'] : [];
  }

  function ensureItem(current, id, type) {
    if (!current.items.has(id)) {
      current.items.set(id, { id, type, status: 'inProgress', steps: [] });
      current.order.push(id);
    }
    return current.items.get(id);
  }

  function upsertItem(current, item, completed, turnId) {
    const target = ensureItem(current, item.id, item.type);
    const oldSteps = target.steps;
    Object.assign(target, item);
    target.turnId = turnId || target.turnId;
    if (item.type === 'reasoning') target.steps = Array.isArray(item.summary) ? item.summary.slice() : oldSteps;
    if (completed && !target.status) target.status = 'completed';
  }

  function renderAll(followBottom) {
    renderTabs();
    renderConversation(state.conversations.get(state.selected), followBottom);
    renderCapabilities();
  }

  function renderTabs() {
    tabs.replaceChildren(...Array.from(state.conversations.values(), current => {
      const button = node('button', 'tab', current.name);
      button.type = 'button';
      button.setAttribute('aria-selected', String(current.id === state.selected));
      const dot = node('span', 'status ' + current.status, '');
      button.appendChild(dot);
      button.addEventListener('click', () => selectConversation(current.id));
      return button;
    }));
  }

  function renderConversation(current, followBottom) {
    if (!current) {
      messages.replaceChildren(node('div', 'empty', '创建或恢复一个 Codex 对话后，过程与最终回答会显示在这里。'));
      updateSendMode(null);
      return;
    }
    const remembered = messages.scrollTop;
    const shouldFollow = followBottom === true || current.followBottom;
    const renderVersion = ++current.renderVersion;
    const existing = new Map(Array.from(messages.children).filter(element => element.dataset && element.dataset.itemId).map(element => [element.dataset.itemId, element]));
    const fragment = document.createDocumentFragment();
    for (const id of current.order) fragment.appendChild(renderItem(current.items.get(id), existing.get(String(id))));
    if (!current.order.length) fragment.appendChild(node('div', 'empty', '输入目标开始对话。Codex 的思考步骤和工具调用会与最终回答分开显示。'));
    messages.replaceChildren(fragment);
    updateSendMode(current);
    usage.textContent = '当前对话 ' + Number(current.usage || 0).toLocaleString('zh-CN') + ' 词元';
    requestAnimationFrame(() => {
      if (state.selected !== current.id || current.renderVersion !== renderVersion) return;
      messages.scrollTop = shouldFollow ? messages.scrollHeight : remembered;
      current.followBottom = shouldFollow;
    });
  }

  function renderItem(item, existing) {
    if (existing && existing.dataset.itemType === item.type) return updateItem(existing, item);
    let root;
    if (item.type === 'userMessage') {
      root = node('article', 'message user-message', textOfUser(item));
    } else if (item.type === 'agentMessage') {
      root = node('article', item.phase === 'commentary' ? 'message commentary' : 'message answer', item.text || '');
    } else if (item.type === 'reasoning') {
      const details = node('details', 'message process', '');
      details.open = true;
      details.appendChild(node('summary', '', '🧠 Codex 过程'));
      const body = node('div', 'process-body', '');
      details.appendChild(body);
      root = details;
    } else {
      const card = node('article', 'message tool-card', '');
      const head = node('div', 'tool-head', '');
      head.appendChild(node('span', '', ''));
      head.appendChild(node('span', 'tool-status', ''));
      card.appendChild(head);
      const detail = document.createElement('details');
      detail.appendChild(node('summary', '', '查看详情'));
      detail.appendChild(node('pre', '', ''));
      card.appendChild(detail);
      root = card;
    }
    root.dataset.itemId = String(item.id);
    root.dataset.itemType = item.type;
    return updateItem(root, item);
  }

  function updateItem(root, item) {
    if (item.type === 'userMessage') {
      root.textContent = textOfUser(item);
      return root;
    }
    if (item.type === 'agentMessage') {
      root.className = item.phase === 'commentary' ? 'message commentary' : 'message answer';
      root.dataset.phase = item.phase || 'final_answer';
      root.textContent = item.text || '';
      return root;
    }
    if (item.type === 'reasoning') {
      const body = root.querySelector('.process-body');
      const steps = item.steps && item.steps.length ? item.steps : ['正在思考…'];
      body.replaceChildren(...steps.map(step => node('span', 'reason-step', step || '…')));
      return root;
    }
    const failed = item.status === 'failed' || item.status === 'declined';
    const interrupted = item.status === 'interrupted';
    root.className = 'message tool-card' + (failed ? ' failed' : '') + (interrupted ? ' interrupted' : '');
    const head = root.querySelector('.tool-head');
    head.children[0].textContent = toolTitle(item);
    head.children[1].textContent = statusLabel(item.status);
    root.querySelector('pre').textContent = toolDetail(item);
    const oldActions = root.querySelector('.approval-actions');
    if (oldActions) oldActions.remove();
    const oldMedia = root.querySelector('.generated-image');
    if (oldMedia) oldMedia.remove();
    if (item.type === 'approval' && item.status === 'waitingForApproval') root.appendChild(renderApprovalActions(item));
    if (item.type === 'userInputRequest' && item.status === 'waitingForApproval') root.appendChild(renderRequestAction(item, 'codex-user-input-request', '回答问题'));
    if (item.type === 'elicitationRequest' && item.status === 'waitingForApproval') root.appendChild(renderRequestAction(item, 'codex-elicitation-request', '处理请求'));
    if (item.type === 'permissionRequest' && item.status === 'waitingForApproval') root.appendChild(renderRequestAction(item, 'codex-permissions-request', '审阅权限'));
    if (item.type === 'imageGeneration') {
      const mediaUrl = sameOriginMediaUrl(item.mediaUrl);
      if (mediaUrl) root.appendChild(renderGeneratedImage(item, mediaUrl));
    }
    return root;
  }

  function renderApprovalActions(item) {
    const actions = node('div', 'approval-actions', '');
    for (const decision of item.availableDecisions || []) {
      const button = node('button', decision === 'accept' || decision === 'acceptForSession' ? 'primary' : 'secondary', decisionLabel(decision));
      button.type = 'button';
      button.addEventListener('click', () => window.dispatchEvent(new CustomEvent('codex-approval', { detail: { threadId: state.selected, requestId: item.requestId, decision } })));
      actions.appendChild(button);
    }
    return actions;
  }

  function renderRequestAction(item, eventName, label) {
    const actions = node('div', 'approval-actions', '');
    const button = node('button', 'primary', label);
    button.type = 'button';
    button.addEventListener('click', () => window.dispatchEvent(new CustomEvent(eventName, { detail: { threadId: state.selected, requestId: item.requestId } })));
    actions.appendChild(button);
    return actions;
  }

  function renderGeneratedImage(item, mediaUrl) {
    const media = node('div', 'generated-image', '');
    const image = document.createElement('img');
    image.src = mediaUrl;
    image.alt = item.alt || 'Codex 生成的图片';
    image.loading = 'lazy';
    media.appendChild(image);
    const actions = node('div', 'generated-image-actions', '');
    for (const [eventName, label] of [['codex-open-media', '打开'], ['codex-save-media', '保存']]) {
      const button = node('button', 'secondary', label);
      button.type = 'button';
      button.addEventListener('click', () => window.dispatchEvent(new CustomEvent(eventName, { detail: { itemId: item.id, url: mediaUrl } })));
      actions.appendChild(button);
    }
    media.appendChild(actions);
    return media;
  }

  function sameOriginMediaUrl(value) {
    if (!value) return '';
    try {
      const url = new URL(value, location.href);
      return (url.protocol === 'http:' || url.protocol === 'https:') && url.origin === location.origin ? url.href : '';
    } catch (_) {
      return '';
    }
  }

  function renderCapabilities() {
    const models = state.capabilities.models || [];
    const current = state.conversations.get(state.selected);
    const settings = current ? current.settings : { model: null, effort: null, speed: null };
    const requestedModel = settings.model || model.value;
    model.replaceChildren(...models.map(item => option(item.model || item.id, item.displayName || item.model || item.id)));
    const selected = models.find(item => (item.model || item.id) === requestedModel) || models.find(item => item.isDefault) || models[0];
    const selectedModel = selected && (selected.model || selected.id) || '';
    model.value = selectedModel;
    const efforts = selected && selected.supportedReasoningEfforts || [];
    effort.replaceChildren(...efforts.map(item => option(item.reasoningEffort, item.description || item.reasoningEffort)));
    const requestedEffort = efforts.some(item => item.reasoningEffort === settings.effort) ? settings.effort : (selected && selected.defaultReasoningEffort || (efforts[0] && efforts[0].reasoningEffort) || '');
    effort.value = requestedEffort;
    const tiers = selected && (selected.serviceTiers || selected.additionalSpeedTiers) || [];
    const extraTiers = uniqueTiers(Array.isArray(tiers) ? tiers : []).filter(item => item.value !== 'standard');
    speedWrap.hidden = !extraTiers.length;
    speed.replaceChildren(option('standard', '标准'), ...extraTiers.map(item => option(item.value, item.label)));
    const defaultSpeed = selected && selected.defaultServiceTier;
    const requestedSpeed = extraTiers.some(item => item.value === settings.speed) ? settings.speed : (extraTiers.some(item => item.value === defaultSpeed) ? defaultSpeed : 'standard');
    speed.value = requestedSpeed;
    if (current) current.settings = { model: selectedModel, effort: requestedEffort, speed: requestedSpeed };
  }

  function setCapabilities(next) {
    state.capabilities = { ...state.capabilities, ...(next || {}) };
    renderCapabilities();
  }

  function setAccount(next) {
    const type = next && next.type;
    const loggedIn = !!type;
    const labels = { chatgpt: 'ChatGPT 已登录', chatgptAuthTokens: 'ChatGPT 外部令牌', apiKey: 'API Key 已配置', amazonBedrock: 'Amazon Bedrock 已配置' };
    account.dataset.state = loggedIn ? 'logged-in' : 'logged-out';
    account.textContent = loggedIn ? ((next.planType ? planLabel(next.planType) + ' · ' : '') + (labels[type] || '账号已配置')) : '登录 ChatGPT';
    account.title = loggedIn ? '管理当前 Codex 认证' : '使用自己的 ChatGPT 账号登录';
  }

  function setQuota(snapshot) {
    const multiBuckets = snapshot && snapshot.rateLimitsByLimitId ? Object.values(snapshot.rateLimitsByLimitId) : [];
    const buckets = multiBuckets.length ? multiBuckets : (snapshot && snapshot.rateLimits ? [snapshot.rateLimits] : []);
    const windows = buckets.flatMap(bucket => [bucket && bucket.primary, bucket && bucket.secondary].filter(Boolean));
    if (!windows.length) {
      quota.textContent = '—';
      quota.title = '尚未读取额度窗口';
      return;
    }
    const highest = windows.reduce((best, item) => Number(item.usedPercent) > Number(best.usedPercent) ? item : best, windows[0]);
    const used = Math.max(0, Math.min(100, Number(highest.usedPercent) || 0));
    const reset = Number(highest.resetsAt) > 0 ? new Date(Number(highest.resetsAt) * 1000).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
    quota.textContent = '已用 ' + used + '%' + (reset ? ' · ' + reset + ' 重置' : '');
    quota.title = windows.map(item => '已用 ' + Math.max(0, Math.min(100, Number(item.usedPercent) || 0)) + '%' + (item.windowDurationMins ? ' / ' + item.windowDurationMins + ' 分钟窗口' : '')).join('\n');
  }

  function setWorkspace(label) {
    workspace.textContent = label || '应用文件';
  }

  function planLabel(value) {
    const key = String(value || '').toLowerCase();
    return ({ free: '免费', plus: 'Plus', pro: 'Pro', team: '团队', business: 'Business', enterprise: '企业', edu: '教育' })[key] || String(value || '');
  }

  function updateSendMode(current) {
    let mode = 'send';
    if (current && current.status === 'generating') mode = 'stop';
    else if (current && current.status === 'interrupted' && !prompt.value.trim() && !current.attachments.length) mode = 'continue';
    send.dataset.mode = mode;
    send.textContent = mode === 'stop' ? '停止' : (mode === 'continue' ? '继续' : '发送');
    steer.hidden = mode !== 'stop';
  }

  function uniqueTiers(tiers) {
    const seen = new Set();
    const output = [];
    for (const item of tiers) {
      const value = typeof item === 'string' ? item : (item && (item.id || item.value || item.serviceTier));
      if (!value || seen.has(value)) continue;
      seen.add(value);
      output.push({ value, label: typeof item === 'string' ? item : (item.displayName || item.name || item.label || value) });
    }
    return output;
  }

  function nearBottom(element) {
    return element.scrollHeight - element.scrollTop - element.clientHeight < 48;
  }

  function textOfUser(item) {
    if (typeof item.text === 'string') return item.text;
    return (item.content || []).filter(part => part.type === 'text').map(part => part.text).join('\n');
  }

  function toolTitle(item) {
    const labels = { commandExecution: '⌨ 命令执行', fileChange: '📝 文件修改', diff: '🧾 汇总差异', webSearch: '🌐 网页搜索', mcpToolCall: '🔌 应用工具', dynamicToolCall: '🧩 动态工具', collabToolCall: '👥 多智能体协作', collabAgentToolCall: '👥 多智能体协作（旧版）', subAgentActivity: '🤝 子智能体活动（版本专用）', imageView: '🖼 查看图片', imageGeneration: '🎨 生成图片（版本专用）', sleep: '⏱ 等待', plan: '📋 计划', enteredReviewMode: '🔎 进入审阅', exitedReviewMode: '✅ 审阅结果', contextCompaction: '🗜 上下文压缩', approval: '🛡 授权请求', userInputRequest: '❓ 需要回答', elicitationRequest: '🧾 应用请求', permissionRequest: '🔐 权限范围请求', serverRequest: '⚙ 宿主请求', warning: '⚠ Codex 警告', error: '⚠ 回合错误' };
    return labels[item.type] || ('🔧 ' + item.type);
  }

  function toolDetail(item) {
    if (item.type === 'commandExecution') return [item.command, item.cwd, item.aggregatedOutput].filter(Boolean).join('\n');
    if (item.type === 'fileChange') return [(item.changes || []).map(change => change.kind + ' ' + change.path).join('\n'), item.patch].filter(Boolean).join('\n');
    if (item.type === 'diff') return item.diff || '差异已清空';
    if (item.type === 'webSearch') return item.query || '';
    if (item.type === 'plan') {
      const steps = Array.isArray(item.plan) ? item.plan.map(step => statusLabel(step.status) + ' · ' + (step.step || step.text || '')).join('\n') : '';
      return [item.explanation, steps, item.text].filter(Boolean).join('\n') || '计划已更新';
    }
    if (item.type === 'approval') {
      const network = item.networkApprovalContext;
      const networkTarget = network && [network.protocol, network.host, network.port].filter(value => value !== undefined && value !== null).join(' ');
      return [item.reason, item.command, item.cwd, item.grantRoot, networkTarget].filter(Boolean).join('\n') || 'Codex 请求继续执行所需的授权';
    }
    if (item.type === 'userInputRequest') {
      return (item.questions || []).map(question => {
        const choices = (question.options || []).map(option => option.label).filter(Boolean).join(' / ');
        return [question.header, question.question, choices, question.isSecret ? '回答内容将隐藏' : ''].filter(Boolean).join(' · ');
      }).join('\n') || 'Codex 需要补充信息';
    }
    if (item.type === 'elicitationRequest') return [item.serverName, item.message, item.mode, safeUrlHost(item.url)].filter(Boolean).join('\n') || '扩展应用需要用户输入';
    if (item.type === 'permissionRequest') return [item.reason, item.cwd, item.permissions && item.permissions.network ? '请求额外网络权限' : '', item.permissions && item.permissions.fileSystem ? '请求额外文件权限' : ''].filter(Boolean).join('\n') || 'Codex 请求扩大当前权限范围';
    if (item.type === 'serverRequest') return '该请求必须由可信宿主按本机协议结构处理';
    if (item.type === 'imageView') return shortPath(item.path || item.filename || '') || '图片已读取';
    if (item.type === 'imageGeneration') return [shortPath(item.savedPath || ''), item.failure && item.failure.message, item.status].filter(Boolean).join('\n') || '图片生成状态已更新';
    if (item.type === 'mcpToolCall' || item.type === 'dynamicToolCall') {
      return [item.appContext && item.appContext.appName, item.server || item.app || item.provider, item.tool || item.name, item.resultSummary || item.outputText, item.error && item.error.message].filter(Boolean).join('\n') || '工具状态已更新';
    }
    if (item.type === 'collabToolCall') return [item.tool, item.senderThreadId && ('发送线程 ' + item.senderThreadId), item.receiverThreadId && ('接收线程 ' + item.receiverThreadId), item.newThreadId && ('新线程 ' + item.newThreadId), item.agentStatus].filter(Boolean).join('\n') || '协作状态已更新';
    if (item.type === 'collabAgentToolCall') return [item.tool, item.receiverThreadIds && ('目标智能体 ' + item.receiverThreadIds.length + ' 个')].filter(Boolean).join('\n') || '旧版协作状态已更新';
    if (item.type === 'subAgentActivity') return item.kind || '子智能体状态已更新';
    if (item.type === 'sleep') return '等待 ' + Math.max(0, Number(item.durationMs) || 0) + ' 毫秒';
    if (item.type === 'enteredReviewMode' || item.type === 'exitedReviewMode') return item.review || '审阅状态已更新';
    if (item.type === 'contextCompaction') return '较早上下文已压缩，当前对话内容仍保留';
    if (item.type === 'error') return item.message + (item.willRetry ? '\n将自动重试' : '');
    return item.message || (item.error && item.error.message) || '无可显示详情';
  }

  function shortPath(value) {
    return String(value || '').split(/[\\/]/).filter(Boolean).pop() || '';
  }

  function safeUrlHost(value) {
    try {
      const url = new URL(value);
      return url.protocol === 'https:' ? url.host : '';
    } catch (_) {
      return '';
    }
  }

  function statusLabel(status) {
    return ({ inProgress: '进行中', completed: '已完成', failed: '失败', declined: '已拒绝', interrupted: '已中断', cancelled: '已取消', waitingForApproval: '等待处理' })[status] || '等待中';
  }

  function decisionLabel(decision) {
    return ({ accept: '允许一次', acceptForSession: '本会话允许', decline: '拒绝', cancel: '取消' })[decision] || '按范围允许';
  }

  function option(value, label) {
    const item = document.createElement('option');
    item.value = value || '';
    item.textContent = label || value || '';
    return item;
  }

  function node(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  model.addEventListener('change', () => {
    const current = state.conversations.get(state.selected);
    if (current) {
      current.settings.model = model.value;
      current.settings.effort = null;
    }
    renderCapabilities();
  });
  effort.addEventListener('change', () => {
    const current = state.conversations.get(state.selected);
    if (current) current.settings.effort = effort.value;
  });
  speed.addEventListener('change', () => {
    const current = state.conversations.get(state.selected);
    if (current) current.settings.speed = speed.value;
  });
  prompt.addEventListener('input', () => {
    const current = state.conversations.get(state.selected);
    if (current) current.draft = prompt.value;
    updateSendMode(current);
  });
  messages.addEventListener('scroll', () => {
    const current = state.conversations.get(state.selected);
    if (!current) return;
    current.scrollTop = messages.scrollTop;
    current.followBottom = nearBottom(messages);
  }, { passive: true });
  account.addEventListener('click', () => window.dispatchEvent(new CustomEvent('codex-account-action', { detail: { state: account.dataset.state || 'logged-out' } })));
  attach.addEventListener('click', () => window.dispatchEvent(new CustomEvent('codex-attach', { detail: { threadId: state.selected } })));
  steer.addEventListener('click', () => window.dispatchEvent(new CustomEvent('codex-steer', { detail: { threadId: state.selected, text: prompt.value } })));
  threadActionRun.addEventListener('click', () => window.dispatchEvent(new CustomEvent('codex-thread-action', { detail: { threadId: state.selected, action: threadAction.value } })));
  send.addEventListener('click', () => {
    const current = state.conversations.get(state.selected);
    const eventName = send.dataset.mode === 'stop' ? 'codex-stop' : (send.dataset.mode === 'continue' ? 'codex-continue' : 'codex-send');
    window.dispatchEvent(new CustomEvent(eventName, { detail: { threadId: state.selected, text: prompt.value, settings: current ? { ...current.settings } : null } }));
  });

  window.CodexAgentUI = { conversation, bindTurn, selectConversation, applyEvent, applyServerRequest, resolveServerRequest, setCapabilities, setAccount, setQuota, setWorkspace };
  renderAll(false);
}());
