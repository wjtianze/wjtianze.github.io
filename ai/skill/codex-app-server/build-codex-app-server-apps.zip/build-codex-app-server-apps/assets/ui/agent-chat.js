'use strict';

(function () {
  const state = { conversations: new Map(), selected: null, capabilities: { models: [] } };
  const tabs = document.getElementById('tabs');
  const messages = document.getElementById('messages');
  const send = document.getElementById('send');
  const usage = document.getElementById('usage');
  const model = document.getElementById('model');
  const effort = document.getElementById('effort');
  const speedWrap = document.getElementById('speed-wrap');
  const speed = document.getElementById('speed');

  function conversation(id, patch) {
    if (!state.conversations.has(id)) state.conversations.set(id, { id, name: '新对话', status: 'idle', activeTurnId: null, items: new Map(), order: [], usage: 0, scrollTop: 0 });
    const value = state.conversations.get(id);
    if (patch) Object.assign(value, patch);
    if (!state.selected) state.selected = id;
    return value;
  }

  function selectConversation(id) {
    const previous = state.conversations.get(state.selected);
    if (previous) previous.scrollTop = messages.scrollTop;
    state.selected = id;
    renderAll(false);
    const current = state.conversations.get(id);
    requestAnimationFrame(() => { messages.scrollTop = current ? current.scrollTop : 0; });
  }

  function applyEvent(message) {
    const params = message.params || {};
    const threadId = params.threadId || (params.thread && params.thread.id);
    if (!threadId) return;
    const item = params.item;
    const current = conversation(threadId);
    const followsBottom = state.selected === threadId && nearBottom(messages);

    if (message.method === 'turn/started') {
      current.status = 'generating';
      current.activeTurnId = params.turn && params.turn.id;
    } else if (message.method === 'turn/completed') {
      current.status = params.turn && params.turn.status === 'failed' ? 'failed' : 'idle';
      current.activeTurnId = null;
    } else if (message.method === 'item/started' && item) {
      upsertItem(current, item);
    } else if (message.method === 'item/completed' && item) {
      upsertItem(current, item, true);
    } else if (message.method === 'item/reasoning/summaryTextDelta') {
      const target = ensureItem(current, params.itemId, 'reasoning');
      const index = Number.isInteger(params.summaryIndex) ? params.summaryIndex : target.steps.length;
      while (target.steps.length <= index) target.steps.push('');
      target.steps[index] += params.delta || '';
    } else if (message.method === 'item/reasoning/summaryPartAdded') {
      const target = ensureItem(current, params.itemId, 'reasoning');
      const index = Number.isInteger(params.summaryIndex) ? params.summaryIndex : target.steps.length;
      while (target.steps.length <= index) target.steps.push('');
    } else if (message.method === 'item/agentMessage/delta') {
      const target = ensureItem(current, params.itemId, 'agentMessage');
      target.text = (target.text || '') + (params.delta || '');
    } else if (message.method === 'item/commandExecution/outputDelta') {
      const target = ensureItem(current, params.itemId, 'commandExecution');
      target.aggregatedOutput = (target.aggregatedOutput || '') + (params.delta || '');
    } else if (message.method === 'thread/tokenUsage/updated') {
      const total = params.tokenUsage && params.tokenUsage.total;
      current.usage = Number(total && (total.totalTokens || total.total_tokens)) || current.usage;
    }

    renderTabs();
    if (state.selected === threadId) renderConversation(current, followsBottom);
  }

  function ensureItem(current, id, type) {
    if (!current.items.has(id)) {
      current.items.set(id, { id, type, status: 'inProgress', steps: [] });
      current.order.push(id);
    }
    return current.items.get(id);
  }

  function upsertItem(current, item, completed) {
    const target = ensureItem(current, item.id, item.type);
    const oldSteps = target.steps;
    Object.assign(target, item);
    if (item.type === 'reasoning') target.steps = Array.isArray(item.summary) ? item.summary.slice() : oldSteps;
    if (completed && !target.status) target.status = 'completed';
  }

  function renderAll(followBottom) {
    renderTabs();
    renderConversation(state.conversations.get(state.selected), followBottom);
    renderCapabilities();
  }

  function renderTabs() {
    tabs.replaceChildren(...Array.from(state.conversations.values(), current => {
      const button = node('button', 'tab', current.name);
      button.type = 'button';
      button.setAttribute('aria-selected', String(current.id === state.selected));
      const dot = node('span', 'status ' + current.status, '');
      button.appendChild(dot);
      button.addEventListener('click', () => selectConversation(current.id));
      return button;
    }));
  }

  function renderConversation(current, followBottom) {
    if (!current) {
      messages.replaceChildren(node('div', 'empty', '创建或恢复一个 Codex 对话后，过程与最终回答会显示在这里。'));
      send.textContent = '发送';
      send.dataset.mode = 'send';
      return;
    }
    const remembered = messages.scrollTop;
    const fragment = document.createDocumentFragment();
    for (const id of current.order) fragment.appendChild(renderItem(current.items.get(id)));
    if (!current.order.length) fragment.appendChild(node('div', 'empty', '输入目标开始对话。Codex 的思考步骤和工具调用会与最终回答分开显示。'));
    messages.replaceChildren(fragment);
    send.textContent = current.status === 'generating' ? '停止' : '发送';
    send.dataset.mode = current.status === 'generating' ? 'stop' : 'send';
    usage.textContent = '当前对话 ' + current.usage + ' 词元';
    requestAnimationFrame(() => { messages.scrollTop = followBottom ? messages.scrollHeight : remembered; });
  }

  function renderItem(item) {
    if (item.type === 'userMessage') {
      return node('article', 'message user-message', textOfUser(item));
    }
    if (item.type === 'agentMessage') {
      return node('article', 'message answer', item.text || '');
    }
    if (item.type === 'reasoning') {
      const details = node('details', 'message process', '');
      details.open = true;
      details.appendChild(node('summary', '', '🧠 Codex 过程'));
      const body = node('div', 'process-body', '');
      const steps = item.steps && item.steps.length ? item.steps : ['正在思考…'];
      for (const step of steps) body.appendChild(node('span', 'reason-step', step || '…'));
      details.appendChild(body);
      return details;
    }
    const failed = item.status === 'failed' || item.status === 'declined';
    const card = node('article', 'message tool-card' + (failed ? ' failed' : ''), '');
    const head = node('div', 'tool-head', '');
    head.appendChild(node('span', '', toolTitle(item)));
    head.appendChild(node('span', 'tool-status', statusLabel(item.status)));
    card.appendChild(head);
    const detail = document.createElement('details');
    detail.appendChild(node('summary', '', '查看详情'));
    detail.appendChild(node('pre', '', toolDetail(item)));
    card.appendChild(detail);
    return card;
  }

  function renderCapabilities() {
    const models = state.capabilities.models || [];
    const requestedModel = model.value;
    model.replaceChildren(...models.map(item => option(item.model || item.id, item.displayName || item.model || item.id)));
    const selected = models.find(item => (item.model || item.id) === requestedModel) || models.find(item => item.isDefault) || models[0];
    if (selected) model.value = selected.model || selected.id;
    const efforts = selected && selected.supportedReasoningEfforts || [];
    effort.replaceChildren(...efforts.map(item => option(item.reasoningEffort, item.description || item.reasoningEffort)));
    if (selected && selected.defaultReasoningEffort) effort.value = selected.defaultReasoningEffort;
    const tiers = selected && (selected.serviceTiers || selected.additionalSpeedTiers) || [];
    speedWrap.hidden = !tiers.length;
    speed.replaceChildren(option('standard', '标准'), ...tiers.map(item => option(typeof item === 'string' ? item : item.id, typeof item === 'string' ? item : (item.displayName || item.id))));
  }

  function setCapabilities(next) {
    state.capabilities = { ...state.capabilities, ...(next || {}) };
    renderCapabilities();
  }

  function nearBottom(element) {
    return element.scrollHeight - element.scrollTop - element.clientHeight < 48;
  }

  function textOfUser(item) {
    if (typeof item.text === 'string') return item.text;
    return (item.content || []).filter(part => part.type === 'text').map(part => part.text).join('\n');
  }

  function toolTitle(item) {
    const labels = { commandExecution: '⌨ 命令执行', fileChange: '📝 文件修改', webSearch: '🌐 网页搜索', mcpToolCall: '🔌 应用工具', dynamicToolCall: '🧩 动态工具', imageView: '🖼 查看图片', plan: '📋 计划' };
    return labels[item.type] || ('🔧 ' + item.type);
  }

  function toolDetail(item) {
    if (item.type === 'commandExecution') return [item.command, item.cwd, item.aggregatedOutput].filter(Boolean).join('\n');
    if (item.type === 'fileChange') return (item.changes || []).map(change => change.kind + ' ' + change.path).join('\n');
    if (item.type === 'webSearch') return item.query || '';
    return JSON.stringify(item, null, 2);
  }

  function statusLabel(status) {
    return ({ inProgress: '进行中', completed: '已完成', failed: '失败', declined: '已拒绝' })[status] || '等待中';
  }

  function option(value, label) {
    const item = document.createElement('option');
    item.value = value || '';
    item.textContent = label || value || '';
    return item;
  }

  function node(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  model.addEventListener('change', renderCapabilities);
  send.addEventListener('click', () => window.dispatchEvent(new CustomEvent(send.dataset.mode === 'stop' ? 'codex-stop' : 'codex-send', { detail: { threadId: state.selected, text: document.getElementById('prompt').value } })));

  window.CodexAgentUI = { conversation, selectConversation, applyEvent, setCapabilities };

  conversation('demo', { name: '演示对话' });
  setCapabilities({ models: [{ model: 'current-default', displayName: '从 model/list 读取', isDefault: true, defaultReasoningEffort: 'medium', supportedReasoningEfforts: [{ reasoningEffort: 'low', description: '低' }, { reasoningEffort: 'medium', description: '中' }, { reasoningEffort: 'high', description: '高' }], inputModalities: ['text', 'image'] }] });
  applyEvent({ method: 'turn/started', params: { threadId: 'demo', turn: { id: 'turn-demo', status: 'inProgress' } } });
  applyEvent({ method: 'item/started', params: { threadId: 'demo', turnId: 'turn-demo', item: { id: 'reason-demo', type: 'reasoning', summary: [], content: [] } } });
  applyEvent({ method: 'item/reasoning/summaryTextDelta', params: { threadId: 'demo', turnId: 'turn-demo', itemId: 'reason-demo', summaryIndex: 0, delta: '读取当前应用结构与协议版本' } });
  applyEvent({ method: 'item/reasoning/summaryPartAdded', params: { threadId: 'demo', turnId: 'turn-demo', itemId: 'reason-demo', summaryIndex: 1 } });
  applyEvent({ method: 'item/reasoning/summaryTextDelta', params: { threadId: 'demo', turnId: 'turn-demo', itemId: 'reason-demo', summaryIndex: 1, delta: '准备零额度回归测试' } });
  applyEvent({ method: 'item/started', params: { threadId: 'demo', turnId: 'turn-demo', item: { id: 'cmd-demo', type: 'commandExecution', command: 'npm.cmd test', cwd: '应用工作区', status: 'inProgress' } } });
}());
