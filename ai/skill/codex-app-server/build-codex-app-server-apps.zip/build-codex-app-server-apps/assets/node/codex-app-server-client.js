'use strict';

const { EventEmitter } = require('node:events');
const { spawn: defaultSpawn } = require('node:child_process');
const readline = require('node:readline');

class CodexProtocolError extends Error {
  constructor(method, payload) {
    const detail = payload && payload.message ? payload.message : 'Codex App Server 请求失败';
    super(method + ': ' + detail);
    this.name = 'CodexProtocolError';
    this.method = method;
    this.code = payload && Number.isInteger(payload.code) ? payload.code : null;
    this.details = payload || null;
  }
}

class CodexAppServerClient extends EventEmitter {
  constructor(options = {}) {
    super();
    if (!options.command) throw new TypeError('command 是必填项');
    this.command = options.command;
    this.args = Array.isArray(options.args) ? options.args.slice() : ['app-server'];
    this.cwd = options.cwd || process.cwd();
    this.env = { ...process.env, ...(options.env || {}) };
    this.spawn = options.spawn || defaultSpawn;
    this.clientInfo = options.clientInfo || { name: 'codex_app_server_host', title: 'Codex App Server Host', version: '0.1.0' };
    this.capabilities = options.capabilities || {};
    this.timeoutMs = positive(options.timeoutMs, 30000);
    this.maxOverloadRetries = Math.max(0, Number(options.maxOverloadRetries) || 3);
    this.child = null;
    this.reader = null;
    this.pending = new Map();
    this.nextId = 1;
    this.ready = false;
    this.startPromise = null;
    this.stopping = false;
    this.stderr = [];
    this.serverRequestHandler = null;
  }

  setServerRequestHandler(handler) {
    if (handler !== null && typeof handler !== 'function') throw new TypeError('服务端请求处理器必须是函数或 null');
    this.serverRequestHandler = handler;
  }

  start() {
    if (this.ready) return Promise.resolve();
    if (this.startPromise) return this.startPromise;
    this.startPromise = this._start().finally(() => {
      if (!this.ready) this.startPromise = null;
    });
    return this.startPromise;
  }

  async _start() {
    this.stopping = false;
    try {
      this.child = this.spawn(this.command, this.args, {
        cwd: this.cwd,
        env: this.env,
        windowsHide: true,
        shell: false,
        stdio: ['pipe', 'pipe', 'pipe']
      });
    } catch (error) {
      throw executableError(error, this.command);
    }

    this.child.once('error', error => this._fatal(executableError(error, this.command)));
    this.child.once('exit', (code, signal) => {
      const error = new Error('Codex App Server 已退出（代码 ' + String(code) + (signal ? '，信号 ' + signal : '') + '）');
      if (!this.stopping) this._fatal(error);
      this._resetProcess();
    });
    this.child.stderr.on('data', chunk => {
      const value = String(chunk || '');
      if (!value) return;
      this.stderr.push(value);
      while (this.stderr.length > 40) this.stderr.shift();
      this.emit('stderr', value);
    });
    this.reader = readline.createInterface({ input: this.child.stdout, crlfDelay: Infinity });
    this.reader.on('line', line => this._onLine(line));

    await this.request('initialize', { clientInfo: this.clientInfo, capabilities: this.capabilities }, { retryOverload: false });
    this.notify('initialized', {});
    this.ready = true;
    this.emit('ready');
  }

  async request(method, params, options = {}) {
    const retryOverload = options.retryOverload !== false;
    const attempts = retryOverload ? this.maxOverloadRetries + 1 : 1;
    let lastError;
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      try {
        return await this._requestOnce(method, params, positive(options.timeoutMs, this.timeoutMs));
      } catch (error) {
        lastError = error;
        if (!(error instanceof CodexProtocolError) || error.code !== -32001 || attempt + 1 >= attempts) throw error;
        const delay = Math.min(2000, 100 * (2 ** attempt)) + Math.floor(Math.random() * 80);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
    throw lastError;
  }

  _requestOnce(method, params, timeoutMs) {
    if (!this.child || !this.child.stdin || this.child.stdin.destroyed) return Promise.reject(new Error('Codex App Server 尚未运行'));
    const id = this.nextId++;
    const message = { method, id };
    if (params !== undefined) message.params = params;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error('Codex App Server 请求超时：' + method));
      }, timeoutMs);
      this.pending.set(id, { method, resolve, reject, timeout });
      try {
        this._write(message);
      } catch (error) {
        clearTimeout(timeout);
        this.pending.delete(id);
        reject(error);
      }
    });
  }

  notify(method, params) {
    const message = { method };
    if (params !== undefined) message.params = params;
    this._write(message);
  }

  respond(id, result, error) {
    if (id === undefined || id === null) throw new TypeError('服务端请求响应缺少 id');
    this._write(error ? { id, error } : { id, result: result === undefined ? {} : result });
  }

  _write(message) {
    if (!this.child || !this.child.stdin || this.child.stdin.destroyed) throw new Error('Codex App Server 连接已关闭');
    this.child.stdin.write(JSON.stringify(message) + '\n');
  }

  _onLine(line) {
    const value = String(line || '').trim();
    if (!value) return;
    let message;
    try {
      message = JSON.parse(value);
    } catch (_) {
      this.emit('warning', new Error('Codex App Server 返回无效 JSON：' + value.slice(0, 300)));
      return;
    }

    if (message.id !== undefined && (Object.prototype.hasOwnProperty.call(message, 'result') || message.error)) {
      const pending = this.pending.get(message.id);
      if (!pending) return this.emit('orphanResponse', message);
      this.pending.delete(message.id);
      clearTimeout(pending.timeout);
      if (message.error) pending.reject(new CodexProtocolError(pending.method, message.error));
      else pending.resolve(message.result);
      return;
    }

    if (message.id !== undefined && message.method) {
      this.emit('serverRequest', message);
      this._handleServerRequest(message);
      return;
    }

    if (message.method) this.emit('notification', message);
  }

  async _handleServerRequest(message) {
    if (!this.serverRequestHandler) {
      this.respond(message.id, null, { code: -32601, message: '客户端未配置此服务端请求的处理器：' + message.method });
      return;
    }
    try {
      const result = await this.serverRequestHandler(message);
      this.respond(message.id, result === undefined ? {} : result);
    } catch (error) {
      this.respond(message.id, null, { code: -32000, message: String(error && error.message || error || '服务端请求处理失败') });
    }
  }

  async interrupt(threadId, turnId) {
    return this.request('turn/interrupt', { threadId, turnId }, { retryOverload: false });
  }

  diagnostics() {
    return { ready: this.ready, command: this.command, args: this.args.slice(), cwd: this.cwd, stderrTail: this.stderr.join('').slice(-12000) };
  }

  stop() {
    this.stopping = true;
    const error = new Error('Codex App Server 已停止');
    this._rejectPending(error);
    if (this.child) {
      try { this.child.stdin.end(); } catch (_) {}
      try { this.child.kill(); } catch (_) {}
    }
    this._resetProcess();
  }

  _fatal(error) {
    const failure = error instanceof Error ? error : new Error(String(error || 'Codex App Server 连接失败'));
    this._rejectPending(failure);
    this.ready = false;
    this.emit('fatal', failure);
  }

  _rejectPending(error) {
    for (const item of this.pending.values()) {
      clearTimeout(item.timeout);
      item.reject(error);
    }
    this.pending.clear();
  }

  _resetProcess() {
    if (this.reader) {
      try { this.reader.close(); } catch (_) {}
    }
    this.reader = null;
    this.child = null;
    this.ready = false;
    this.startPromise = null;
  }
}

function positive(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

function executableError(error, command) {
  if (!error || !['EPERM', 'EACCES'].includes(error.code)) return error;
  const wrapped = new Error('Windows 阻止启动 Codex 可执行文件：' + command + '。请让用户重新选择可运行的 codex.exe；不要复制应用包文件或修改权限。');
  wrapped.code = error.code;
  wrapped.cause = error;
  return wrapped;
}

module.exports = { CodexAppServerClient, CodexProtocolError };
