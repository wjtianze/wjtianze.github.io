'use strict';

const { EventEmitter } = require('node:events');
const { spawn: defaultSpawn } = require('node:child_process');
const readline = require('node:readline');

class CodexProtocolError extends Error {
  constructor(method, payload) {
    const detail = payload && payload.message ? payload.message : 'Codex App Server 请求失败';
    super(method + ': ' + detail);
    this.name = 'CodexProtocolError';
    this.method = method;
    this.code = payload && Number.isInteger(payload.code) ? payload.code : null;
    this.details = payload || null;
  }
}

class CodexAppServerClient extends EventEmitter {
  constructor(options = {}) {
    super();
    if (!options.command) throw new TypeError('command 是必填项');
    this.command = options.command;
    this.args = Array.isArray(options.args) ? options.args.slice() : ['app-server'];
    this.cwd = options.cwd || process.cwd();
    this.env = { ...process.env, ...(options.env || {}) };
    this.spawn = options.spawn || defaultSpawn;
    this.clientInfo = options.clientInfo || { name: 'codex_app_server_host', title: 'Codex App Server Host', version: '0.1.0' };
    this.capabilities = options.capabilities || {};
    this.timeoutMs = positive(options.timeoutMs, 30000);
    const configuredRetries = options.maxOverloadRetries === undefined ? 3 : Number(options.maxOverloadRetries);
    this.maxOverloadRetries = Number.isFinite(configuredRetries) ? Math.max(0, Math.floor(configuredRetries)) : 3;
    this.maxStderrBytes = Math.max(1024, Math.floor(positive(options.maxStderrBytes, 12000)));
    this.child = null;
    this.reader = null;
    this.pending = new Map();
    this.nextId = 1;
    this.ready = false;
    this.startPromise = null;
    this.stopping = false;
    this.stderr = Buffer.alloc(0);
    this.expectedExits = new WeakSet();
    this.serverRequestHandler = null;
    this.serverInfo = null;
  }

  setServerRequestHandler(handler) {
    if (handler !== null && typeof handler !== 'function') throw new TypeError('服务端请求处理器必须是函数或 null');
    this.serverRequestHandler = handler;
  }

  start() {
    if (this.ready) return Promise.resolve();
    if (this.startPromise) return this.startPromise;
    this.startPromise = this._start().finally(() => {
      if (!this.ready) this.startPromise = null;
    });
    return this.startPromise;
  }

  async _start() {
    this.stopping = false;
    this.stderr = Buffer.alloc(0);
    let child;
    try {
      child = this.spawn(this.command, this.args, {
        cwd: this.cwd,
        env: this.env,
        windowsHide: true,
        shell: false,
        stdio: ['pipe', 'pipe', 'pipe']
      });
    } catch (error) {
      throw executableError(error, this.command);
    }
    this.child = child;

    if (!child || !child.stdin || !child.stdout || !child.stderr) {
      this._terminateChild(child);
      throw new Error('Codex App Server 子进程未提供完整的 stdio 管道');
    }

    child.once('error', error => {
      if (this.child !== child) return;
      const expected = this.expectedExits.has(child) || this.stopping;
      if (!expected) this._fatal(executableError(error, this.command));
      this._resetProcess(child);
    });
    child.once('exit', (code, signal) => {
      if (this.child !== child) return;
      const error = new Error('Codex App Server 已退出（代码 ' + String(code) + (signal ? '，信号 ' + signal : '') + '）');
      if (!this.expectedExits.has(child) && !this.stopping) this._fatal(error);
      this._resetProcess(child);
    });
    child.stdin.on('error', error => {
      if (this.child !== child || this.expectedExits.has(child) || this.stopping) return;
      this._fatal(error);
      this._terminateChild(child);
    });
    child.stderr.on('data', chunk => {
      const value = String(chunk || '');
      if (!value) return;
      const next = Buffer.concat([this.stderr, Buffer.from(value, 'utf8')]);
      this.stderr = next.length > this.maxStderrBytes ? next.subarray(next.length - this.maxStderrBytes) : next;
      this.emit('stderr', value);
    });
    this.reader = readline.createInterface({ input: child.stdout, crlfDelay: Infinity });
    this.reader.on('line', line => {
      if (this.child === child) this._onLine(line);
    });

    try {
      this.serverInfo = await this.request('initialize', { clientInfo: this.clientInfo, capabilities: this.capabilities }, { retryOverload: false });
      this.notify('initialized', {});
      this.ready = true;
      this.emit('ready');
    } catch (error) {
      this._terminateChild(child);
      throw error;
    }
  }

  async request(method, params, options = {}) {
    const retryOverload = options.retryOverload !== false;
    const attempts = retryOverload ? this.maxOverloadRetries + 1 : 1;
    let lastError;
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      try {
        return await this._requestOnce(method, params, positive(options.timeoutMs, this.timeoutMs));
      } catch (error) {
        lastError = error;
        if (!(error instanceof CodexProtocolError) || error.code !== -32001 || attempt + 1 >= attempts) throw error;
        const delay = Math.min(2000, 100 * (2 ** attempt)) + Math.floor(Math.random() * 80);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
    throw lastError;
  }

  _requestOnce(method, params, timeoutMs) {
    if (!this.child || !this.child.stdin || this.child.stdin.destroyed) return Promise.reject(new Error('Codex App Server 尚未运行'));
    const id = this.nextId++;
    const message = { method, id };
    if (params !== undefined) message.params = params;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error('Codex App Server 请求超时：' + method));
      }, timeoutMs);
      this.pending.set(id, { method, resolve, reject, timeout });
      try {
        this._write(message);
      } catch (error) {
        clearTimeout(timeout);
        this.pending.delete(id);
        reject(error);
      }
    });
  }

  notify(method, params) {
    const message = { method };
    if (params !== undefined) message.params = params;
    this._write(message);
  }

  respond(id, result, error) {
    if (id === undefined || id === null) throw new TypeError('服务端请求响应缺少 id');
    this._write(error ? { id, error } : { id, result: result === undefined ? {} : result });
  }

  _write(message) {
    if (!this.child || !this.child.stdin || this.child.stdin.destroyed) throw new Error('Codex App Server 连接已关闭');
    this.child.stdin.write(JSON.stringify(message) + '\n');
  }

  _onLine(line) {
    const value = String(line || '').trim();
    if (!value) return;
    let message;
    try {
      message = JSON.parse(value);
    } catch (_) {
      this.emit('warning', new Error('Codex App Server 返回无效 JSON：' + value.slice(0, 300)));
      return;
    }

    if (message.id !== undefined && (Object.prototype.hasOwnProperty.call(message, 'result') || message.error)) {
      const pending = this.pending.get(message.id);
      if (!pending) return this.emit('orphanResponse', message);
      this.pending.delete(message.id);
      clearTimeout(pending.timeout);
      if (message.error) pending.reject(new CodexProtocolError(pending.method, message.error));
      else pending.resolve(message.result);
      return;
    }

    if (message.id !== undefined && message.method) {
      this.emit('serverRequest', message);
      this._handleServerRequest(message);
      return;
    }

    if (message.method) this.emit('notification', message);
  }

  async _handleServerRequest(message) {
    if (!this.serverRequestHandler) {
      this._respondSafely(message.id, null, { code: -32601, message: '客户端未配置此服务端请求的处理器：' + message.method });
      return;
    }
    try {
      const result = await this.serverRequestHandler(message);
      this._respondSafely(message.id, result === undefined ? {} : result);
    } catch (error) {
      this._respondSafely(message.id, null, { code: -32000, message: String(error && error.message || error || '服务端请求处理失败') });
    }
  }

  _respondSafely(id, result, error) {
    try {
      this.respond(id, result, error);
      return true;
    } catch (writeError) {
      if (!this.stopping) this.emit('warning', writeError);
      return false;
    }
  }

  async interrupt(threadId, turnId) {
    return this.request('turn/interrupt', { threadId, turnId }, { retryOverload: false });
  }

  async steer(threadId, turnId, input) {
    const text = String(input || '').trim();
    if (!threadId || !turnId || !text) throw new TypeError('steer 需要线程编号、活动回合编号和非空追加要求');
    return this.request('turn/steer', {
      threadId: String(threadId), expectedTurnId: String(turnId), input: [{ type: 'text', text }]
    }, { retryOverload: false });
  }

  forkThread(params) {
    if (!params || !params.threadId) throw new TypeError('forkThread 缺少 threadId');
    return this.request('thread/fork', { ...params, threadId: String(params.threadId) });
  }

  getGoal(threadId) {
    if (!threadId) throw new TypeError('getGoal 缺少 threadId');
    return this.request('thread/goal/get', { threadId: String(threadId) });
  }

  setGoal(threadId, objective, tokenBudget) {
    const text = String(objective || '').trim();
    if (!threadId || !text || text.length > 4000) throw new TypeError('目标必须为 1～4000 个字符');
    const params = { threadId: String(threadId), objective: text, status: 'active' };
    if (tokenBudget !== undefined && tokenBudget !== null) {
      if (!Number.isSafeInteger(tokenBudget) || tokenBudget <= 0) throw new TypeError('目标词元预算必须是正整数');
      params.tokenBudget = tokenBudget;
    }
    return this.request('thread/goal/set', params);
  }

  clearGoal(threadId) {
    if (!threadId) throw new TypeError('clearGoal 缺少 threadId');
    return this.request('thread/goal/clear', { threadId: String(threadId) });
  }

  compactThread(threadId) {
    if (!threadId) throw new TypeError('compactThread 缺少 threadId');
    return this.request('thread/compact/start', { threadId: String(threadId) });
  }

  startReview(threadId, target, delivery = 'inline') {
    if (!threadId || !target || typeof target !== 'object') throw new TypeError('startReview 缺少线程或审查目标');
    return this.request('review/start', { threadId: String(threadId), target, delivery: delivery === 'detached' ? 'detached' : 'inline' });
  }

  async capabilityCenter(options = {}) {
    const cwd = options.cwd || this.cwd;
    const threadId = options.threadId || undefined;
    const force = options.force === true;
    const providerCapabilitiesParams = options.providerCapabilitiesParams && typeof options.providerCapabilitiesParams === 'object'
      ? { ...options.providerCapabilitiesParams }
      : {};
    const settled = await Promise.allSettled([
      this.request('configRequirements/read'),
      this.request('modelProvider/capabilities/read', providerCapabilitiesParams),
      this.request('app/list', { limit: 100, ...(threadId ? { threadId } : {}), forceRefetch: force }),
      this.request('app/installed', { ...(threadId ? { threadId } : {}), forceRefresh: force }),
      this.request('skills/list', { cwds: [cwd], forceReload: force }),
      this.request('mcpServerStatus/list', { limit: 100, detail: 'toolsAndAuthOnly', ...(threadId ? { threadId } : {}) })
    ]);
    const names = ['requirements', 'providerCapabilities', 'apps', 'installedApps', 'skills', 'mcp'];
    const values = {};
    const supported = {};
    const errors = {};
    settled.forEach((item, index) => {
      const name = names[index];
      supported[name] = item.status === 'fulfilled' || !(item.reason instanceof CodexProtocolError && item.reason.code === -32601);
      if (item.status === 'fulfilled') values[name] = item.value;
      else errors[name] = { code: item.reason && item.reason.code, message: String(item.reason && item.reason.message || item.reason) };
    });
    return { protocol: this.serverInfo, ...values, supported, errors, productionPluginManagement: false };
  }

  setSkillEnabled(skillPath, enabled) {
    const value = String(skillPath || '').trim();
    if (!value) throw new TypeError('技能配置必须使用 skills/list 返回的 SKILL.md 路径');
    return this.request('skills/config/write', { path: value, enabled: enabled === true });
  }

  archiveThread(threadId) {
    if (!threadId) throw new TypeError('archiveThread 缺少 threadId');
    return this.request('thread/archive', { threadId: String(threadId) });
  }

  unarchiveThread(threadId) {
    if (!threadId) throw new TypeError('unarchiveThread 缺少 threadId');
    return this.request('thread/unarchive', { threadId: String(threadId) });
  }

  unsubscribeThread(threadId) {
    if (!threadId) throw new TypeError('unsubscribeThread 缺少 threadId');
    return this.request('thread/unsubscribe', { threadId: String(threadId) });
  }

  deleteThread(threadId, options = {}) {
    if (!threadId) throw new TypeError('deleteThread 缺少 threadId');
    if (options.confirmed !== true) throw new TypeError('永久删除线程前必须传入 { confirmed: true }');
    return this.request('thread/delete', { threadId: String(threadId) }, { retryOverload: false });
  }

  loginMcp(name, threadId) {
    const value = String(name || '').trim();
    if (!value) throw new TypeError('loginMcp 缺少 MCP 服务名称');
    return this.request('mcpServer/oauth/login', { name: value, ...(threadId ? { threadId: String(threadId) } : {}) });
  }

  diagnostics() {
    return { ready: this.ready, command: this.command, args: this.args.slice(), cwd: this.cwd, serverInfo: this.serverInfo, stderrTail: this.stderr.toString('utf8') };
  }

  stop() {
    this.stopping = true;
    const error = new Error('Codex App Server 已停止');
    this._rejectPending(error);
    this._terminateChild(this.child);
  }

  _fatal(error) {
    const failure = error instanceof Error ? error : new Error(String(error || 'Codex App Server 连接失败'));
    this._rejectPending(failure);
    this.ready = false;
    this.emit('fatal', failure);
  }

  _rejectPending(error) {
    for (const item of this.pending.values()) {
      clearTimeout(item.timeout);
      item.reject(error);
    }
    this.pending.clear();
  }

  _terminateChild(child) {
    if (!child) return;
    this.expectedExits.add(child);
    try { if (child.stdin && !child.stdin.destroyed) child.stdin.end(); } catch (_) {}
    try { child.kill(); } catch (_) {}
    this._resetProcess(child);
  }

  _resetProcess(child) {
    if (child && this.child !== child) return;
    if (this.reader) {
      try { this.reader.close(); } catch (_) {}
    }
    this.reader = null;
    this.child = null;
    this.ready = false;
    this.startPromise = null;
    this.serverInfo = null;
  }
}

function positive(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

function executableError(error, command) {
  if (!error || !['EPERM', 'EACCES'].includes(error.code)) return error;
  const wrapped = new Error('Windows 阻止启动 Codex 可执行文件：' + command + '。请让用户重新选择可运行的 codex.exe；不要复制应用包文件或修改权限。');
  wrapped.code = error.code;
  wrapped.cause = error;
  return wrapped;
}

module.exports = { CodexAppServerClient, CodexProtocolError };
