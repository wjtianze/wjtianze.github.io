---
name: build-codex-app-server-apps
description: Build, refactor, test, package, or troubleshoot native desktop clients that integrate Codex App Server for authentication, threads, turns, approvals, tools, files, images, and streamed agent UI. Use for rich interactive App Server integrations; use the Codex SDK instead for CI, batch jobs, or non-interactive automation.
---

# Build Codex App Server Apps

Build a trusted native host around `codex app-server`, not an embedded ChatGPT webpage. Preserve the product's identity and expose only the Codex capabilities the installed version and effective policy actually allow.

## Product and maturity boundary

- Use App Server for rich interactive clients that need authentication, persisted threads, approvals, and streamed agent events. Use the Codex SDK for CI, batch jobs, and non-interactive automation.
- The official documentation currently labels the App Server command and WebSocket transport experimental and unsupported for production workloads. State that limitation in product and release decisions; do not present the protocol as a stable public API.
- Prefer the default local stdio transport for a native desktop host. WebSocket, Unix-socket, remote terminal UI, and remote Code Mode host paths require the additional experimental, authentication, and transport controls in [references/protocol-and-compatibility.md](references/protocol-and-compatibility.md).
- A hosted renderer must not directly own the App Server process, credentials, arbitrary filesystem access, or approval decisions. Keep those in the trusted host.

Use this boundary for a local desktop integration:

```text
renderer UI -> narrow preload or loopback API -> trusted native host -> stdio JSONL -> codex app-server
```

Read [references/protocol-and-compatibility.md](references/protocol-and-compatibility.md) before changing protocol code. Read [references/windows-runtime-and-security.md](references/windows-runtime-and-security.md) for Windows launch, login, local bridge, process, filesystem, or attachment work. Read [references/agent-ui.md](references/agent-ui.md) before changing the chat UI. Read [references/testing-and-release.md](references/testing-and-release.md) before declaring the integration ready.

## Workflow

### 1. Establish the real host boundary

Inspect the source of truth, packaging entrypoint, preload/IPC or loopback layer, renderer, file manager, current AI implementation, and generated copies. Preserve unrelated changes and do not patch generated artifacts as the source.

Decide the supported operating systems, executable discovery, renderer-to-host API, default `cwd`, readable and writable roots, approval UX, persistence ownership, packaging, and user-acceptance gate before implementation. Keep an existing API/web edition intact when the user asks for a separate Codex edition.

### 2. Pin semantics and wire shape to evidence

Open the current [official App Server documentation](https://learn.chatgpt.com/docs/app-server), then generate schemas from the exact Codex executable the product will launch:

```powershell
node scripts/snapshot-schema.js --out .codex-app-server-schema
```

Use the two sources for different questions:

- Official documentation determines current semantics, maturity labels, deprecations, and security warnings.
- Generated TypeScript and JSON Schema determine which methods, fields, enums, and required properties the installed executable accepts.

If they differ, version-gate the behavior or disable it with a truthful explanation. Do not guess legacy spellings, treat an undocumented generated field as universally supported, or expose a method that the official documentation still says not to use in production.

### 3. Implement the trusted client

Start from [assets/node/codex-app-server-client.js](assets/node/codex-app-server-client.js) for Node or Electron. Preserve these invariants in every language:

- spawn the verified executable directly with piped stdio, `windowsHide`, `shell: false`, bounded diagnostics, exit handling, timeouts, and rejection of pending requests;
- send one JSON object per line without a `jsonrpc` field;
- send exactly one `initialize`, await its response, then send the `initialized` notification before any other method;
- separate responses, notifications, and server-initiated requests by message shape, not arrival order;
- use unique request IDs and an initialization lock;
- retry only overload error `-32001`, with bounded exponential backoff and jitter;
- route events and pending requests by `threadId`, `turnId`, `itemId`, and request `id`; do not assume every notification contains every identifier;
- provide explicit trusted-host handlers for every supported server request and reject unknown requests with a JSON-RPC error instead of inventing an approval response.

Handle command/file approvals, permission subsets, user input, MCP elicitation, dynamic tools, external-token refresh, and attestation as different request types. Missing a required response can leave a turn waiting indefinitely.

### 4. Discover account, model, and policy state

- Read `account/read`; for user-owned ChatGPT login, use `account/login/start` with `chatgpt` or `chatgptDeviceCode`, open only the returned URL, and wait for completion notifications. Never read account files, cookies, credential stores, or token files directly.
- Read `model/list` and use each model's advertised reasoning efforts, default effort, input modalities, personality support, and default/hidden state. Do not hard-code model IDs.
- Treat answer-speed or service-tier controls as version-specific unless the generated schema and runtime model data both advertise the exact request and response fields. The current official model example does not make such a field part of the documented baseline.
- Read `configRequirements/read` before offering sandbox, approval, network, or feature settings. Read `modelProvider/capabilities/read` before claiming provider-specific tool support.
- Use `account/rateLimits/read`, `account/rateLimits/updated`, and `account/usage/read` for quota and activity. Do not describe subscription usage as an API balance or infer missing metrics.
- Treat configuration writes, skill enablement, marketplace changes, earned reset consumption, credit-notification email, external-agent import, and MCP OAuth as user-visible mutations with appropriate confirmation.

### 5. Implement real thread and turn lifecycles

- Create, resume, read, list, fork, name, archive, and unarchive threads through the corresponding server methods. Use `thread/delete` only after explicit destructive confirmation.
- Start work with `turn/start`. Use `turn/steer` only for the active turn and include `expectedTurnId`. Stop with `turn/interrupt` and retain already streamed items.
- Treat turn-level overrides as new defaults for later turns on that thread, except `outputSchema`, which applies only to the current turn.
- Use `thread/compact/start` and render the `contextCompaction` item; do not depend on deprecated `thread/compacted`.
- Use `review/start` for review and keep inline versus detached `reviewThreadId` distinct.
- Do not build new features on deprecated `thread/rollback`.
- Expose `thread/shellCommand` only as an explicit user action: it runs outside the sandbox with full access. Treat experimental `process/*` the same way and keep it disabled unless the product intentionally owns that risk.

### 6. Enforce permission and file boundaries

- Use only the permission shape accepted by the generated schema. Stable thread methods can use `sandbox`; turns and command execution use `sandboxPolicy`. Experimental named `permissions` profiles require the capability opt-in and `permissionProfile/list`; never send `permissions` together with `sandbox`.
- Default to the application's controlled workspace. Never silently expand to `dangerFullAccess` to make a request pass.
- App Server `fs/*` methods require absolute paths but are not a renderer authorization boundary. Validate and confine every renderer-provided path in the trusted host before calling them.
- Send only input item types accepted by the current schema. The documented baseline includes `text`, remote `image`, and `localImage`; explicit skill and app invocation use `skill` and `mention` items as documented.
- For non-image files, place validated files inside the allowed workspace and reference their path in text unless the installed schema explicitly supports another input type.
- Upload raw bytes to a local bridge, sanitize names, prevent traversal and reparse-point escapes, bound request sizes, and serve media only through a validated same-origin route.

### 7. Build a typed agent UI

Adapt the minimal scaffold in [assets/ui](assets/ui), then complete the product-specific Markdown, sanitization, accessibility, persistence, and host actions described in [references/agent-ui.md](references/agent-ui.md).

The UI must distinguish commentary and final answers, reasoning summaries, plans, commands, file changes, web search, MCP/app and collaboration tools, approvals, permission requests, warnings, review, compaction, and errors. Preserve per-conversation drafts, items, pending requests, settings, and scroll state. Do not dump raw protocol JSON, hidden prompts, secrets, or absolute paths into the conversation.

### 8. Verify without consuming user quota

Run the bundled fake-server smoke:

```powershell
node scripts/smoke-client.js
```

Then follow [references/testing-and-release.md](references/testing-and-release.md). Use a fake App Server or recorded fixtures for automated tests. Real ChatGPT login, real model turns, installation acceptance, publication, and release upload remain explicit user-owned gates.

## Done criteria

Do not call the integration ready until:

- the current official documentation and exact installed-version schemas have both been checked;
- handshake, interleaved message classes, server requests, overload, exit, restart, thread/turn routing, approvals, and capability fallback pass without real model usage;
- every feature in scope is either verified against the current server or visibly reported unavailable;
- destructive and outside-sandbox methods require deliberate user action;
- no credential, raw auth file, arbitrary file route, hidden prompt, or unauthenticated remote listener is exposed;
- the packaged artifact and its resources pass local checks and are held for explicit user acceptance before release.
