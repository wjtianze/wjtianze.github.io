---
name: build-codex-app-server-apps
description: Build, refactor, test, package, or troubleshoot native desktop applications that integrate Codex App Server with each user's own ChatGPT account. Use when replacing API-key AI or embedded AI webpages with Codex, implementing JSONL app-server clients, account login, model/reasoning/speed/usage controls, approvals, filesystem access, streamed reasoning and tool UI, images or attachments, Windows launchers, or a desktop-only Codex edition that must coexist with an API-backed web edition.
---

# Build Codex App Server Apps

Build a real desktop integration around `codex app-server`, not a web-page wrapper around ChatGPT. Preserve the host application's product identity while exposing Codex's account, model, agent, tool, filesystem, image, and usage capabilities through a narrow native bridge.

## Non-negotiable architecture

Use this boundary:

```text
renderer UI -> preload or loopback API -> native host -> stdio JSONL -> codex app-server
```

- Keep `codex app-server` and ChatGPT authentication in the native host. Never expose the raw process, credentials, account files, or unrestricted local-file reads to the renderer.
- Treat this as desktop-only. A normal hosted webpage cannot safely spawn the local server or own its callback. Keep the browser edition on its existing API provider.
- Let every user sign in with their own ChatGPT account. Never pool, bundle, scrape, export, or resell a developer account.
- Default the Codex working directory and writable roots to the application's own file-manager workspace unless the product explicitly asks for another folder.
- Keep the existing API edition intact when creating a Codex edition. Use an explicit suffix such as `vx.x-codex` and label the web/API and desktop/Codex paths separately.

Read [references/protocol-and-compatibility.md](references/protocol-and-compatibility.md) before editing the protocol client. Read [references/windows-runtime-and-security.md](references/windows-runtime-and-security.md) for Windows launch, login, local bridge, filesystem, and attachment work. Read [references/agent-ui.md](references/agent-ui.md) before changing the chat UI. Read [references/testing-and-release.md](references/testing-and-release.md) before declaring the integration ready.

## Workflow

### 1. Establish the host boundary

Inspect the real source, packaging entrypoint, preload/IPC or loopback layer, renderer, file manager, and current AI implementation. Identify generated copies and do not patch them as the source. Preserve unrelated user changes.

Write down these decisions before implementation:

- desktop host and supported operating systems;
- Codex executable discovery strategy;
- renderer-to-host API surface;
- default `cwd`, readable roots, and writable roots;
- approval policy and visible approval fallback;
- ordinary API/web edition that must remain available;
- packaging and user-acceptance gate.

### 2. Pin behavior to the installed Codex version

Do not copy request fields from memory. Generate version-matched schemas without consuming account usage:

```powershell
node scripts/snapshot-schema.js --out .codex-app-server-schema
```

If the executable is not directly runnable from the shell, reuse the product's already verified executable locator and generate schemas from the same native host context. Compare the generated schema with all requests the integration sends.

Rules:

- Use stable methods unless an actual feature requires `experimentalApi: true`.
- Send exactly one `initialize` request, await success, then send `initialized`; send nothing else first.
- Treat stdio as newline-delimited JSON. Omit the `jsonrpc` field.
- Separate responses, notifications, and server-initiated requests by shape, not by arrival order.
- Do not mix `permissions`, `permissionProfile`, `sandbox`, or `sandboxPolicy` shapes from different versions. Use only fields accepted by the generated schema and runtime capability discovery.
- On an enum or removed-field error, retry only with a candidate explicitly advertised by the current schema, a capability method, or the server error. Never guess a chain of legacy values.

### 3. Implement the native client

Start from [assets/node/codex-app-server-client.js](assets/node/codex-app-server-client.js) when the host is Node or Electron. Keep equivalent invariants in other languages:

- direct child-process spawn with `windowsHide`, piped stdin/stdout/stderr, a bounded stderr diagnostic buffer, exit handling, request timeouts, and pending-request rejection;
- monotonically unique request IDs and one JSON object per output line;
- initialization lock so concurrent callers share one startup promise;
- bounded retry with exponential backoff and jitter only for overload error `-32001`;
- explicit handler for every server request, especially command, file-change, permission, user-input, MCP, and external-token refresh requests;
- `turn/interrupt` for Stop, while retaining already streamed output;
- thread IDs, active turn IDs, items, usage, and approval state scoped per conversation.

Never display an unhandled protocol exception as the whole product experience. Preserve the technical details in diagnostics and show the user an actionable Chinese message such as“Codex 版本与当前请求字段不兼容，请更新应用或重新生成协议结构”。

### 4. Discover account and model capabilities

- Call `account/read` on startup and after `account/updated`.
- Start managed browser login with `account/login/start` type `chatgpt`; open only the returned `authUrl`; wait for `account/login/completed`. Offer device-code login when browser callbacks are unreliable.
- Provide cancel-login and logout actions. Never read `auth.json`, browser cookies, the Windows credential store, or token files directly.
- Read quota windows from `account/rateLimits/read` and usage from `account/usage/read`; show reset times and used/remaining percentages without inventing a currency balance.
- Populate the model picker from `model/list`. Populate reasoning choices from the selected model's `supportedReasoningEfforts`, choose `defaultReasoningEffort`, and honor `inputModalities`.
- Show a speed selector only when the installed version advertises a supported service tier. Warn that faster service can consume included usage or credits more quickly.
- Use “词元” for model-token counts in Chinese product copy; keep literal protocol field names unchanged in code.

### 5. Build a Codex-native agent UI

Copy or adapt [assets/ui/agent-chat.html](assets/ui/agent-chat.html), [assets/ui/agent-chat.css](assets/ui/agent-chat.css), and [assets/ui/agent-chat.js](assets/ui/agent-chat.js). The UI must make agent activity understandable without dumping protocol JSON:

- final answer and agent activity are visually distinct;
- each reasoning summary step starts on its own line;
- command, file change, web search, MCP/app, image view, plan, and approval items have typed cards with started/completed/failed states;
- detailed command output and diffs are collapsed by default;
- account, model, reasoning effort, optional speed tier, quota, and workspace are visible but do not dominate the conversation;
- Send/Stop reflects the selected conversation, not whichever turn emitted the newest global event;
- switching away from a generating conversation preserves every streamed item and restores it on return;
- auto-scroll follows only when the reader is already near the bottom; otherwise preserve their viewport;
- images render through a validated same-origin media route, and generated images include a working in-app open/save action;
- SVG/HTML previews are sandboxed, size-bounded to the message column, stable while streaming, and never force an internal scrollbar merely to show the whole visualization.

Do not show hidden prompt context, cited knowledge-point payloads, question-answer keys, local file paths, or bridge tokens as visible user messages.

### 6. Handle files and images safely

- Send images as supported `image` or `localImage` inputs.
- For non-image files, save them inside the permitted workspace and provide a text item containing the validated path and task; do not invent a generic file input type.
- Use raw binary upload to the local bridge rather than Base64 JSON. Sanitize names, generate collision-resistant filenames, reject path traversal and reparse-point escapes, and restrict media-serving extensions.
- Estimate the actual UTF-8 serialized request before sending. If the product uses a 7 MB soft ceiling, progressively compress images while retaining every required image; only omit optional bulk text such as interactive-demo source after the minimum image budget still exceeds the ceiling. Return a JSON `413` with a readable explanation instead of a connection reset or“Failed to fetch”。

### 7. Verify without using the user's quota

Run the bundled fake-server smoke:

```powershell
node scripts/smoke-client.js
```

Then follow [references/testing-and-release.md](references/testing-and-release.md). Automated tests must use a fake App Server or recorded protocol fixtures. Live ChatGPT login, quota-consuming turns, installation, external publication, and release upload are user-owned acceptance gates.

## Latest integration contract

Treat the installed Codex version as the source of truth. Before changing a request or event handler, regenerate the local schema and compare the exact method, field names, enum values, and required fields. Never “fix” a protocol error by trying several legacy spellings.

### Common failure traps

- `initialize` and `initialized` are a handshake pair. Do not call `account/read`, `model/list`, `thread/start`, or `turn/start` before initialization succeeds, and do not initialize the same process twice.
- `codex app-server` is bidirectional JSONL. A server request is not a notification: it has an `id` and requires a response with the same `id`. Missing a permission, file-change, command, user-input, MCP, or token-refresh response leaves the turn apparently frozen.
- Do not copy permission fields between versions. In particular, never send `workspace-write`, `workspaceWrite.readOnlyAccess`, or a guessed `sandboxPolicy`/`permissions` object. If the runtime says a legacy read-only field was removed, use the current schema's `permissionProfile` or advertised restricted-read profile. If the user explicitly enables full access, pass only the exact current `dangerFullAccess`-style profile advertised by the schema and show the risk before applying it.
- `spawn EPERM` is a Windows executable-launch problem, not proof that Codex is missing. Try the user-selected verified executable and the host process environment; do not copy Store/MSIX files, change ACLs, or ask for administrator access merely to bypass it.
- A closed command window must not own the server lifetime. Use a detached/native host process or Electron main process, persist a random loopback route and port in a user-readable status file, and open the page only after the bridge reports ready.
- `Failed to fetch` must be classified before retrying: bridge not ready, wrong origin, oversized request, rejected path, exited child process, or App Server error. Return structured JSON errors with the cause and a recovery action; never hide the original stderr tail.

### Prompt and data contract

Every request must have exactly four top-level prompt blocks with explicit delimiters: `L7_SYSTEM_LEARNING_MATERIALS`, `L7_USER_PROMPT`, `L7_USER_REFERENCES`, and `L7_AI_RESPONSE_RULES`. Keep the user's words separate from hidden citations and attachments. Within system learning materials, use named subsections for product/material metadata, knowledge points, questions and answer state, interactive demos, source text, and historical conversations. Current-turn history may remain as ordered `user`/`assistant` messages; other conversations and soft-deleted conversations should be retained as hidden history snapshots. Do not display any of these payloads as fake user bubbles.

For educational products, enforce “no answer leakage before submission” in the response-rules block, and enforce answer-position balancing in the question-generation block. A post-parse normalizer should shuffle option content, remap `answer`, and update letter references in explanations so model habits cannot create a predictable answer key.

### Capability-backed product features

Expose only features discovered from the current account/model capabilities:

- ChatGPT login, logout, account status, plan, rate-limit windows, reset times, and usage; never invent an API balance for subscription usage.
- Dynamic model selection, supported reasoning efforts, default effort, input modalities, optional speed/service tiers, and per-request snapshots of all settings.
- Threads, turns, resume, steer, interrupt, background generation, retry/continue, token usage, reasoning summaries, plans, commands, file changes, web/MCP/app tools, images, approvals, and user-input requests.
- A controlled application workspace/file manager, validated attachments, local images, generated-image copying, same-origin media routes, and isolated SVG/HTML previews.
- Persistent package-local archives for messages, drafts, attachments, model settings, question/answer state, demos, citations, translations, usage, and soft-deleted conversations. “Delete conversation” hides it; “clear archive” is the destructive operation.

### Agent UI design contract

Use a stable five-level layout: conversation tabs; compact capability bar; scrollable message/activity area; attachment/reference/input area; lightweight token/usage footer. Keep the product's identity and ordinary API edition intact, and label desktop/Codex and web/API paths distinctly.

- Separate final answer, reasoning summary, plan, tool call, tool result, approval, warning, and error into typed cards. Every activity step is its own line/block; do not concatenate streamed summaries.
- Show started, running, completed, failed, interrupted, and waiting-for-approval states. Collapse long commands, diffs, and tool output by default; expose an inspect/copy/open action instead of dumping raw protocol JSON.
- Send/Stop/Continue belongs to the selected conversation. Different conversations may run in parallel; switching tabs must preserve streamed items, drafts, pending approvals, scroll position, and the exact button state.
- Auto-scroll only when the user is already near the bottom. If the user has scrolled up, keep the viewport fixed while content, translations, images, or visualizations arrive.
- Keep account/model/effort/speed/workspace controls visible but compact. Do not expose obsolete temperature/top-p controls, raw bridge tokens, local absolute paths, hidden prompts, answer keys, or citation payloads in normal UI.
- Render Markdown and formulas through trusted sanitization. Middle-click any formula to copy its original LaTeX, including deep children such as a radical or fraction line.
- Render SVG/HTML in a sandboxed same-origin frame bounded by the message column. During streaming, drop the incomplete final line, reuse the same frame, lock the first valid size, and never introduce an internal scrollbar merely to show the drawing. Keep source and a readable failure fallback.
- Images must have a working in-app open/save action and a validated same-origin route; external links go through a protocol-checked host action, never `about:blank#blocked`.

### Approval and filesystem UX

Default to the application's file-manager workspace. Make read-only, workspace-write, external-sandbox, and full-access profiles visibly distinct and explain what each permits. Approval cards should show the command, working directory, files, network target, and risk; offer approve-once, approve-for-scope, reject, and cancel where the current protocol supports them. A product may automate only an explicitly selected safe policy. Never silently upgrade to full access to make a request succeed.

### Release gate

Before calling an integration ready, run schema generation, fake-server protocol smoke, project tests, packaged-resource checks, and a manual UI pass covering login, model/effort/speed controls, quota, parallel conversations, Stop/Continue, tool approvals, file/image attachment, generated images, SVG/HTML streaming, archive reload, and clear-archive behavior. Hold real login, user approval, installer acceptance, publication, and release upload for the user's explicit acceptance.

## Done criteria

Do not call the work complete until all are true:

- current-version schema generation or equivalent capability proof passes;
- login, logout, models, reasoning, optional speed, rate limits, turns, Stop, approvals, tools, images, and per-conversation restoration are covered;
- web/API and desktop/Codex editions coexist with truthful platform labels;
- no API key, account token, cookie, raw auth file, arbitrary file route, or remote unauthenticated App Server is exposed;
- fake-server and project regressions pass without consuming user quota;
- packaged desktop artifacts are tested locally and held for explicit user acceptance before public release.
