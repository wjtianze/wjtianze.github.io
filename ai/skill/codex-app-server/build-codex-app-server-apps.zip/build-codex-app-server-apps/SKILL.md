---
name: build-codex-app-server-apps
description: Build, refactor, test, package, or troubleshoot native desktop applications that integrate Codex App Server with each user's own ChatGPT account. Use when replacing API-key AI or embedded AI webpages with Codex, implementing JSONL app-server clients, account login, model/reasoning/speed/usage controls, approvals, filesystem access, streamed reasoning and tool UI, images or attachments, Windows launchers, or a desktop-only Codex edition that must coexist with an API-backed web edition.
---

# Build Codex App Server Apps

Build a real desktop integration around `codex app-server`, not a web-page wrapper around ChatGPT. Preserve the host application's product identity while exposing Codex's account, model, agent, tool, filesystem, image, and usage capabilities through a narrow native bridge.

## Non-negotiable architecture

Use this boundary:

```text
renderer UI -> preload or loopback API -> native host -> stdio JSONL -> codex app-server
```

- Keep `codex app-server` and ChatGPT authentication in the native host. Never expose the raw process, credentials, account files, or unrestricted local-file reads to the renderer.
- Treat this as desktop-only. A normal hosted webpage cannot safely spawn the local server or own its callback. Keep the browser edition on its existing API provider.
- Let every user sign in with their own ChatGPT account. Never pool, bundle, scrape, export, or resell a developer account.
- Default the Codex working directory and writable roots to the application's own file-manager workspace unless the product explicitly asks for another folder.
- Keep the existing API edition intact when creating a Codex edition. Use an explicit suffix such as `vx.x-codex` and label the web/API and desktop/Codex paths separately.

Read [references/protocol-and-compatibility.md](references/protocol-and-compatibility.md) before editing the protocol client. Read [references/windows-runtime-and-security.md](references/windows-runtime-and-security.md) for Windows launch, login, local bridge, filesystem, and attachment work. Read [references/agent-ui.md](references/agent-ui.md) before changing the chat UI. Read [references/testing-and-release.md](references/testing-and-release.md) before declaring the integration ready.

## Workflow

### 1. Establish the host boundary

Inspect the real source, packaging entrypoint, preload/IPC or loopback layer, renderer, file manager, and current AI implementation. Identify generated copies and do not patch them as the source. Preserve unrelated user changes.

Write down these decisions before implementation:

- desktop host and supported operating systems;
- Codex executable discovery strategy;
- renderer-to-host API surface;
- default `cwd`, readable roots, and writable roots;
- approval policy and visible approval fallback;
- ordinary API/web edition that must remain available;
- packaging and user-acceptance gate.

### 2. Pin behavior to the installed Codex version

Do not copy request fields from memory. Generate version-matched schemas without consuming account usage:

```powershell
node scripts/snapshot-schema.js --out .codex-app-server-schema
```

If the executable is not directly runnable from the shell, reuse the product's already verified executable locator and generate schemas from the same native host context. Compare the generated schema with all requests the integration sends.

Rules:

- Use stable methods unless an actual feature requires `experimentalApi: true`.
- Send exactly one `initialize` request, await success, then send `initialized`; send nothing else first.
- Treat stdio as newline-delimited JSON. Omit the `jsonrpc` field.
- Separate responses, notifications, and server-initiated requests by shape, not by arrival order.
- Do not mix `permissions`, `permissionProfile`, `sandbox`, or `sandboxPolicy` shapes from different versions. Use only fields accepted by the generated schema and runtime capability discovery.
- On an enum or removed-field error, retry only with a candidate explicitly advertised by the current schema, a capability method, or the server error. Never guess a chain of legacy values.

### 3. Implement the native client

Start from [assets/node/codex-app-server-client.js](assets/node/codex-app-server-client.js) when the host is Node or Electron. Keep equivalent invariants in other languages:

- direct child-process spawn with `windowsHide`, piped stdin/stdout/stderr, a bounded stderr diagnostic buffer, exit handling, request timeouts, and pending-request rejection;
- monotonically unique request IDs and one JSON object per output line;
- initialization lock so concurrent callers share one startup promise;
- bounded retry with exponential backoff and jitter only for overload error `-32001`;
- explicit handler for every server request, especially command, file-change, permission, user-input, MCP, and external-token refresh requests;
- `turn/interrupt` for Stop, while retaining already streamed output;
- thread IDs, active turn IDs, items, usage, and approval state scoped per conversation.

Never display an unhandled protocol exception as the whole product experience. Preserve the technical details in diagnostics and show the user an actionable Chinese message such as“Codex 版本与当前请求字段不兼容，请更新应用或重新生成协议结构”。

### 4. Discover account and model capabilities

- Call `account/read` on startup and after `account/updated`.
- Start managed browser login with `account/login/start` type `chatgpt`; open only the returned `authUrl`; wait for `account/login/completed`. Offer device-code login when browser callbacks are unreliable.
- Provide cancel-login and logout actions. Never read `auth.json`, browser cookies, the Windows credential store, or token files directly.
- Read quota windows from `account/rateLimits/read` and usage from `account/usage/read`; show reset times and used/remaining percentages without inventing a currency balance.
- Populate the model picker from `model/list`. Populate reasoning choices from the selected model's `supportedReasoningEfforts`, choose `defaultReasoningEffort`, and honor `inputModalities`.
- Show a speed selector only when the installed version advertises a supported service tier. Warn that faster service can consume included usage or credits more quickly.
- Use “词元” for model-token counts in Chinese product copy; keep literal protocol field names unchanged in code.

### 5. Build a Codex-native agent UI

Copy or adapt [assets/ui/agent-chat.html](assets/ui/agent-chat.html), [assets/ui/agent-chat.css](assets/ui/agent-chat.css), and [assets/ui/agent-chat.js](assets/ui/agent-chat.js). The UI must make agent activity understandable without dumping protocol JSON:

- final answer and agent activity are visually distinct;
- each reasoning summary step starts on its own line;
- command, file change, web search, MCP/app, image view, plan, and approval items have typed cards with started/completed/failed states;
- detailed command output and diffs are collapsed by default;
- account, model, reasoning effort, optional speed tier, quota, and workspace are visible but do not dominate the conversation;
- Send/Stop reflects the selected conversation, not whichever turn emitted the newest global event;
- switching away from a generating conversation preserves every streamed item and restores it on return;
- auto-scroll follows only when the reader is already near the bottom; otherwise preserve their viewport;
- images render through a validated same-origin media route, and generated images include a working in-app open/save action;
- SVG/HTML previews are sandboxed, size-bounded to the message column, stable while streaming, and never force an internal scrollbar merely to show the whole visualization.

Do not show hidden prompt context, cited knowledge-point payloads, question-answer keys, local file paths, or bridge tokens as visible user messages.

### 6. Handle files and images safely

- Send images as supported `image` or `localImage` inputs.
- For non-image files, save them inside the permitted workspace and provide a text item containing the validated path and task; do not invent a generic file input type.
- Use raw binary upload to the local bridge rather than Base64 JSON. Sanitize names, generate collision-resistant filenames, reject path traversal and reparse-point escapes, and restrict media-serving extensions.
- Estimate the actual UTF-8 serialized request before sending. If the product uses a 7 MB soft ceiling, progressively compress images while retaining every required image; only omit optional bulk text such as interactive-demo source after the minimum image budget still exceeds the ceiling. Return a JSON `413` with a readable explanation instead of a connection reset or“Failed to fetch”。

### 7. Verify without using the user's quota

Run the bundled fake-server smoke:

```powershell
node scripts/smoke-client.js
```

Then follow [references/testing-and-release.md](references/testing-and-release.md). Automated tests must use a fake App Server or recorded protocol fixtures. Live ChatGPT login, quota-consuming turns, installation, external publication, and release upload are user-owned acceptance gates.

## Done criteria

Do not call the work complete until all are true:

- current-version schema generation or equivalent capability proof passes;
- login, logout, models, reasoning, optional speed, rate limits, turns, Stop, approvals, tools, images, and per-conversation restoration are covered;
- web/API and desktop/Codex editions coexist with truthful platform labels;
- no API key, account token, cookie, raw auth file, arbitrary file route, or remote unauthenticated App Server is exposed;
- fake-server and project regressions pass without consuming user quota;
- packaged desktop artifacts are tested locally and held for explicit user acceptance before public release.
