'use strict';

const path = require('node:path');
const readline = require('node:readline');

const reader = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
let initialized = false;
let overloadCount = 0;
let alwaysOverloadCount = 0;
let nextThread = 1;
let nextTurn = 1;
let nextLogin = 1;
let pendingProbe = null;
let pendingLogin = null;
let account = { type: 'chatgpt', email: 'fake@example.invalid', planType: 'plus' };
let currentGoal = null;
const pendingApprovals = new Map();
const activeTurns = new Map();
const archivedThreads = new Set();

function send(message) {
  process.stdout.write(JSON.stringify(message) + '\n');
}

function response(id, result) {
  send({ id, result: result === undefined ? {} : result });
}

function notify(method, params) {
  send({ method, params: params || {} });
}

function turnKey(threadId, turnId) {
  return String(threadId) + ':' + String(turnId);
}

function runTurn(threadId, turnId, mode) {
  const suffix = turnId.replace(/[^a-z0-9_-]/gi, '_');
  const reasonId = 'reason-' + suffix;
  notify('turn/started', { threadId, turn: { id: turnId, status: 'inProgress', items: [] } });
  notify('item/started', { threadId, turnId, item: { id: reasonId, type: 'reasoning', summary: [], content: [] } });
  notify('item/reasoning/summaryTextDelta', { threadId, turnId, itemId: reasonId, summaryIndex: 0, delta: '检查项目结构' });
  notify('item/reasoning/summaryPartAdded', { threadId, turnId, itemId: reasonId, summaryIndex: 1 });
  notify('item/reasoning/summaryTextDelta', { threadId, turnId, itemId: reasonId, summaryIndex: 1, delta: '运行零额度测试' });
  notify('item/completed', { threadId, turnId, item: { id: reasonId, type: 'reasoning', summary: ['检查项目结构', '运行零额度测试'], content: [] } });

  const kind = mode === 'file-approval' ? 'file' : 'command';
  const itemId = (kind === 'file' ? 'file-' : 'cmd-') + suffix;
  const approvalId = 'approval-' + suffix;
  if (kind === 'file') {
    notify('item/started', { threadId, turnId, item: { id: itemId, type: 'fileChange', changes: [{ path: 'fixture.txt', kind: 'update' }], status: 'inProgress' } });
    send({ id: approvalId, method: 'item/fileChange/requestApproval', params: { threadId, turnId, itemId, reason: '写入离线夹具', grantRoot: process.cwd(), availableDecisions: ['accept', 'acceptForSession', 'decline', 'cancel'] } });
  } else {
    notify('item/started', { threadId, turnId, item: { id: itemId, type: 'commandExecution', command: 'node --check app.js', cwd: process.cwd(), status: 'inProgress' } });
    send({ id: approvalId, method: 'item/commandExecution/requestApproval', params: { threadId, turnId, itemId, command: 'node --check app.js', cwd: process.cwd(), availableDecisions: ['accept', 'acceptForSession', 'decline', 'cancel'] } });
  }
  const pending = { approvalId, threadId, turnId, itemId, kind };
  pendingApprovals.set(approvalId, pending);
  activeTurns.set(turnKey(threadId, turnId), pending);
}

function approvalAccepted(result) {
  const decision = result && result.decision;
  return decision === 'accept' || decision === 'acceptForSession' || !!(decision && typeof decision === 'object' && decision.acceptWithExecpolicyAmendment);
}

function finishApproval(pending, result) {
  pendingApprovals.delete(pending.approvalId);
  activeTurns.delete(turnKey(pending.threadId, pending.turnId));
  const { approvalId, threadId, turnId, itemId, kind } = pending;
  notify('serverRequest/resolved', { threadId, requestId: approvalId });
  if (!approvalAccepted(result)) {
    if (kind === 'file') notify('item/completed', { threadId, turnId, item: { id: itemId, type: 'fileChange', changes: [{ path: 'fixture.txt', kind: 'update' }], status: 'declined' } });
    else notify('item/completed', { threadId, turnId, item: { id: itemId, type: 'commandExecution', command: 'node --check app.js', cwd: process.cwd(), status: 'declined', exitCode: null, aggregatedOutput: '' } });
    notify('turn/completed', { threadId, turn: { id: turnId, status: 'completed', items: [], error: null } });
    return;
  }

  if (kind === 'file') notify('item/completed', { threadId, turnId, item: { id: itemId, type: 'fileChange', changes: [{ path: 'fixture.txt', kind: 'update' }], status: 'completed' } });
  else notify('item/completed', { threadId, turnId, item: { id: itemId, type: 'commandExecution', command: 'node --check app.js', cwd: process.cwd(), status: 'completed', exitCode: 0, aggregatedOutput: '' } });

  const suffix = turnId.replace(/[^a-z0-9_-]/gi, '_');
  const mcpId = 'mcp-' + suffix;
  notify('item/started', { threadId, turnId, item: { id: mcpId, type: 'mcpToolCall', server: 'fixture', tool: 'lookup', status: 'inProgress', arguments: {}, result: null, error: null } });
  notify('item/completed', { threadId, turnId, item: { id: mcpId, type: 'mcpToolCall', server: 'fixture', tool: 'lookup', status: 'completed', arguments: {}, result: { content: [{ type: 'text', text: 'fixture result' }] }, error: null } });
  const imageId = 'image-' + suffix;
  notify('item/started', { threadId, turnId, item: { id: imageId, type: 'imageView', path: path.join(process.cwd(), 'fake-view.png') } });
  notify('item/completed', { threadId, turnId, item: { id: imageId, type: 'imageView', path: path.join(process.cwd(), 'fake-view.png') } });
  const collabId = 'collab-' + suffix;
  notify('item/started', { threadId, turnId, item: { id: collabId, type: 'collabToolCall', tool: 'spawnAgent', status: 'inProgress', senderThreadId: threadId, receiverThreadId: null, newThreadId: null } });
  notify('item/completed', { threadId, turnId, item: { id: collabId, type: 'collabToolCall', tool: 'spawnAgent', status: 'completed', senderThreadId: threadId, receiverThreadId: null, newThreadId: 'thread-child' } });
  const answerId = 'answer-' + suffix;
  notify('item/started', { threadId, turnId, item: { id: answerId, type: 'agentMessage', text: '', phase: 'final_answer' } });
  notify('item/agentMessage/delta', { threadId, turnId, itemId: answerId, delta: '测试完成。' });
  notify('item/completed', { threadId, turnId, item: { id: answerId, type: 'agentMessage', text: '测试完成。', phase: 'final_answer' } });
  notify('thread/tokenUsage/updated', { threadId, tokenUsage: { total: { inputTokens: 12, cachedInputTokens: 4, outputTokens: 8, reasoningOutputTokens: 3, totalTokens: 20 } } });
  notify('turn/completed', { threadId, turn: { id: turnId, status: 'completed', items: [], error: null } });
}

function interruptTurn(threadId, turnId) {
  const pending = activeTurns.get(turnKey(threadId, turnId));
  if (pending) {
    pendingApprovals.delete(pending.approvalId);
    activeTurns.delete(turnKey(threadId, turnId));
    notify('serverRequest/resolved', { threadId, requestId: pending.approvalId });
    if (pending.kind === 'file') notify('item/completed', { threadId, turnId, item: { id: pending.itemId, type: 'fileChange', changes: [{ path: 'fixture.txt', kind: 'update' }], status: 'failed' } });
    else notify('item/completed', { threadId, turnId, item: { id: pending.itemId, type: 'commandExecution', command: 'node --check app.js', cwd: process.cwd(), status: 'failed', exitCode: null, aggregatedOutput: '' } });
  }
  notify('turn/completed', { threadId, turn: { id: turnId, status: 'interrupted', items: [], error: null } });
}

reader.on('line', line => {
  let message;
  try { message = JSON.parse(line); } catch (_) { return; }

  if (pendingApprovals.has(message.id) && (Object.prototype.hasOwnProperty.call(message, 'result') || message.error)) {
    const pending = pendingApprovals.get(message.id);
    return finishApproval(pending, message.result || { decision: 'decline' });
  }
  if (message.id === 'probe-1' && (Object.prototype.hasOwnProperty.call(message, 'result') || message.error)) {
    const requestId = pendingProbe;
    pendingProbe = null;
    return response(requestId, { clientResult: message.result || null, clientError: message.error || null });
  }

  if (message.method === 'initialize') {
    if (initialized) return send({ id: message.id, error: { code: -32000, message: 'Already initialized' } });
    if (process.env.FAKE_INIT_ERROR === '1') return send({ id: message.id, error: { code: -32602, message: 'Fixture rejected initialization' } });
    initialized = true;
    return response(message.id, { userAgent: 'fake-app-server/1.0', codexHome: process.cwd(), platformFamily: 'windows', platformOs: 'windows' });
  }
  if (message.method === 'initialized') return;
  if (!initialized) return send({ id: message.id, error: { code: -32000, message: 'Not initialized' } });

  if (message.method === 'model/list') return response(message.id, { data: [{ id: 'fake-sol', model: 'fake-sol', displayName: 'Fake Sol', isDefault: true, hidden: false, defaultReasoningEffort: 'medium', supportedReasoningEfforts: [{ reasoningEffort: 'low', description: '快速' }, { reasoningEffort: 'medium', description: '均衡' }, { reasoningEffort: 'high', description: '深入' }], inputModalities: ['text', 'image'], supportsPersonality: true }], nextCursor: null });
  if (message.method === 'modelProvider/capabilities/read') return response(message.id, { namespaceTools: true, imageGeneration: true, webSearch: true });
  if (message.method === 'account/read') return response(message.id, { account, requiresOpenaiAuth: true });
  if (message.method === 'account/logout') {
    account = null;
    response(message.id, {});
    return notify('account/updated', { authMode: null, planType: null });
  }
  if (message.method === 'account/login/start') {
    const type = message.params && message.params.type;
    const loginId = 'login-' + nextLogin++;
    pendingLogin = { loginId, type };
    if (type === 'chatgptDeviceCode') return response(message.id, { type, loginId, verificationUrl: 'https://example.invalid/device', userCode: 'FAKE-CODE' });
    return response(message.id, { type: 'chatgpt', loginId, authUrl: 'https://example.invalid/login' });
  }
  if (message.method === 'account/login/cancel') {
    const loginId = message.params && message.params.loginId;
    response(message.id, {});
    if (pendingLogin && pendingLogin.loginId === loginId) {
      pendingLogin = null;
      notify('account/login/completed', { loginId, success: false, error: 'cancelled' });
    }
    return;
  }
  if (message.method === 'test/complete-login') {
    const login = pendingLogin;
    if (!login) return send({ id: message.id, error: { code: -32000, message: 'No pending login' } });
    pendingLogin = null;
    account = { type: 'chatgpt', email: 'fake@example.invalid', planType: 'plus' };
    response(message.id, { completed: true, loginId: login.loginId });
    notify('account/login/completed', { loginId: login.loginId, success: true, error: null });
    return notify('account/updated', { authMode: 'chatgpt', planType: 'plus' });
  }
  if (message.method === 'account/rateLimits/read') return response(message.id, { rateLimits: { limitId: 'codex', primary: { usedPercent: 20, windowDurationMins: 300, resetsAt: 1893456000 }, secondary: null, rateLimitReachedType: null }, rateLimitsByLimitId: {}, rateLimitResetCredits: { availableCount: 1, credits: null } });
  if (message.method === 'account/usage/read') return response(message.id, { summary: { lifetimeTokens: 20, peakDailyTokens: 12, longestRunningTurnSec: 3, currentStreakDays: 1, longestStreakDays: 1 }, dailyUsageBuckets: [{ startDate: '2026-08-19', tokens: 20 }] });
  if (message.method === 'configRequirements/read') return response(message.id, { requirements: null });
  if (message.method === 'app/list') return response(message.id, { data: [{ id: 'fake-app', name: 'Fake App', description: 'fixture', isAccessible: true, isEnabled: true }], nextCursor: null });
  if (message.method === 'app/installed') return response(message.id, { apps: [{ id: 'fake-app', enabled: true, callable: true }] });
  if (message.method === 'app/read') return response(message.id, { apps: [{ id: 'fake-app', name: 'Fake App', description: 'fixture', toolSummaries: [] }], missingAppIds: [] });
  if (message.method === 'skills/list') return response(message.id, { data: [{ cwd: process.cwd(), skills: [{ name: 'fixture-skill', description: 'fixture', path: path.join(process.cwd(), 'SKILL.md'), enabled: true }], errors: [] }] });
  if (message.method === 'skills/config/write') {
    if (!message.params || !message.params.path || message.params.name) return send({ id: message.id, error: { code: -32602, message: 'skills/config/write requires path' } });
    return response(message.id, {});
  }
  if (message.method === 'mcpServerStatus/list') return response(message.id, { data: [{ name: 'fixture', tools: { lookup: {} }, resources: [], resourceTemplates: [], authStatus: { status: 'notLoggedIn' } }], nextCursor: null });
  if (message.method === 'mcpServer/oauth/login') return response(message.id, { authorizationUrl: 'https://example.invalid/mcp-login' });
  if (message.method === 'thread/fork') {
    const threadId = 'thread-' + nextThread++;
    response(message.id, { thread: { id: threadId, sessionId: message.params.threadId, forkedFromId: message.params.threadId, turns: [] } });
    return notify('thread/started', { thread: { id: threadId, sessionId: message.params.threadId, forkedFromId: message.params.threadId } });
  }
  if (message.method === 'thread/goal/set') {
    currentGoal = { threadId: message.params.threadId, objective: message.params.objective, status: message.params.status || 'active', tokenBudget: message.params.tokenBudget || null };
    return response(message.id, { goal: currentGoal });
  }
  if (message.method === 'thread/goal/get') return response(message.id, { goal: currentGoal });
  if (message.method === 'thread/goal/clear') { currentGoal = null; return response(message.id, {}); }
  if (message.method === 'thread/compact/start') {
    const threadId = message.params.threadId;
    const turnId = 'compact-' + nextTurn++;
    const item = { id: 'compact-item-' + turnId, type: 'contextCompaction' };
    response(message.id, {});
    notify('turn/started', { threadId, turn: { id: turnId, status: 'inProgress', items: [] } });
    notify('item/started', { threadId, turnId, item });
    notify('item/completed', { threadId, turnId, item });
    return notify('turn/completed', { threadId, turn: { id: turnId, status: 'completed', items: [], error: null } });
  }
  if (message.method === 'review/start') return response(message.id, { turn: { id: 'review-' + nextTurn++, status: 'inProgress', items: [] }, reviewThreadId: message.params.threadId });
  if (message.method === 'thread/start') {
    const threadId = 'thread-' + nextThread++;
    response(message.id, { thread: { id: threadId, sessionId: threadId, status: { type: 'idle' }, turns: [] } });
    return notify('thread/started', { thread: { id: threadId, sessionId: threadId } });
  }
  if (message.method === 'thread/archive') {
    archivedThreads.add(message.params.threadId);
    response(message.id, {});
    return notify('thread/archived', { threadId: message.params.threadId });
  }
  if (message.method === 'thread/unarchive') {
    archivedThreads.delete(message.params.threadId);
    response(message.id, { thread: { id: message.params.threadId, sessionId: message.params.threadId } });
    return notify('thread/unarchived', { threadId: message.params.threadId });
  }
  if (message.method === 'thread/unsubscribe') return response(message.id, { status: 'unsubscribed' });
  if (message.method === 'thread/delete') {
    archivedThreads.delete(message.params.threadId);
    response(message.id, {});
    return notify('thread/deleted', { threadId: message.params.threadId });
  }
  if (message.method === 'turn/start') {
    const turnId = 'turn-' + nextTurn++;
    const inputText = (((message.params || {}).input || []).find(item => item && item.type === 'text') || {}).text || '';
    const mode = inputText.includes('file-approval') ? 'file-approval' : 'command';
    response(message.id, { turn: { id: turnId, status: 'inProgress', items: [], error: null } });
    return setImmediate(() => runTurn(message.params.threadId, turnId, mode));
  }
  if (message.method === 'turn/interrupt') {
    interruptTurn(message.params.threadId, message.params.turnId);
    return response(message.id, {});
  }
  if (message.method === 'turn/steer') {
    const active = activeTurns.get(turnKey(message.params.threadId, message.params.expectedTurnId));
    if (!active) return send({ id: message.id, error: { code: -32003, message: 'No active turn' } });
    return response(message.id, { turnId: message.params.expectedTurnId });
  }
  if (message.method === 'test/overload') {
    overloadCount += 1;
    if (overloadCount < 2) return send({ id: message.id, error: { code: -32001, message: 'Server overloaded; retry later.' } });
    return response(message.id, { recovered: true });
  }
  if (message.method === 'test/always-overload') {
    alwaysOverloadCount += 1;
    return send({ id: message.id, error: { code: -32001, message: 'Still overloaded.' } });
  }
  if (message.method === 'test/stats') return response(message.id, { overloadCount, alwaysOverloadCount, threads: nextThread - 1, turns: nextTurn - 1, pendingApprovals: pendingApprovals.size });
  if (message.method === 'test/invalid-json') {
    process.stdout.write('{this is not json}\n');
    return response(message.id, { emitted: true });
  }
  if (message.method === 'test/stderr') {
    process.stderr.write('x'.repeat(4096));
    return response(message.id, { emitted: 4096 });
  }
  if (message.method === 'test/server-request') {
    pendingProbe = message.id;
    return send({ id: 'probe-1', method: 'item/tool/requestUserInput', params: { threadId: 'thread-probe', turnId: 'turn-probe', itemId: 'probe-item', questions: [] } });
  }
  if (message.method === 'test/hang') return;
  if (message.method === 'test/exit') return setImmediate(() => process.exit(9));
  return send({ id: message.id, error: { code: -32601, message: 'Unknown method: ' + message.method } });
});
