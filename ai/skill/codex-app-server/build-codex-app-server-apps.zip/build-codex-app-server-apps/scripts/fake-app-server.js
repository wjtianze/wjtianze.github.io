'use strict';

const readline = require('node:readline');

const reader = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
let initialized = false;
let overloadCount = 0;
let pendingApproval = null;

function send(message) {
  process.stdout.write(JSON.stringify(message) + '\n');
}

function response(id, result) {
  send({ id, result: result === undefined ? {} : result });
}

function notify(method, params) {
  send({ method, params: params || {} });
}

function runTurn(threadId, turnId) {
  notify('turn/started', { threadId, turn: { id: turnId, status: 'inProgress', items: [] } });
  notify('item/started', { threadId, turnId, item: { id: 'reason-1', type: 'reasoning', summary: [], content: [] } });
  notify('item/reasoning/summaryTextDelta', { threadId, turnId, itemId: 'reason-1', summaryIndex: 0, delta: '检查项目结构' });
  notify('item/reasoning/summaryPartAdded', { threadId, turnId, itemId: 'reason-1', summaryIndex: 1 });
  notify('item/reasoning/summaryTextDelta', { threadId, turnId, itemId: 'reason-1', summaryIndex: 1, delta: '运行零额度测试' });
  notify('item/completed', { threadId, turnId, item: { id: 'reason-1', type: 'reasoning', summary: ['检查项目结构', '运行零额度测试'], content: [] } });
  notify('item/started', { threadId, turnId, item: { id: 'cmd-1', type: 'commandExecution', command: 'node --check app.js', cwd: process.cwd(), status: 'inProgress' } });
  pendingApproval = { threadId, turnId };
  send({
    id: 'approval-1',
    method: 'item/commandExecution/requestApproval',
    params: { threadId, turnId, itemId: 'cmd-1', command: 'node --check app.js', cwd: process.cwd(), availableDecisions: ['accept', 'decline', 'cancel'] }
  });
}

function finishTurn() {
  if (!pendingApproval) return;
  const { threadId, turnId } = pendingApproval;
  pendingApproval = null;
  notify('serverRequest/resolved', { threadId, requestId: 'approval-1' });
  notify('item/completed', { threadId, turnId, item: { id: 'cmd-1', type: 'commandExecution', command: 'node --check app.js', cwd: process.cwd(), status: 'completed', exitCode: 0, aggregatedOutput: '' } });
  notify('item/started', { threadId, turnId, item: { id: 'answer-1', type: 'agentMessage', text: '', phase: 'final_answer' } });
  notify('item/agentMessage/delta', { threadId, turnId, itemId: 'answer-1', delta: '测试完成。' });
  notify('item/completed', { threadId, turnId, item: { id: 'answer-1', type: 'agentMessage', text: '测试完成。', phase: 'final_answer' } });
  notify('thread/tokenUsage/updated', { threadId, tokenUsage: { total: { inputTokens: 12, cachedInputTokens: 4, outputTokens: 8, reasoningOutputTokens: 3, totalTokens: 20 } } });
  notify('turn/completed', { threadId, turn: { id: turnId, status: 'completed', items: [], error: null } });
}

reader.on('line', line => {
  let message;
  try { message = JSON.parse(line); } catch (_) { return; }

  if (message.id === 'approval-1' && Object.prototype.hasOwnProperty.call(message, 'result')) {
    if (!message.result || !['accept', 'acceptForSession'].includes(message.result.decision)) {
      send({ id: 'approval-result', error: { code: 1, message: '测试审批未接受' } });
      process.exitCode = 3;
      return;
    }
    finishTurn();
    return;
  }

  if (message.method === 'initialize') {
    if (initialized) return send({ id: message.id, error: { code: -32000, message: 'Already initialized' } });
    initialized = true;
    return response(message.id, { userAgent: 'fake-app-server/1.0', platformFamily: 'windows', platformOs: 'windows' });
  }
  if (message.method === 'initialized') return;
  if (!initialized) return send({ id: message.id, error: { code: -32000, message: 'Not initialized' } });

  if (message.method === 'model/list') return response(message.id, { data: [{ id: 'fake-sol', model: 'fake-sol', displayName: 'Fake Sol', isDefault: true, hidden: false, defaultReasoningEffort: 'medium', supportedReasoningEfforts: [{ reasoningEffort: 'low', description: '快速' }, { reasoningEffort: 'medium', description: '均衡' }, { reasoningEffort: 'high', description: '深入' }], inputModalities: ['text', 'image'] }], nextCursor: null });
  if (message.method === 'account/read') return response(message.id, { account: { type: 'chatgpt', email: 'fake@example.invalid', planType: 'plus' }, requiresOpenaiAuth: true });
  if (message.method === 'account/rateLimits/read') return response(message.id, { rateLimits: { limitId: 'codex', primary: { usedPercent: 20, windowDurationMins: 300, resetsAt: 1893456000 }, secondary: null, rateLimitReachedType: null }, rateLimitsByLimitId: {} });
  if (message.method === 'account/usage/read') return response(message.id, { usage: { totalTokens: 20 } });
  if (message.method === 'thread/start') return response(message.id, { thread: { id: 'thread-fake', status: { type: 'idle' }, turns: [] } });
  if (message.method === 'turn/start') {
    const turnId = 'turn-fake';
    response(message.id, { turn: { id: turnId, status: 'inProgress', items: [], error: null } });
    return setImmediate(() => runTurn(message.params.threadId, turnId));
  }
  if (message.method === 'turn/interrupt') {
    notify('turn/completed', { threadId: message.params.threadId, turn: { id: message.params.turnId, status: 'interrupted', items: [], error: null } });
    return response(message.id, {});
  }
  if (message.method === 'test/overload') {
    overloadCount += 1;
    if (overloadCount < 2) return send({ id: message.id, error: { code: -32001, message: 'Server overloaded; retry later.' } });
    return response(message.id, { recovered: true });
  }
  return send({ id: message.id, error: { code: -32601, message: 'Unknown method: ' + message.method } });
});
