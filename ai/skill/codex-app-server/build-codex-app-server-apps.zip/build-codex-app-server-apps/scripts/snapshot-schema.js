'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync: defaultSpawnSync } = require('node:child_process');

function snapshotSchema(args, options = {}) {
  const outIndex = args.indexOf('--out');
  const codexIndex = args.indexOf('--codex');
  if (outIndex < 0 || !args[outIndex + 1]) {
    const error = new Error('用法：node scripts/snapshot-schema.js --out <工作区内目录> [--codex <codex.exe>]');
    error.exitCode = 2;
    throw error;
  }

  const cwd = options.cwd || process.cwd();
  const root = path.resolve(cwd);
  const target = path.resolve(root, args[outIndex + 1]);
  assertChildPath(root, target, '输出目录必须位于当前工作区内，且不能是工作区根目录');
  assertResolvedParentInside(root, target);

  if (fs.existsSync(target)) {
    const stat = fs.lstatSync(target);
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error('输出路径必须是普通目录：' + target);
    if (fs.readdirSync(target).length) throw new Error('输出目录非空，为避免覆盖已停止：' + target);
  }

  const parent = path.dirname(target);
  fs.mkdirSync(parent, { recursive: true });
  assertResolvedParentInside(root, target);

  const command = codexIndex >= 0 && args[codexIndex + 1] ? args[codexIndex + 1] : (process.env.CODEX_EXECUTABLE || 'codex');
  const spawnSync = options.spawnSync || defaultSpawnSync;
  const staging = target + '.tmp-' + process.pid + '-' + crypto.randomBytes(6).toString('hex');
  fs.mkdirSync(staging);

  try {
    for (const [kind, verb] of [['json', 'generate-json-schema'], ['typescript', 'generate-ts']]) {
      const output = path.join(staging, kind);
      fs.mkdirSync(output);
      const run = spawnSync(command, ['app-server', verb, '--out', output], { windowsHide: true, shell: false, encoding: 'utf8' });
      if (run.error) {
        if (['EPERM', 'EACCES'].includes(run.error.code)) {
          throw new Error('Windows 阻止启动 ' + command + '。请通过 --codex 传入宿主应用已验证可运行的 codex.exe；不要复制应用包文件或修改权限。');
        }
        throw run.error;
      }
      if (run.status !== 0) throw new Error('生成 ' + kind + ' 结构失败：' + String(run.stderr || run.stdout || '未知错误'));
    }

    if (fs.existsSync(target)) fs.rmdirSync(target);
    fs.renameSync(staging, target);
    return { ok: true, codex: command, output: target };
  } catch (error) {
    fs.rmSync(staging, { recursive: true, force: true });
    throw error;
  }
}

function assertResolvedParentInside(root, target) {
  const realRoot = fs.realpathSync.native(root);
  let existing = path.dirname(target);
  while (!fs.existsSync(existing)) {
    const parent = path.dirname(existing);
    if (parent === existing) break;
    existing = parent;
  }
  const realParent = fs.realpathSync.native(existing);
  const relative = path.relative(realRoot, realParent);
  if (isOutside(relative)) throw new Error('输出目录的真实父路径越出了当前工作区');
}

function assertChildPath(root, candidate, message) {
  const relative = path.relative(root, candidate);
  if (!relative || isOutside(relative)) throw new Error(message);
}

function isOutside(relative) {
  return relative.startsWith('..' + path.sep) || relative === '..' || path.isAbsolute(relative);
}

function main() {
  try {
    const result = snapshotSchema(process.argv.slice(2));
    process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  } catch (error) {
    process.stderr.write(String(error && error.stack || error) + '\n');
    process.exitCode = error && error.exitCode || 1;
  }
}

if (require.main === module) main();

module.exports = { snapshotSchema, assertChildPath };
