'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const args = process.argv.slice(2);
const outIndex = args.indexOf('--out');
const codexIndex = args.indexOf('--codex');
if (outIndex < 0 || !args[outIndex + 1]) {
  process.stderr.write('用法：node scripts/snapshot-schema.js --out <工作区内目录> [--codex <codex.exe>]\n');
  process.exit(2);
}

const root = path.resolve(process.cwd());
const target = path.resolve(root, args[outIndex + 1]);
if (target === root || !target.startsWith(root + path.sep)) throw new Error('输出目录必须位于当前工作区内，且不能是工作区根目录');
if (fs.existsSync(target) && fs.readdirSync(target).length) throw new Error('输出目录非空，为避免覆盖已停止：' + target);

const command = codexIndex >= 0 && args[codexIndex + 1] ? args[codexIndex + 1] : (process.env.CODEX_EXECUTABLE || 'codex');
fs.mkdirSync(target, { recursive: true });

for (const [kind, verb] of [['json', 'generate-json-schema'], ['typescript', 'generate-ts']]) {
  const output = path.join(target, kind);
  fs.mkdirSync(output, { recursive: true });
  const run = spawnSync(command, ['app-server', verb, '--out', output], { windowsHide: true, shell: false, encoding: 'utf8' });
  if (run.error) {
    if (['EPERM', 'EACCES'].includes(run.error.code)) {
      throw new Error('Windows 阻止启动 ' + command + '。请通过 --codex 传入宿主应用已验证可运行的 codex.exe；不要复制应用包文件或修改权限。');
    }
    throw run.error;
  }
  if (run.status !== 0) throw new Error('生成 ' + kind + ' 结构失败：' + String(run.stderr || run.stdout || '未知错误'));
}

process.stdout.write(JSON.stringify({ ok: true, codex: command, output: target }, null, 2) + '\n');
