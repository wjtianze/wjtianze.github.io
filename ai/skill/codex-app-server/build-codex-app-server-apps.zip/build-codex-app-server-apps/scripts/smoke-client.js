'use strict';

const assert = require('node:assert/strict');
const path = require('node:path');
const { CodexAppServerClient } = require('../assets/node/codex-app-server-client');

async function main() {
  const fakeServer = path.join(__dirname, 'fake-app-server.js');
  const notifications = [];
  const serverRequests = [];
  const client = new CodexAppServerClient({
    command: process.execPath,
    args: [fakeServer],
    cwd: path.resolve(__dirname, '..'),
    clientInfo: { name: 'skill_smoke', title: '技能冒烟测试', version: '1.0.0' },
    timeoutMs: 3000,
    maxOverloadRetries: 2
  });

  client.on('notification', message => notifications.push(message));
  client.on('fatal', error => {
    if (!client.stopping) process.stderr.write(String(error.stack || error) + '\n');
  });
  client.setServerRequestHandler(message => {
    serverRequests.push(message);
    assert.equal(message.method, 'item/commandExecution/requestApproval');
    return { decision: 'accept' };
  });

  try {
    await client.start();
    assert.equal(client.ready, true);

    const models = await client.request('model/list', { limit: 20, includeHidden: false });
    assert.equal(models.data[0].displayName, 'Fake Sol');
    assert.deepEqual(models.data[0].inputModalities, ['text', 'image']);
    assert.equal(models.data[0].supportedReasoningEfforts.length, 3);

    const account = await client.request('account/read', { refreshToken: false });
    assert.equal(account.account.type, 'chatgpt');
    assert.equal(account.account.planType, 'plus');
    const limits = await client.request('account/rateLimits/read');
    assert.equal(limits.rateLimits.primary.usedPercent, 20);

    const overload = await client.request('test/overload');
    assert.equal(overload.recovered, true);

    const started = await client.request('thread/start', {});
    const completed = new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('等待 turn/completed 超时')), 3000);
      const onNotification = message => {
        if (message.method !== 'turn/completed') return;
        clearTimeout(timer);
        client.off('notification', onNotification);
        resolve(message);
      };
      client.on('notification', onNotification);
    });
    await client.request('turn/start', { threadId: started.thread.id, input: [{ type: 'text', text: '运行测试' }] });
    const done = await completed;
    assert.equal(done.params.turn.status, 'completed');
    assert.equal(serverRequests.length, 1);

    const steps = notifications.filter(item => item.method === 'item/reasoning/summaryTextDelta');
    assert.deepEqual(steps.map(item => item.params.summaryIndex), [0, 1]);
    assert.ok(notifications.some(item => item.method === 'item/agentMessage/delta'));
    assert.ok(notifications.some(item => item.method === 'thread/tokenUsage/updated'));

    const interrupt = await client.interrupt('thread-fake', 'turn-other');
    assert.deepEqual(interrupt, {});

    process.stdout.write(JSON.stringify({ ok: true, models: models.data.length, reasoningSteps: steps.length, approvals: serverRequests.length, notifications: notifications.length }, null, 2) + '\n');
  } finally {
    client.stop();
  }
}

main().catch(error => {
  process.stderr.write(String(error.stack || error) + '\n');
  process.exitCode = 1;
});
