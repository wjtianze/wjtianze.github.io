'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { CodexAppServerClient, CodexProtocolError } = require('../assets/node/codex-app-server-client');
const { snapshotSchema } = require('./snapshot-schema');

const fakeServer = path.join(__dirname, 'fake-app-server.js');

function createClient(options = {}) {
  return new CodexAppServerClient({
    command: process.execPath,
    args: [fakeServer],
    cwd: path.resolve(__dirname, '..'),
    clientInfo: { name: 'skill_smoke', title: '技能冒烟测试', version: '1.0.0' },
    timeoutMs: 3000,
    maxOverloadRetries: 2,
    ...options
  });
}

async function withClient(options, callback) {
  const client = createClient(options);
  try {
    await client.start();
    return await callback(client);
  } finally {
    client.stop();
  }
}

async function waitUntil(predicate, message, attempts = 100) {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (predicate()) return;
    await new Promise(resolve => setTimeout(resolve, 10));
  }
  throw new Error(message);
}

async function testMainFlow() {
  const notifications = [];
  const serverRequests = [];
  let releaseApproval = null;
  return withClient({}, async client => {
    client.on('notification', message => notifications.push(message));
    client.setServerRequestHandler(message => {
      serverRequests.push(message);
      assert.equal(message.method, 'item/commandExecution/requestApproval');
      return new Promise(resolve => { releaseApproval = resolve; });
    });

    assert.equal(client.ready, true);
    const models = await client.request('model/list', { limit: 20, includeHidden: false });
    assert.equal(models.data[0].displayName, 'Fake Sol');
    assert.deepEqual(models.data[0].inputModalities, ['text', 'image']);
    assert.equal(models.data[0].supportedReasoningEfforts.length, 3);
    assert.equal(models.data[0].supportsPersonality, true);

    const account = await client.request('account/read', { refreshToken: false });
    assert.equal(account.account.type, 'chatgpt');
    assert.equal(account.account.planType, 'plus');
    const limits = await client.request('account/rateLimits/read');
    assert.equal(limits.rateLimits.primary.usedPercent, 20);
    assert.equal(limits.rateLimitResetCredits.availableCount, 1);
    const accountUsage = await client.request('account/usage/read');
    assert.equal(accountUsage.summary.lifetimeTokens, 20);
    assert.equal(accountUsage.dailyUsageBuckets.length, 1);
    const capabilities = await client.capabilityCenter({ force: true });
    assert.equal(capabilities.providerCapabilities.webSearch, true);
    assert.equal(capabilities.apps.data[0].id, 'fake-app');
    assert.equal(capabilities.skills.data[0].skills[0].name, 'fixture-skill');
    assert.equal(capabilities.mcp.data[0].name, 'fixture');
    assert.equal(capabilities.supported.apps && capabilities.supported.skills && capabilities.supported.mcp, true);
    assert.equal(capabilities.productionPluginManagement, false);
    const skillPath = capabilities.skills.data[0].skills[0].path;
    await client.setSkillEnabled(skillPath, false);
    assert.throws(() => client.setSkillEnabled('', false), /SKILL\.md 路径/);
    assert.match((await client.loginMcp('fixture')).authorizationUrl, /^https:/);

    const overload = await client.request('test/overload');
    assert.equal(overload.recovered, true);

    const started = await client.request('thread/start', {});
    const completed = new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('等待 turn/completed 超时')), 3000);
      const onNotification = message => {
        if (message.method !== 'turn/completed') return;
        clearTimeout(timer);
        client.off('notification', onNotification);
        resolve(message);
      };
      client.on('notification', onNotification);
    });
    const turn = await client.request('turn/start', { threadId: started.thread.id, input: [{ type: 'text', text: '运行测试' }] });
    await waitUntil(() => typeof releaseApproval === 'function', '等待审批请求超时');
    assert.equal((await client.steer(started.thread.id, turn.turn.id, '先检查失败测试')).turnId, turn.turn.id);
    releaseApproval({ decision: 'accept' });
    const done = await completed;
    assert.equal(done.params.turn.status, 'completed');
    assert.equal(serverRequests.length, 1);

    const steps = notifications.filter(item => item.method === 'item/reasoning/summaryTextDelta');
    assert.deepEqual(steps.map(item => item.params.summaryIndex), [0, 1]);
    assert.ok(notifications.some(item => item.method === 'item/agentMessage/delta'));
    assert.ok(notifications.some(item => item.method === 'thread/tokenUsage/updated'));
    assert.ok(notifications.some(item => item.method === 'item/completed' && item.params.item && item.params.item.type === 'mcpToolCall'));
    assert.ok(notifications.some(item => item.method === 'item/completed' && item.params.item && item.params.item.type === 'imageView'));
    assert.ok(notifications.some(item => item.method === 'item/completed' && item.params.item && item.params.item.type === 'collabToolCall'));

    const goal = await client.setGoal(started.thread.id, '完成迁移', 40000);
    assert.equal(goal.goal.tokenBudget, 40000);
    assert.equal((await client.getGoal(started.thread.id)).goal.objective, '完成迁移');
    await client.clearGoal(started.thread.id);
    assert.equal((await client.getGoal(started.thread.id)).goal, null);
    const fork = await client.forkThread({ threadId: started.thread.id });
    assert.equal(fork.thread.forkedFromId, started.thread.id);
    await client.compactThread(started.thread.id);
    await waitUntil(() => notifications.some(item => item.method === 'item/completed' && item.params.item && item.params.item.type === 'contextCompaction'), '等待上下文压缩项目超时');
    assert.equal(notifications.some(item => item.method === 'thread/compacted'), false, '不得依赖已弃用的 thread/compacted');
    assert.equal((await client.startReview(started.thread.id, { type: 'custom', instructions: '检查改动' })).reviewThreadId, started.thread.id);
    await client.archiveThread(started.thread.id);
    assert.equal((await client.unarchiveThread(started.thread.id)).thread.id, started.thread.id);
    assert.equal((await client.unsubscribeThread(started.thread.id)).status, 'unsubscribed');
    assert.throws(() => client.deleteThread(started.thread.id), /confirmed/);
    assert.deepEqual(await client.deleteThread(started.thread.id, { confirmed: true }), {});

    const interrupt = await client.interrupt('thread-fake', 'turn-other');
    assert.deepEqual(interrupt, {});
    return { models: models.data.length, reasoningSteps: steps.length, approvals: serverRequests.length, notifications: notifications.length, steerForkGoalCompactReviewArchiveCapabilities: true };
  });
}

async function testLoginLifecycle() {
  return withClient({}, async client => {
    const updated = [];
    client.on('notification', message => {
      if (message.method === 'account/updated' || message.method === 'account/login/completed') updated.push(message);
    });
    await client.request('account/logout');
    assert.equal((await client.request('account/read')).account, null);

    const browserLogin = await client.request('account/login/start', { type: 'chatgpt' });
    assert.match(browserLogin.authUrl, /^https:/);
    await client.request('account/login/cancel', { loginId: browserLogin.loginId });
    await waitUntil(() => updated.some(message => message.method === 'account/login/completed' && message.params.loginId === browserLogin.loginId), '等待取消登录通知超时');
    assert.ok(updated.some(message => message.method === 'account/login/completed' && message.params.loginId === browserLogin.loginId && message.params.success === false));

    const deviceLogin = await client.request('account/login/start', { type: 'chatgptDeviceCode' });
    assert.equal(deviceLogin.userCode, 'FAKE-CODE');
    await client.request('test/complete-login');
    await waitUntil(() => updated.some(message => message.method === 'account/login/completed' && message.params.loginId === deviceLogin.loginId), '等待登录完成通知超时');
    assert.equal((await client.request('account/read')).account.type, 'chatgpt');
    assert.ok(updated.some(message => message.method === 'account/login/completed' && message.params.loginId === deviceLogin.loginId && message.params.success === true));
    assert.ok(updated.some(message => message.method === 'account/updated' && message.params.authMode === 'chatgpt'));
    return { loginCancelLogoutDeviceCode: true };
  });
}

async function testConcurrentThreadsAndApprovalOutcomes() {
  return withClient({}, async client => {
    const approvalMethods = [];
    let declineNextCommand = false;
    client.setServerRequestHandler(message => {
      approvalMethods.push(message.method);
      if (message.method === 'item/fileChange/requestApproval') return { decision: 'acceptForSession' };
      if (declineNextCommand) {
        declineNextCommand = false;
        return { decision: 'decline' };
      }
      return { decision: 'accept' };
    });

    const [firstThread, secondThread] = await Promise.all([client.request('thread/start', {}), client.request('thread/start', {})]);
    assert.notEqual(firstThread.thread.id, secondThread.thread.id);
    const completed = [];
    client.on('notification', message => {
      if (message.method === 'turn/completed') completed.push(message);
    });
    const [firstTurn, secondTurn] = await Promise.all([
      client.request('turn/start', { threadId: firstThread.thread.id, input: [{ type: 'text', text: 'command approval' }] }),
      client.request('turn/start', { threadId: secondThread.thread.id, input: [{ type: 'text', text: 'file-approval' }] })
    ]);
    assert.notEqual(firstTurn.turn.id, secondTurn.turn.id);
    for (let attempt = 0; attempt < 50 && completed.length < 2; attempt += 1) await new Promise(resolve => setTimeout(resolve, 10));
    assert.equal(completed.length, 2);
    assert.ok(approvalMethods.includes('item/commandExecution/requestApproval'));
    assert.ok(approvalMethods.includes('item/fileChange/requestApproval'));

    declineNextCommand = true;
    let declined = false;
    const onNotification = message => {
      if (message.method === 'item/completed' && message.params.item && message.params.item.type === 'commandExecution' && message.params.item.status === 'declined') declined = true;
    };
    client.on('notification', onNotification);
    const declinedTurn = await client.request('turn/start', { threadId: firstThread.thread.id, input: [{ type: 'text', text: 'decline approval' }] });
    for (let attempt = 0; attempt < 50 && !completed.some(item => item.params.turn.id === declinedTurn.turn.id); attempt += 1) await new Promise(resolve => setTimeout(resolve, 10));
    client.off('notification', onNotification);
    assert.equal(declined, true);

    const stats = await client.request('test/stats');
    assert.equal(stats.threads, 2);
    assert.equal(stats.turns, 3);
    assert.equal(stats.pendingApprovals, 0);
    return { concurrentThreads: 2, fileAndSessionApproval: true, declineApproval: true };
  });
}

async function testNoRetryAndDiagnostics() {
  return withClient({ maxOverloadRetries: 0, maxStderrBytes: 1024 }, async client => {
    assert.equal(client.maxOverloadRetries, 0);
    await assert.rejects(client.request('test/always-overload'), error => error instanceof CodexProtocolError && error.code === -32001);
    const stats = await client.request('test/stats');
    assert.equal(stats.alwaysOverloadCount, 1, '明确配置 0 时不应重试过载请求');

    const warning = new Promise(resolve => client.once('warning', resolve));
    await client.request('test/invalid-json');
    assert.match((await warning).message, /无效 JSON/);

    await client.request('test/stderr');
    await new Promise(resolve => setTimeout(resolve, 20));
    assert.ok(Buffer.byteLength(client.diagnostics().stderrTail, 'utf8') <= 1024);
    return { overloadAttempts: stats.alwaysOverloadCount, boundedStderr: true };
  });
}

async function testServerRequestFallback() {
  return withClient({}, async client => {
    const probe = await client.request('test/server-request');
    assert.equal(probe.clientError.code, -32601);
    assert.match(probe.clientError.message, /未配置/);
    return { unhandledServerRequest: 'rejected' };
  });
}

async function testLateServerRequestResolution() {
  const client = createClient();
  client.setServerRequestHandler(async () => ({ decision: 'accept' }));
  client.stop();
  await client._handleServerRequest({ id: 'late-request', method: 'item/commandExecution/requestApproval', params: {} });
  return { lateServerRequestSafe: true };
}

async function testInitializationCleanup() {
  const client = createClient({ env: { FAKE_INIT_ERROR: '1' } });
  try {
    await assert.rejects(client.start(), error => error instanceof CodexProtocolError && error.code === -32602);
    assert.equal(client.child, null, '初始化失败后不应遗留子进程引用');
    assert.equal(client.ready, false);
    return { failedInitializationCleaned: true };
  } finally {
    client.stop();
  }
}

async function testStartupLockTimeoutAndLaunchError() {
  const client = createClient();
  try {
    await assert.rejects(client.request('model/list'), /尚未运行/);
    const first = client.start();
    const second = client.start();
    assert.equal(first, second, '并发启动必须共享同一初始化 Promise');
    await Promise.all([first, second]);
    await assert.rejects(client.request('test/hang', {}, { timeoutMs: 40 }), /请求超时/);
    assert.equal(client.pending.size, 0, '请求超时后必须清理 pending');
    assert.equal((await client.request('test/stats')).alwaysOverloadCount, 0, '超时不应破坏后续请求');
  } finally {
    client.stop();
  }

  const denied = createClient({
    spawn: () => {
      const error = new Error('denied fixture');
      error.code = 'EPERM';
      throw error;
    }
  });
  await assert.rejects(denied.start(), /Windows 阻止启动/);
  assert.equal(denied.child, null);
  return { startupLock: true, timeoutCleanup: true, launchErrorClassified: true };
}

async function testExitAndRestartIsolation() {
  const exiting = createClient();
  try {
    await exiting.start();
    await assert.rejects(exiting.request('test/exit'), /已退出/);
    assert.equal(exiting.child, null);
  } finally {
    exiting.stop();
  }

  const restarting = createClient();
  try {
    await restarting.start();
    const oldChild = restarting.child;
    restarting.stop();
    await restarting.start();
    const newChild = restarting.child;
    oldChild.emit('exit', 0, null);
    assert.equal(restarting.child, newChild, '旧子进程的迟到退出事件不能清空新连接');
    assert.equal(restarting.ready, true);
    return { exitRejectedPending: true, restartIsolated: true };
  } finally {
    restarting.stop();
  }
}

function testSnapshotSchemaTransaction() {
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'codex-skill-schema-'));
  try {
    let calls = 0;
    const failingSpawn = (_command, args) => {
      calls += 1;
      fs.writeFileSync(path.join(args[3], 'schema.txt'), args[1], 'utf8');
      return calls === 2 ? { status: 1, stderr: 'fixture failure' } : { status: 0, stderr: '' };
    };
    assert.throws(() => snapshotSchema(['--out', 'schema', '--codex', 'fake-codex'], { cwd: tempRoot, spawnSync: failingSpawn }), /fixture failure/);
    assert.equal(fs.existsSync(path.join(tempRoot, 'schema')), false, '失败快照不应留下半成品目标目录');
    assert.equal(fs.readdirSync(tempRoot).some(name => name.includes('.tmp-')), false, '失败快照不应遗留临时目录');

    const successfulSpawn = (_command, args) => {
      fs.writeFileSync(path.join(args[3], 'schema.txt'), args[1], 'utf8');
      return { status: 0, stderr: '' };
    };
    const result = snapshotSchema(['--out', 'schema', '--codex', 'fake-codex'], { cwd: tempRoot, spawnSync: successfulSpawn });
    assert.equal(result.ok, true);
    assert.equal(fs.readFileSync(path.join(tempRoot, 'schema', 'json', 'schema.txt'), 'utf8'), 'generate-json-schema');
    assert.equal(fs.readFileSync(path.join(tempRoot, 'schema', 'typescript', 'schema.txt'), 'utf8'), 'generate-ts');
    assert.throws(() => snapshotSchema(['--out', '..\\escape', '--codex', 'fake-codex'], { cwd: tempRoot, spawnSync: successfulSpawn }), /工作区内/);
    return { schemaSnapshotTransactional: true };
  } finally {
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }
}

async function main() {
  const mainFlow = await testMainFlow();
  const login = await testLoginLifecycle();
  const concurrency = await testConcurrentThreadsAndApprovalOutcomes();
  const retryAndDiagnostics = await testNoRetryAndDiagnostics();
  const fallback = await testServerRequestFallback();
  const lateRequest = await testLateServerRequestResolution();
  const initialization = await testInitializationCleanup();
  const startup = await testStartupLockTimeoutAndLaunchError();
  const lifecycle = await testExitAndRestartIsolation();
  const snapshot = testSnapshotSchemaTransaction();
  process.stdout.write(JSON.stringify({ ok: true, ...mainFlow, ...login, ...concurrency, ...retryAndDiagnostics, ...fallback, ...lateRequest, ...initialization, ...startup, ...lifecycle, ...snapshot }, null, 2) + '\n');
}

main().catch(error => {
  process.stderr.write(String(error.stack || error) + '\n');
  process.exitCode = 1;
});
