# Codex 智能体界面规范

`assets/ui` 是展示状态归并方式的最小脚手架，不是已完成的生产界面。产品仍需实现可信 Markdown 解析、净化、无障碍、持久化、宿主动作和版本专用项目。

## 信息层级

推荐从上到下分为：

1. 对话标签：名称、生成、等待输入、未读、失败和中断状态。
2. 能力条：账号、模型、思考强度、工作区、额度，以及当前结构真正支持的可选设置。
3. 消息区：用户消息、Codex 过程、工具、授权、警告、最终回答、图片和可视化。
4. 输入区：附件、引用状态、输入／预览、发送／停止／追加要求。
5. 轻量统计：当前对话词元与必要状态，不抢占正文。

不要保留只为旧 API 设计的温度、采样概率、手写模型名、网页嵌入或无效能力开关。回答速度／服务档位不是当前官方 `model/list` 基线；只有本机结构和模型数据都提供准确字段时才显示。

线程工具可以容纳分支、名称、目标、固定、归档、恢复、删除、手动压缩和代码审查，但要区分可恢复和不可恢复操作。`thread/delete` 必须二次确认；已弃用的 `thread/rollback` 不作为新入口。`thread/shellCommand` 和实验性 `process/*` 必须标注“沙箱外完全访问”。

## 路由和状态归并

一些官方通知可能只有 `turnId` 或 `turn`，不保证同时带 `threadId`。宿主在收到 `turn/start` 或 `review/start` 响应时立即保存 `turnId -> threadId`，再把后续事件路由到正确对话。不要用“当前选中的标签”兜底。

每个对话独立保存：

- `threadId`、`sessionId`、`activeTurnId`、运行状态和订阅状态；
- 完整消息／项目树和 `itemId` 索引；
- `turnId -> threadId` 映射、待处理服务端请求与审批结果；
- 累计用量、额度快照、警告和错误；
- 草稿、附件、模型设置、滚动位置和是否贴底。

切换对话时，从该对话自己的状态派生发送、停止、继续和追加要求按钮。后台生成继续更新原对话；切回后恢复完整项目、待审批卡、草稿和视口。

## 事件到界面的映射

| App Server 项目／事件 | UI |
|---|---|
| `agentMessage.phase = commentary` | 过程性说明，弱化显示，不伪装成最终答案 |
| `agentMessage.phase = final_answer` | 最终回答区 |
| `reasoning` 与摘要增量 | “Codex 过程”容器；按 `summaryIndex` 和 `summaryPartAdded` 分行 |
| `plan`、`turn/plan/updated` | 可折叠计划，显示待处理／进行中／已完成 |
| `commandExecution` | 命令卡，命令与工作目录可见，输出折叠 |
| `fileChange`、`turn/diff/updated` | 文件修改卡，按文件分组，差异折叠 |
| `webSearch` | 搜索／打开／页内查找卡 |
| `mcpToolCall`、`dynamicToolCall` | 工具卡，显示应用、工具、状态和必要结果 |
| `collabToolCall` | 多智能体协作卡，显示发送线程、接收线程和状态 |
| `imageView` | 查看图片卡，不暴露不必要的完整本机路径 |
| `enteredReviewMode`、`exitedReviewMode` | 审查开始与最终审查结果 |
| `contextCompaction` | 上下文压缩活动；不使用旧 `thread/compacted` |
| 审批服务端请求 | 就地审批卡，显示范围、网络目标与风险 |
| 用户输入、权限或 MCP 征询 | 各自独立的问答／权限／表单卡 |
| `thread/tokenUsage/updated` | 词元统计，不混进回答正文 |

`item/completed` 是最终项目状态。`turn/plan/updated` 和 `turn/diff/updated` 是聚合视图，不能覆盖最终项目。对未知但结构合法的项目显示安全、无原始 JSON 的通用卡，并保留诊断记录。

同时单独处理：

- `configWarning` 与 `warning`；
- `model/safetyBuffering/updated`；
- `model/rerouted`；
- `model/verification`；
- `hook/started` 与 `hook/completed`；
- `thread/status/changed`、`thread/closed`、归档、恢复和删除通知。

模型重路由、安全缓冲、账号验证和配置警告都不是最终回答，不能塞进普通助手气泡。

## 服务端请求

服务端请求不能统一成审批：

- 命令与文件修改返回服务器当前支持的决定枚举，优先使用 `availableDecisions`。
- 网络审批应显示 `networkApprovalContext` 的协议、主机和端口，不依赖命令文本。
- `item/permissions/requestApproval` 返回请求权限的子集与 `turn / session` 范围。
- `item/tool/requestUserInput` 返回按问题编号组织的答案，并尊重 `autoResolutionMs`。
- `mcpServer/elicitation/request` 区分表单和 URL 流程。
- `item/tool/call` 是实验动态工具调用，由受信任宿主执行。
- `account/chatgptAuthTokens/refresh` 与 `attestation/generate` 只由受信任宿主处理，不显示可随意批准的按钮。

未知请求应在宿主返回 JSON-RPC 方法不支持错误；界面可以显示“宿主无法处理此 Codex 请求”，但不能编造 `accept`。

`serverRequest/resolved` 到达后原位关闭卡片。回合结束或中断也可能清理未回答请求，不能继续保留可点击按钮。

## 分行与渲染稳定性

- 收到新的 reasoning 项目、`summaryIndex` 或 `summaryPartAdded` 时建立独立块。
- 数据层保存 `steps[]`，不把不同摘要步骤拼成一段字符串。
- 高频增量每动画帧最多批量渲染一次；只更新内容节点，不替换卡片根节点。
- `item/agentMessage/delta` 与 `item/plan/delta` 是增量；最终 `item/completed` 可能与简单拼接结果不同，以最终项目为准。
- 长命令、差异和工具结果默认折叠，提供检查、复制、打开等显式动作。
- 命令输出、工具结果和错误采用允许字段白名单，绝不直接渲染未知协议对象。

## 滚动

更新前计算 `scrollHeight - scrollTop - clientHeight`。只有原先距离底部约 48 像素以内时才继续跟随；否则保持滚动锚点或原 `scrollTop`。用户主动滚到底部后再恢复自动跟随。

后台思考、翻译、工具、图片和可视化更新都不能夺走已经上滚用户的视口。切换标签时保存并恢复每个对话自己的滚动位置。

## Markdown、图片和可视化

- Markdown 先经过可信解析和净化，再渲染公式；脚本、事件属性和危险 URL 不能逃出内容容器。
- 本机图片先由宿主验证真实路径与工作区范围，再映射成同源 `mediaUrl`。界面不直接使用本机路径。
- `imageView` 是当前官方项目类型。若生成结构还出现 `imageGeneration` 等额外类型，只作为版本专用扩展处理，不假定所有版本都有。
- 外链由宿主打开经过协议校验的 `https:` URL；拒绝 `file:`、`javascript:` 与危险 `data:`。
- SVG／HTML 围栏自动预览时同时保留源码和失败回退。HTML 放入 sandbox iframe；SVG 净化后内联或放入 iframe。禁止外部脚本、字体、网络资源与顶层导航。

### 流式 SVG／HTML

1. 丢弃未完成的最后一行和尾部半个标签。
2. 上一次成功预览持续显示，新候选解析成功后原子替换。
3. 相同源码哈希不重复渲染，更新限制在约 80～150 毫秒一次。
4. 复用同一个 iframe；首个有效尺寸后锁定布局。
5. 最终完成时用完整源码再渲染一次，并保留可复制源码和失败说明。

预览宽度不超过消息列，高度受可视区域约束；使用响应式比例缩放，不依赖内部滚动条展示整张图。

## 隐式上下文和秘密

系统提示词、引用、附件绝对路径、认证状态、组织要求和工具内部载荷可以进入宿主或模型输入，但不能显示为伪造用户消息。界面只显示用户能理解的摘要，例如“已附加 2 个工作区文件”。

不显示访问令牌、刷新令牌、API Key、桥能力令牌、证明令牌、Cookie、完整本机路径、隐藏提示词或未筛选工具参数。

## 可执行检查表

- 模型、思考强度、输入模态和人格选择来自 `model/list`，未知能力默认关闭。
- commentary 与 final answer、思考摘要、计划、命令、文件、工具、协作、审批、警告、审查、压缩和错误视觉分离。
- 无 `threadId` 的回合事件仍能通过已绑定的 `turnId` 路由到正确对话。
- 追加要求只在活动回合可用，并发送 `expectedTurnId`。
- 授权卡使用服务器实际提供的决定；用户输入、权限和 MCP 表单不显示通用“允许一次”。
- 多对话并行、切换、停止、继续、订阅关闭、归档／恢复和后台事件不丢状态。
- 用户上滚后不强制贴底；流式更新不重建卡片根节点。
- 窄屏、窗口缩放、DPI 和大字体下，审批按钮、消息区和输入区仍可操作。
- 图片、SVG 和 HTML 有可读失败回退，外链与媒体动作经过宿主校验。
