# 协议与兼容性

## 证据层级与成熟度

开始协议工作时先读取当前 [OpenAI 官方 App Server 文档](https://learn.chatgpt.com/docs/app-server)，再从产品实际启动的 Codex 可执行文件生成 TypeScript 与 JSON Schema：

```text
codex app-server generate-ts --out <目录>
codex app-server generate-json-schema --out <目录>
```

- 官方文档负责说明语义、成熟度、弃用状态和安全警告。
- 本机生成结构负责说明当前安装版本接受的字段、枚举、必填项和事件联合类型。
- 文档存在而本机结构不存在的功能应降级为“不受当前版本支持”。
- 本机结构存在而官方文档没有稳定说明的功能只能作为版本专用能力，不得宣传为通用能力。
- 官方文档当前明确把 App Server 命令和 WebSocket 传输标为实验性且不支持生产工作负载。即使结构中存在相关字段，也不能抹去这一成熟度限制。
- 官方文档仍把 `plugin/list`、`plugin/read`、`plugin/install` 和 `plugin/uninstall` 标为开发中；生产客户端不要调用。

## 传输

线上协议是省略 `"jsonrpc":"2.0"` 的双向 JSON-RPC 2.0：

- 默认 `stdio://`：每行一个 JSON 对象，适合本机受信任宿主；
- `ws://IP:PORT`：每个文本帧一个消息，实验性且不受支持；
- `unix://` 或 `unix://PATH`：在 Unix 套接字上使用 WebSocket HTTP Upgrade；
- `off`：不暴露本地传输。

WebSocket 监听器同时提供 `/readyz` 和 `/healthz`。带 `Origin` 的健康请求会被拒绝。非回环监听在滚动发布期间可能默认无认证，绝不能直接暴露；远程使用必须采用 `wss://`、TLS 和官方支持的 capability-token 或 signed-bearer-token 配置。原始令牌放在受限文件或独立秘密存储中，不写到命令行。

WebSocket 入口队列过载时返回 `-32001` 与“Server overloaded; retry later.”。客户端只对此错误做有上限的指数退避和随机抖动。

`--listen` 控制客户端如何连接 App Server；`--code-mode-host` 控制 App Server 到 Code Mode 宿主的出站连接，两者不能混淆。同一 App Server 进程内的全部线程共享该 Code Mode 宿主连接。

## 初始化

每条传输连接严格执行：

1. 发送一次带稳定 `clientInfo.name/title/version` 的 `initialize`。
2. 等待成功响应。
3. 发送无 `id` 的 `initialized` 通知。
4. 此后才能调用账号、模型、线程或其它方法。

初始化前调用其它方法会收到 `Not initialized`；同一连接重复初始化会收到 `Already initialized`。

`initialize.params.capabilities` 当前可包含：

- `experimentalApi`：开启实验方法和字段；默认关闭；
- `optOutNotificationMethods`：按完整方法名精确屏蔽通知，不支持通配符；
- `requestAttestation`：允许服务端发起 `attestation/generate` 请求；
- `mcpServerOpenaiFormElicitation`：允许 MCP 扩展表单征询。

只有真正实现了对应宿主处理器时才声明能力。企业集成应使用稳定、可识别的 `clientInfo.name`，不要伪装成官方客户端。

## 三类消息

- 响应：有 `id`，并含 `result` 或 `error`。
- 通知：无 `id`，有 `method` 与 `params`。
- 服务端请求：同时有 `id` 与 `method`；客户端必须用同一 `id` 返回 `result` 或 `error`。

响应、通知与服务端请求可以交错到达。不要按到达顺序猜测类型，也不要把所有服务端请求都变成“允许／拒绝”按钮。

## 方法分层

以下是当前官方文档中会直接改变富客户端设计的接口，不是替代生成结构的完整方法清单。

### 账号与模型

- `account/read`、`account/login/start`、`account/login/cancel`、`account/logout` 与 `account/updated` 管理认证。
- ChatGPT 浏览器和设备代码登录由 App Server 管理。实验性的 `chatgptAuthTokens` 只适用于宿主已经拥有认证生命周期的情况；它还要求处理 `account/chatgptAuthTokens/refresh` 服务端请求。
- `account/rateLimits/read` 与 `account/rateLimits/updated` 提供额度窗口；`account/usage/read` 提供可为空的活动汇总和按日桶。
- `account/rateLimitResetCredit/consume` 会消耗一次已获得的重置，必须使用幂等键并在完成后重读额度。
- `account/sendAddCreditsNudgeEmail` 会触发外部邮件，`account/workspaceMessages/read` 会读取工作区消息；都不能被轮询副作用或后台自动动作滥用。
- `model/list` 是模型、默认模型、思考强度、输入模态、人格支持和升级提示的来源。隐藏模型只在确有需要时用 `includeHidden: true` 获取。
- `modelProvider/capabilities/read`、`configRequirements/read` 和 `permissionProfile/list` 分别描述提供方能力、管理员要求与可用权限配置。
- `experimentalFeature/list` 带有 `beta / underDevelopment / stable / deprecated / removed` 阶段；不能把“存在”直接解释为“可投入生产”。
- `experimentalFeature/enablement/set` 只修改当前进程支持的运行时开关；`collaborationMode/list` 与 `environment/info` 也是实验接口，使用前必须声明 `experimentalApi`，并为环境连接失败提供降级。

官方当前 `model/list` 基线没有承诺回答速度或服务档位字段。只有本机结构和运行时数据同时出现准确字段时才显示这类控件。

### 线程

- 创建、继续、读取和分页使用 `thread/start`、`thread/resume`、`thread/read`、`thread/list`。
- `thread/start`、`thread/resume` 和 `thread/fork` 返回加载的 `instructionSources`；路径采用源环境的本机绝对语法。
- `thread.sessionId` 是当前会话树根，分支线程不能从自己的 `threadId` 推导它。
- 分支用 `thread/fork`；`lastTurnId` 只能指向已经结束的回合，`ephemeral: true` 创建内存分支。
- 名称、目标和元数据分别使用 `thread/name/set`、`thread/goal/*`、`thread/metadata/update`。
- 名称与目标变化通过 `thread/name/updated`、`thread/goal/updated` 和 `thread/goal/cleared` 通知其它订阅客户端，不能只更新发起操作的本地控件。
- `thread/loaded/list` 查看已加载线程；`thread/unsubscribe` 取消当前连接订阅，最后一个订阅者离开后可能延迟卸载并发出 `thread/closed`。
- `thread/archive` 可恢复；`thread/unarchive` 恢复；`thread/delete` 永久删除线程及其派生后代，必须单独确认。
- `thread/turns/list` 与 `thread/items/list` 是实验分页接口；只有客户端启用实验能力且存储支持时使用。
- `thread/compact/start` 立即返回，压缩过程通过普通回合／项目事件和 `contextCompaction` 项目呈现。
- `thread/rollback` 已弃用，不为新功能使用。
- `thread/shellCommand` 在沙箱外以完全访问运行，只能对应用户明确发起的命令。
- `thread/backgroundTerminals/*` 是实验接口，使用 App Server 的 `processId`，不能拿系统进程号代替。

如果配置把某个 MCP 服务设为必需且初始化失败，`thread/start` 与 `thread/resume` 应直接失败，而不是假装能力仍可用。

### 回合、审查和输入

`turn/start.input` 的当前文档基线包括：

- `text`；
- 远程 URL 的 `image`；
- 本机绝对路径的 `localImage`；
- 显式调用技能时的 `skill`；
- 显式调用应用时的 `mention`。

不要发明通用 `file` 输入。每个额外类型都必须来自当前结构。

- `turn/start` 的模型、思考强度、人格、`cwd` 和沙箱覆盖会成为该线程后续回合的默认值；`outputSchema` 只影响当前回合。
- `turn/steer` 只追加到活动回合，必须包含匹配的 `expectedTurnId`，不能携带模型、目录、沙箱或输出结构覆盖。
- `turn/interrupt` 使用真实 `threadId + turnId`；最终状态为 `interrupted`。
- `thread/inject_items` 把原始 Responses API 项目直接写入模型可见历史，属于高级接口；不要用它伪造普通用户消息或绕过产品审计。
- `review/start` 支持未提交改动、基准分支、提交和自定义目标。分离审查返回不同的 `reviewThreadId`，必须单独持久化和停止。

显式技能调用应同时在文本中包含 `$技能名` 并附 `skill` 项目；应用调用应包含 `$应用名` 与 `app://<id>` 的 `mention` 项目。

### 命令、进程、文件与配置

- `command/exec` 在服务器沙箱下执行单条 argv 数组命令；流式会话用 `command/exec/write`、`resize`、`terminate` 和 `outputDelta`。
- 实验性的 `process/spawn`、`writeStdin`、`resizePty`、`kill`、`outputDelta` 和 `exited` 在 Codex 沙箱外运行，必须显式启用实验能力，且只用于产品有意提供的本机进程控制。
- `fs/readFile`、`writeFile`、`createDirectory`、`getMetadata`、`readDirectory`、`remove`、`copy`、`watch`、`unwatch` 使用绝对路径。它们不替代宿主对渲染器的路径授权。
- `config/read` 是只读；`config/value/write`、`config/batchWrite`、`skills/config/write`、`marketplace/*` 与 `externalAgentConfig/import` 会修改用户状态，必须由明确操作触发。
- `skills/config/write` 当前按技能 `SKILL.md` 的路径启用或禁用，不接受只给名称的兼容猜测。
- `externalAgentConfig/detect` 只发现可迁移项；导入必须把用户选择的精确项目交给 `externalAgentConfig/import`，并持续处理 `externalAgentConfig/import/progress` 与 `externalAgentConfig/import/completed`，不能从立即返回的 `importId` 推断迁移已完成。
- `hooks/list` 只列出已发现 hook；同步 hook 的真实运行状态来自 `hook/started` 与 `hook/completed`。
- `feedback/upload` 会把分类、日志或附件发送给外部服务，只能由明确的“发送反馈”动作触发，并先展示将要发送的范围。

### 技能、应用与 MCP

- `skills/list` 可按多个 `cwd` 获取技能并支持 `forceReload`；`skills/changed` 只作为重新读取信号。
- `skills/extraRoots/set` 替换进程级额外发现根，不持久化；不要悄悄扩张技能扫描范围。
- `app/list` 返回目录可访问／启用状态；`app/installed` 返回有效运行状态；`app/read` 只读显示元数据和可选工具摘要，不能替代 `callable` 检查。
- `mcpServerStatus/list` 查看工具、资源和认证状态；`mcpServer/oauth/login` 返回授权地址并通过完成通知报告结果。
- `mcpServer/startupStatus/updated.failureReason = reauthenticationRequired` 时应提供重新连接入口。
- MCP 资源读取、工具调用、`config/mcpServer/reload` 和 OAuth 都要按当前结构与线程范围实现，不能把“服务器已配置”当作“用户已授权调用”。OAuth 完成以 `mcpServer/oauthLogin/completed` 为准。
- `marketplace/add/remove/upgrade` 会修改市场配置；不能在后台自动执行。`plugin/skill/read` 可按需读取远程插件技能，但不使开发中的插件安装接口自动变为生产可用。

## 沙箱、权限与审批

- 线程创建／继续／分支的稳定字段使用 `sandbox`。
- 回合和 `command/exec` 使用结构化 `sandboxPolicy`，包括 `readOnly`、`workspaceWrite`、`externalSandbox` 与高风险 `dangerFullAccess`。
- `readOnly.access` 和 `workspaceWrite.readOnlyAccess` 可限制可读根；`workspaceWrite.networkAccess` 是布尔值，`externalSandbox.networkAccess` 使用 `restricted` 或 `enabled`。
- 实验性命名权限配置使用 `permissions`，需先启用 `experimentalApi` 并调用 `permissionProfile/list`；不得与 `sandbox` 同发。
- `approvalPolicy` 是线程／回合的审批策略。应用工具的 `approvals_reviewer` 与 `default_tools_approval_mode` 是配置文件键，不能凭名称相似拼成请求字段。
- 管理员要求优先于本地配置和界面选择。

命令审批响应支持 `accept`、`acceptForSession`、`decline`、`cancel`，以及当前结构允许的执行策略修订对象；文件修改审批支持前四种。优先渲染服务器给出的 `availableDecisions`。

`networkApprovalContext` 表示受管网络目标，不等同普通 shell 命令审批；界面应显示协议、主机和端口。并发网络请求可能按目标合并成一个审批。

`item/permissions/requestApproval` 必须只返回请求权限的子集，并明确 `turn` 或 `session` 范围。`item/tool/requestUserInput` 返回按问题编号组织的答案；`mcpServer/elicitation/request` 返回 `accept / decline / cancel` 和相应内容；它们都不能用普通审批决定代替。

`serverRequest/resolved` 表示待处理请求已经回答或被回合结束清理，客户端必须原位关闭对应卡片。

## 事件归并

不要假设每个通知都有 `threadId`。例如当前官方 `turn/started`、`turn/completed` 和 `turn/plan/updated` 的文档形状可能只提供回合信息。客户端在收到 `turn/start` 或 `review/start` 响应时建立 `turnId -> threadId` 映射，再用 `threadId / turnId / itemId` 归并。

- `item/started` 建立活动项目；
- 增量事件只更新对应项目；
- `item/completed` 是项目最终权威状态；
- `turn/plan/updated` 和 `turn/diff/updated` 是聚合视图，项目本身仍以 `item/*` 为准；
- `turn/completed` 决定回合状态；
- `thread/status/changed` 决定运行状态，不从本地按钮猜测；
- `thread/tokenUsage/updated` 更新统计，不进入回答正文。

当前常见项目类型包括 `userMessage`、`agentMessage`、`plan`、`reasoning`、`commandExecution`、`fileChange`、`mcpToolCall`、`dynamicToolCall`、`collabToolCall`、`webSearch`、`imageView`、`enteredReviewMode`、`exitedReviewMode` 和 `contextCompaction`。`agentMessage.phase` 使用 `commentary` 或 `final_answer`，必须分开显示。

同时处理 `configWarning`、`warning`、`model/safetyBuffering/updated`、`model/rerouted`、`model/verification` 与同步 hook 事件。不要把模型重路由、安全缓冲或账号验证错误显示成普通最终答案。

`thread/compacted` 已弃用，改用 `contextCompaction` 项目。`item/fileChange/outputDelta` 也是旧兼容事件，当前版本使用 `fileChange` 项目和 `turn/diff/updated`。

## 错误恢复

- `-32001`：只对此错误做有上限的指数退避和抖动。
- `UsageLimitExceeded`：重读额度窗口并显示重置时间，不换用共享账号。
- `Unauthorized`：重读账号状态并引导重新登录。
- `BadRequest` 或字段／枚举错误：停止猜测，记录方法与拒绝字段，重新生成结构。
- `SandboxError`：说明被拒绝资源与当前范围，不自动改成完全访问。
- 连接断开：拒绝未完成请求、保留已收到内容与 stderr 尾部，并提供重连／恢复。

`error.error.codexErrorInfo` 还可能是 `ContextWindowExceeded`、`HttpConnectionFailed`、`ResponseStreamConnectionFailed`、`ResponseStreamDisconnected`、`ResponseTooManyFailedAttempts`、`InternalServerError` 或 `Other`；上游状态码可能出现在 `httpStatusCode`。

`account/rateLimits/updated` 在不同版本中可能不是完整快照。只合并明确出现的字段；无法可靠合并时重新调用 `account/rateLimits/read`。`account/usage/read` 不是货币余额，所有字段都应允许缺失或为空。

## 兼容性排查顺序

1. 记录 Codex 版本、方法、完整错误和经过脱敏的请求形状。
2. 用产品实际可执行文件重新生成结构。
3. 对照官方文档确认稳定／实验／开发中／弃用状态。
4. 只用结构明确允许的形状重试一次；涉及权限时仍不得扩大到未确认范围。
5. 把原始错误保留在诊断日志，向用户显示更新 Codex、重选可执行文件、重启桥或调整已确认工作区等可执行动作。

`spawn EPERM`、`EACCES`、桥接 `Failed to fetch`、JSON-RPC 无效请求、额度错误和沙箱错误是不同故障，不能统一成“请重试”。
