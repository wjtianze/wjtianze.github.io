# 协议与兼容性

## 连接模型

`codex app-server` 面向需要深度集成 Codex 的富客户端，提供账号、对话历史、审批和智能体事件。默认 `stdio` 传输是每行一个 JSON 对象的双向 JSONL；线上 JSON 省略 `jsonrpc` 字段。

连接后严格按顺序执行：

1. 发送一次 `initialize`，包含稳定的 `clientInfo.name/title/version` 和确有需要的能力声明。
2. 等待初始化响应成功。
3. 发送无 `id` 的 `initialized` 通知。
4. 再调用账号、模型、线程或回合方法。

初始化之前调用其它方法会得到 `Not initialized`；同一连接重复初始化会得到 `Already initialized`。

## 三类消息

- 响应：有 `id`，并有 `result` 或 `error`。
- 通知：无 `id`，有 `method` 和 `params`。
- 服务端请求：同时有 `id` 与 `method`；客户端必须回传同一 `id` 的 `result` 或 `error`。

不要假设消息按请求顺序到达。通知和审批请求可以夹在普通响应之间。

## 版本匹配

每次适配实际安装版本时运行：

```text
codex app-server generate-ts --out <目录>
codex app-server generate-json-schema --out <目录>
```

生成物只与执行命令的那个 Codex 版本匹配。把它当作请求字段、枚举和事件结构的最高优先级依据。官方文档用于理解语义，不能替代本机结构。

重点检查：

- `initialize` 能力开关；
- `thread/start`、`thread/resume`、`thread/read`；
- `turn/start`、`turn/steer`、`turn/interrupt`；
- 当前版本的权限配置与审批策略；
- `model/list`、`permissionProfile/list` 等发现接口；
- `account/*`；
- 全部 `item/*`、`turn/*`、`thread/tokenUsage/updated` 事件；
- 服务端审批和用户输入请求的响应枚举。

## 线程、回合和输入

- 线程是对话；回合是一次用户请求及随后的智能体工作；项目是消息、思考、计划、命令、文件修改、工具调用等活动单元。
- 新对话使用 `thread/start`，历史对话使用 `thread/resume`；必要时用 `thread/read` 恢复完整内容。
- `turn/start.input` 原生支持 `text`、`image`、`localImage`，以及当前结构明确支持的其它类型。
- 停止生成使用 `turn/interrupt`，并保留已经收到的增量和项目。
- 对正在运行的回合补充要求使用 `turn/steer`，同时带上期望的回合编号。

## 事件归并

以 `item.id` 和 `turnId/threadId` 为主键归并：

- `item/started` 建立活动卡；
- 增量事件只追加到对应项目；
- `item/completed` 是项目最终权威状态；
- `turn/completed` 决定发送/停止状态；
- `thread/tokenUsage/updated` 更新用量，不要混入正文。

思考摘要的 `summaryPartAdded` 是明确分段信号；即使旧版本没有该事件，也要按不同项目或摘要编号分行显示，绝不能把多个步骤粘成一句。

## 权限与审批

不同版本出现过短横线、驼峰、权限配置和沙箱策略等不同结构。可靠做法只有一个：按本机生成结构和发现结果构造请求。

- 不混发新旧字段。
- 优先选择限制在应用工作区的可写配置，并允许 Codex 或用户处理升级请求。
- 自动审批只能审批当前策略明确允许的范围；超出范围时显示清晰的命令、目录、网络目标和风险。
- 如果产品提供“完全访问”，必须由用户清楚选择；不得为消除报错而静默放大权限。
- 服务端审批请求必须响应，否则回合会看似永久卡住。

## 错误恢复

- `-32001`：服务过载，使用有上限的指数退避和随机抖动。
- `UsageLimitExceeded`：显示额度窗口与重置时间，引导查看账号用量；不要自动换开发者账号。
- `Unauthorized`：刷新 `account/read`，引导重新登录。
- `BadRequest` 或未知字段/枚举：停止盲目重试，输出被拒绝字段并重新生成结构。
- `SandboxError`：说明被拒绝的资源和当前工作区，不要直接改成完全访问。
- 连接断开：拒绝所有未完成请求，保留已接收内容，提供重连/恢复线程入口。

## 官方入口

- App Server 文档：<https://learn.chatgpt.com/docs/app-server.md>
- Codex 文档：<https://developers.openai.com/codex/>

协议会随 Codex 更新；在发布前重新核对以上来源和本机结构。
