# textbook-learning-helper 版本更新记录

> 自 v5.0 起，每条更新记录均标注发布时间（UTC+8，格式 `YYYY.MM.DD HH:MM`）。

## L7.0 · 2026.07.06 16:00（UTC+8）

L7.0 是一次大版本更新，在 L6.7 的 7 项功能基础上额外覆盖 5 项需求：①简化 SKILL.md/README.md（移除版本细节，CHANGELOG 已有）、②教材原文与批阅栏的功能按钮右缩进、③HTML 大标题恢复原样（但保留 LaTeX 助手按钮）、④LaTeX 弹窗增加搜索功能、⑤检查并修复代码 bug。两个发行版（开发者版 L7.0-d / 普通版 L7.0）同步发布，仅差版本水印与 API Key 两行。

**继承自 L6.7 的 7 项功能（L6.7 未正式发布，直接并入 L7.0）**

1. **点击公式复制 LaTeX 源码**：页面内任意 KaTeX 渲染的公式（含聊天、知识点、题目、解析、批阅等所有视图，演示 iframe 内除外）都可点击——点击行内公式 `$...$` 复制 `$...$` 包裹的 LaTeX 源码；点击行间公式 `$$...$$` 复制 `$$...$$` 包裹的 LaTeX 源码。底层用 document 捕获阶段 click 监听，向上查找 `.katex` / `.katex-display` 元素，从 KaTeX 注入的 `<annotation encoding="application/x-tex">` 提取原始 LaTeX。
2. **左栏新增「❌ 错题本」第五个 tab**：自动收集所有已批阅但未全对的题目（错题 + 半对题）。一题一屏格式与测验相同（复用 `renderOne`），上方白色 content-head 显示「❌ 错题本」标题与「第 x/x 题  共 x 道错题」统计。底部按钮区：「🔄 重新作答此题」（清除该题作答/批阅状态，跳到测验视图该题）/「📝 跳到测验此题」（保留状态跳到测验视图对应位置）。点击「📊 错题卡」打开错题卡浮层。
3. **测验标题栏格式重构**：移除原下方蓝色 `quiz-head` 标题块；把答题情况 + 进度条信息合并到上方白色 `content-head`；三段（📝 测验 / 答题情况 / 进度条）固定宽度并排显示，不会随字数变化。
4. **题目标题栏左右分栏**：改为左右两段布局——左侧 `.q-num-left` 显示「第N题」+ 题型 badge + 难度（🔥困难/⚡中等/简单）+ 已批阅 chip；右侧 `.q-tools` 用 `margin-left:auto;padding-left:16px` 实现右缩进，放重写/重新批阅/讲解/删除等工具按钮。
5. **修复 AI 讲解知识点滚动晃动**：新增 `_renderKpExplainBox(ci,ii,it)` 把详解 box 单独抽出，新增 `_streamKpExplain(ci,ii)` 流式更新时只重渲染 box 自身（保留外层 body 的滚动位置），不重建整页。
6. **知识点双标题合并**：移除蓝色 `kp-page-head` 标题块，把信息（分类 chip + 知识点名 + 序号 chip）合并到上方白色 `content-head` 的 `kp-info-block` 中。
7. **新增 LaTeX 公式助手弹窗**：四个学科 tab（通用 / 数学 / 物理 / 化学）× 难度级别，含常用 LaTeX 公式（导数、偏导、积分、双重/三重/环路积分、矩阵、行列式、求和等），点击即复制。

**L7.0 新增的 5 项变更**

8. **简化 SKILL.md / README.md / description（Feature 1）**：移除 SKILL.md description 中所有「L6.x 新增 xxx」的版本细节（CHANGELOG 已有详细记录），只保留帮助 AI 理解技能用途与帮助用户理解功能的高层描述。SKILL.md 的「页面功能」章节从按版本罗列的 30+ 条改为按功能分组的 15 条精简描述。README.md 移除所有「### L6.x 新增 / 调整」小节，改为统一的「功能亮点」列表。
9. **教材原文与批阅栏功能按钮右缩进（Feature 2）**：原 content-head 中 `head-btn`（📑 目录按钮，仅教材原文视图显示）位于 ttl 与 content-tabs 之间，未右对齐。L7.0 给 `.head-btn` 加 `margin-left:auto`，把它推到右侧；同时给 `.content-tabs` 也加 `margin-left:auto` 兜底（批阅视图没有 head-btn 时，tabs 自身推到右侧）。这样教材原文视图的「📑 目录」按钮与所有视图的功能 tab 都右对齐，视觉上更整齐。
10. **HTML 大标题恢复原样（Feature 3）**：L6.7 曾把 header 从 64px 扩到 78px，并把题数+版本信息从右上角移到左上角主标题下方，中间放 LaTeX 助手按钮。用户反馈不习惯，L7.0 恢复原样：header 高度回到 64px；左侧「🗑 清除缓存」+ 主标题；右侧「∑ LaTeX 助手」按钮 + 题数 + 版本水印。LaTeX 助手按钮保留，只是位置从中间挪到右侧。
11. **LaTeX 弹窗增加搜索功能（Feature 4）**：在 LaTeX 助手弹窗的 tabs/levels 下方、grid 上方新增搜索框。输入关键词后，跨所有学科与难度匹配公式的 label 或 tex 内容（大小写不敏感），搜索模式下每个公式按钮额外显示来源学科+难度标签。搜索框右侧显示匹配数量，并有 ✕ 清空按钮。无匹配时显示「🔍 未找到匹配 xxx 的公式」+ 提示试试更短的关键词。打开弹窗时自动清空搜索框。
12. **检查并修复代码 bug（Feature 5）**：
    - **bugfix 1：KaTeX 点击复制干扰选项选择**。原 L6.7 的 `_installKatexClickHandler` 在所有 `.katex` 点击时都会复制 LaTeX 并 `preventDefault()`/`stopPropagation()`——这导致点击选择题选项内的公式时无法选中选项（事件被吞掉）。L7.0 新增交互元素检查：用 `el.closest('.option, label, button, input, textarea, a[href], [onclick], .latex-item, ...')` 检查公式是否位于交互元素内，若是则放行事件（不复制），让选项的 onchange 正常触发。交互元素清单覆盖了选项 label、按钮、输入框、带 onclick 的元素、LaTeX 助手公式项（避免双重复制）、各种工具按钮等。
    - **bugfix 2：错题本视图删除/重写题目后不刷新**。原 `delQ()` 只调 `rQ()`（刷新测验视图），若当前在错题本视图，删除后错题本不会更新。L7.0 新增 `refreshCurrentView()` 函数，根据 `currentView` 调用对应的渲染函数（rKP/rFull/rQ/rWrongbook/renderAnalysisArea），`delQ()` 改用此函数。

**其他变更**

13. **localStorage key 前缀**：从 `tlh_L67_` 改为 `tlh_L70_`，避免加载旧版本状态导致兼容问题。`clearAllCache()` 仍会清掉所有 `tlh_` 前缀的数据（含历史版本）。
14. **版本号升级为大版本 L7.0**：本次更新力度较大（7 项 L6.7 功能 + 5 项 L7.0 新增 = 12 项变更），从 L6.7 直接升级为 L7.0 大版本。CHANGELOG 中不保留 L6.7 条目，直接以 L7.0 发布。

## L6.6 · 2026.07.06 03:34（UTC+8）

L6.6 是一次聚焦「单选排除 + 草稿持久化 + 引用 chip 交互」的小版本更新，覆盖用户提出的 4 项需求：单选题支持排除选项、所有内容（含聊天输入草稿）均 Markdown+LaTeX 渲染并保存至本地、引用按钮右侧的 chip 可点击移除、引用 chip 单行显示且可左右滑动。两个发行版（开发者版 L6.6-d / 普通版 L6.6）同步发布，仅差版本水印与 API Key 两行。

**核心变更 1：单选题也支持右键排除选项（Feature 1）**

1. **背景**：原代码 `renderOne()` 中 `single` 与 `judge` 共用同一段渲染分支，使用纯 radio 输入，无 `oncontextmenu`/`onclick` 排除逻辑；`toggleExclude()` 与 `reviveOption()` 也都明确把 `q.type!=='multiple'&&q.type!=='indeterminate'` 排除在外，单选题被锁死无法排除选项。
2. **拆分 single 与 judge 渲染分支**：L6.6 把 `if(q.type==='single'||q.type==='judge')` 拆成两个独立分支。`judge` 仍走原逻辑（仅 2 个选项，排除无意义），`single` 改为与 `multiple` 一致的渲染方式——`<label class="option'+(isEx?' excluded':'')+selCls+'">` + `oncontextmenu="return toggleExclude(...)"` + 排除时 `onclick="return reviveOption(...)"`，但 input type 仍是 `radio`（保持单选语义）。
3. **放宽 toggleExclude 与 reviveOption 的题型白名单**：两个函数的题型校验从 `q.type!=='multiple'&&q.type!=='indeterminate'` 改为 `q.type!=='multiple'&&q.type!=='indeterminate'&&q.type!=='single'`，单选题现在也能进入排除/恢复逻辑。
4. **reviveOption 单选语义**：单选题的 `reviveOption()` 不能像多选那样把选项加入 `__selected` 集合（单选是单值），改为直接 `q.__selected=k`——左键单击被排除的选项时，直接选中该选项并取消其他选中。
5. **底部提示与 AI prompt**：单选题渲染末尾追加 `单选题：选 1 项；右键可排除选项` 提示文字与「💡 右键单击选项可将其排除（打红叉）」opt-hint；`__excluded` 字段已存在的 AI prompt 注入逻辑（`已排除的选项：`）对单选同样生效。
6. **持久化复用现有 qStates**：`q.__excluded` 字段已经在 `qStates` 序列化/反序列化中，单选题排除状态自动随 localStorage 持久化，无需额外改动。

**核心变更 2：所有内容均 Markdown+LaTeX 渲染并保存至本地（Feature 2）**

7. **现状盘点**：题干 `q.text`、解析 `q.explanation`、AI 详解 `q.__explainContent`、AI 批阅评语 `q.__feedback`、参考答案 `q.answer`、用户作答 `q.__input`、用户看法 `q.__view`、AI 看法评价 `q.__viewEval`、聊天消息（user/assistant/reasoning）等内容已通过 `md()` + `renderMathIn()` 渲染，并已存入 localStorage（`qStates`/`convs`）。
8. **新增「聊天输入草稿持久化」**：原 `chatPrev()` 只更新右侧 Markdown 实时预览，textarea 中的未发送文本**不保存**——切换对话或刷新页面后草稿即丢。L6.6 在 `chatPrev()` 中新增 `cc.__draft=v; saveStateSoon()`，每次输入时把草稿写入当前对话对象的 `__draft` 字段并防抖存盘；新增 `restoreDraft()` 函数从 `curConv().__draft` 读取草稿回填到 textarea 与预览区。
9. **草稿恢复触发点**：`sw()`（切换对话）末尾新增 `restoreDraft()` 调用；`init()` 中 `loadState()` 之后与 marked/katex 加载完成的 interval 回调中各调用一次 `restoreDraft()`，确保页面刷新后未发送的草稿也能恢复。发送消息时 `inp.value=''` 后 `chatPrev()` 会自动把 `__draft` 写为空字符串，避免下次恢复时出现幽灵草稿。
10. **payload schema 扩展**：`saveState` 序列化 `convs` 时新增 `__draft:c.__draft||''` 字段；`loadState` 反序列化时新增 `if(typeof convs[i].__draft!=='string')convs[i].__draft='';` 兼容旧版（L6.5.1 及更早）save。`payload.v` 仍保持 `v:2`，因为 `__draft` 是可选字段，旧版 save 加载后 `__draft` 默认空字符串，向后兼容。

**核心变更 3：引用按钮右侧 chip 可点击 ✕ 移除（Feature 3）**

11. **chip 内嵌 ✕ + onclick**：原 `renderCiteList()` 生成的 chip 是纯展示型 span，无 onclick。L6.6 给每个 chip 加 `onclick="removeCite('kp'|'q',idx)"` 与内嵌 `<span class="cite-chip-x">✕</span>`；hover 时 ✕ 的 opacity 从 .55 提升到 1，提示可点击。
12. **chip 文本独立包裹**：为保证 ✕ 始终可见且文本截断优雅，chip 内部结构从 `📖 文字 ✕` 改为 `<span class="cite-chip-text">📖 文字</span><span class="cite-chip-x">✕</span>`——`.cite-chip-text` 用 `overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0` 截断超长文本，`.cite-chip-x` 用 `flex-shrink:0` 保证不被挤压。
13. **removeCite 函数**：新增 `removeCite(type,idx)`——`type==='kp'` 时从 `_citeKp` Set 中 `delete('kp_'+idx)`，`type==='q'` 时从 `_citeQ` 中 `delete('q_'+idx)`，然后 `renderCiteList()` 重绘。引用仍是「仅本次有效，不存本地」，移除不影响 localStorage。
14. **title 提示更新**：chip 的 `title` 属性从 `分类 / 名称` 改为 `分类 / 名称 — 点击移除`，鼠标悬停明确告知可点击移除。
15. **新增 chip 后自动滚动到最右**：`renderCiteList()` 末尾新增 `if(el.scrollWidth>el.clientWidth){el.scrollLeft=el.scrollWidth}`——配合 Feature 4 的单行水平滚动，新加的 chip 一定会被滚动到可视区域，避免「加了引用但看不到」。

**核心变更 4：引用 chip 仅显示一行 + 左右滑动条查看更多（Feature 4）**

16. **`.qt-cite-list` CSS 改造**：原规则 `display:flex;flex-wrap:wrap;gap:3px;flex:1;min-width:0`（多行换行）改为 `display:flex;flex-wrap:nowrap;gap:3px;flex:1;min-width:0;overflow-x:auto;overflow-y:hidden;scrollbar-width:thin;align-items:center`——`flex-wrap:nowrap` 强制单行，`overflow-x:auto` 启用水平滚动条，`scrollbar-width:thin` 让 Firefox 显示细滚动条。
17. **Webkit 滚动条美化**：新增 `::-webkit-scrollbar{height:4px}`、`::-webkit-scrollbar-thumb{background:var(--border-strong);border-radius:2px}`、`::-webkit-scrollbar-track{background:transparent}` 三条规则，让 Chrome/Edge/Safari 的水平滚动条也是 4px 高的细条，不抢占输入区垂直空间。
18. **chip 不被压缩**：`.cite-chip` 新增 `flex-shrink:0`，保证 chip 在容器宽度不足时不会被横向压缩变形（只允许整体水平滚动）。
19. **chip 最大宽度放宽**：原 `max-width:140px` 在单行滚动场景下偏窄，改为 `max-width:200px`——长知识点名也能多显示几个字；超出仍由 `.cite-chip-text` 的 `text-overflow:ellipsis` 截断。
20. **引用弹窗提示同步**：`#cite-modal` 的说明段落新增 `💡 L6.6 新增：引用按钮右侧的 chip 仅显示一行，可左右滑动查看；点击任意 chip 即可移除该引用。`，让用户首次使用时即知晓新交互。

**版本号与持久化**

21. **localStorage key 前缀改为 `tlh_L66_`**：避免加载 L6.5.1 的旧状态导致 `__draft` 字段缺失的兼容问题（虽然 `loadState` 已做容错，但前缀升级是预防性措施，让用户从干净状态开始体验 L6.6 的新功能）。清除缓存按钮仍按 `tlh_` 前缀匹配，会一次性清掉 `tlh_L60_`~`tlh_L66_` 所有版本的数据。
22. **版本号统一更新为 L6.6 / L6.6-d**：页眉水印、SKILL、README、文件名示例、localStorage key 前缀、inject.py 文档字符串同步。两个发行版的 template.html 仅差版本水印（`L6.6-d 生成` vs `L6.6 生成`）与 API Key（`sk-...` vs `<your-api-key>`）两行。

**L6.6 二次检查 bugfix（2026.07.06 03:51 UTC+8，版本号不变仍为 L6.6）**

发布后对全部代码做了一轮 bug 与需求达成情况复查，发现并修复以下 5 个问题：

23. **bugfix：发送消息后草稿未立即落盘**：原 `sendChat()` 在 `inp.value='';chatPrev();` 后依赖 `chatPrev()` 内的 `saveStateSoon()`（500ms 防抖）写盘。若用户在 500ms 内刷新页面，localStorage 里的 `__draft` 仍是发送前的旧值，重载后会恢复出「幽灵草稿」。修复：在 `chatPrev()` 之前显式 `cc.__draft='';`，并在 `chatPrev()` 之后追加 `saveState();` 同步落盘，确保发送瞬间草稿即被清空并持久化。
24. **bugfix：`eNQ()`（再出题）手动设 `inp.value` 后未同步草稿**：`eNQ()` 直接 `inp.value='#出题 @textbook-learning-helper...'`，不触发 `oninput` 事件，`__draft` 仍是旧值。虽然紧接着 `sendChat()` 会清空草稿，但中间状态不一致——若 `sendChat()` 因任何原因 early return（如 `str=true` 有消息正在生成），`__draft` 就停留在旧值。修复：在 `inp.value=...` 后立即 `_cc.__draft=inp.value;` 同步草稿到当前对话，保持中间状态一致。
25. **bugfix（需求 2 补全）：批阅数据视图知识点标签未 Markdown 渲染**：`renderAnalysisInto()` 中 3 处用 `esc(q.kp)`/`esc(s[si][0])` 渲染知识点名（答题概览表的「知识点」列、错题底部的 📚 标签、薄弱知识点排行榜），若知识点名含 `$...$` 公式则显示为原文不渲染。L6.6 二次检查统一改为 `md(q.kp)`/`md(s[si][0])` 并加 `class="md-content"`，配合 `renderMathIn(c)` 完成公式渲染，达成「一切内容均 Markdown+LaTeX 渲染」的需求。
26. **bugfix：`.qt-hint` 在引用 chip 较多时被挤压换行**：原 `.quiz-toggle-bar .qt-hint` 无 `flex-shrink`/`white-space` 约束，当 `.qt-cite-list`（`flex:1`）撑满剩余空间时，`.qt-hint` 会被 flex 压缩并触发文字换行，导致整栏高度跳动。修复：给 `.qt-hint` 加 `flex-shrink:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:40%`，保证它单行显示且不换行；同时给 `.quiz-toggle-bar label` 与 `.qt-cite-btn` 也加 `flex-shrink:0`，确保只有 `.qt-cite-list` 会水平滚动，其余元素稳定不变形。
27. **bugfix：清除缓存确认框未提及草稿**：`clearAllCache()` 的 `confirm()` 文案列出「所有对话记录（含 AI 回复）」但未提及「未发送的输入草稿」，用户可能不知道草稿也会被清。L6.6 起草稿存入 `convs.__draft`，会随对话一起被清。修复：把文案改为「所有对话记录（含 AI 回复与未发送的输入草稿）」，明确告知用户草稿也会被清除。

**L6.6 三次检查 bugfix（2026.07.06 04:00 UTC+8，版本号不变仍为 L6.6）**

针对用户追问「单选题排除后再选择然后选其他选项再搞一堆操作后的选项涂色情况」做了专项排查，发现并修复 1 个严重涂色 bug：

28. **bugfix：单选/判断/多选/不定项切换选项后旧选项仍显示蓝色高亮（stale `selected` class）**：
    - **根因**：CSS 第 284 行原为 `.option.selected,.option:has(input:checked){background:#e3f2fd;...}`，两个选择器用逗号并列。`renderOne()` 渲染时根据 `q.__selected` 给选中项的 `<label>` 加 `selected` 类、给 `<input>` 加 `checked` 属性。但 `uP()`（选项 `onchange` 触发）只更新 `__selected` 状态并 `saveState()`，**不调用 `rQ()` 重新渲染**——DOM 上旧选项的 `selected` 类残留。
    - **复现路径（单选题 A/B/C/D，初始选 B）**：① 初始渲染：B 有 `selected` 类 + radio `checked` → 蓝色。② 用户点击 C：浏览器切换 radio（C checked、B unchecked），`uP()` 把 `__selected` 改为 `'C'`，但 DOM 未重绘——B 的 label 仍带 `selected` 类。③ CSS 求值：B 匹配 `.option.selected` → 蓝色 ✗；C 匹配 `:has(input:checked)` → 蓝色 ✓。**B 和 C 同时显示蓝色**，用户看到两个"已选"选项。同理，多选/不定项取消勾选某项后，该项 label 上的 `selected` 类也会残留，继续显示蓝色。
    - **涉及操作序列**：排除选项 A → 选 B → 点 C（切换）→ B、C 双蓝；排除 A → 选 B → 恢复 A（revive，`__selected='A'`）→ 点 D（切换）→ A、D 双蓝；多选选 A+B → 取消 A → A 仍蓝。任何不触发 `rQ()` 的选项切换都会复现。
    - **修复**：CSS 改为 `.option:has(input:checked){...}`，移除 `.option.selected` 选择器。涂色完全由浏览器原生的 `:has(input:checked)` 维护——radio/checkbox 的 `checked` 状态变化时 CSS 即时求值，无 stale class 问题。`renderOne()` 仍往 label 上写 `selected` 类，但该类不再有 CSS 引用，成为无害空类。
    - **安全性验证**：① 未锁定题——用户点击切换选项时 `:has(input:checked)` 即时跟踪 radio 的 checked 状态，旧选项 radio 变 unchecked 后立刻失去蓝色。② 锁定（已批阅）题——所有 radio `disabled`，但用户选中项的 `checked` 属性仍在（`sel=(!isEx&&q.__selected===k)?' checked':''`），`:has(input:checked)` 仍匹配 disabled+checked 的 radio，蓝色高亮正确保留。③ 排除选项——`sel` 因 `isEx=true` 恒为 `''`（不 checked），`:has(input:checked)` 不匹配，无蓝色，只有 `.excluded` 的灰暗+红叉样式。④ 判断题、多选题、不定项题同理全部修复。
    - **浏览器兼容性**：`:has()` 选择器需 Chrome 105+ / Edge 105+ / Firefox 121+ / Safari 15.4+。L6.5 起已全面依赖 `:has(input:checked)`，本修复不引入新的兼容性要求。

**需求达成情况复查结论**

- **需求 1（单选可排除选项）**：✓ 已达成。`renderOne()` 单选分支、`toggleExclude()`、`reviveOption()` 均已支持 `single` 题型；`uP()`/`saveDrafts()`/`readSel()`/`gradeObjective()` 的单选逻辑天然兼容排除（排除的 radio 被 disabled，不会被 `:checked` 命中）；`__excluded` 字段已通过 `qStates` 持久化；AI prompt 注入的「已排除的选项」逻辑对单选同样生效。
- **需求 2（一切内容 Markdown+LaTeX 渲染 + 保存至本地）**：✓ 已达成（含本次 bugfix #25 补全）。题干/选项/解析/AI 详解/AI 评语/参考答案/用户作答/用户看法/AI 看法评价/聊天消息/聊天思考过程/聊天输入草稿/知识点名/知识点描述/知识点 AI 详解/教材原文/摘要/分类名/目录条目/批阅数据中的知识点标签与薄弱排行榜——全部通过 `md()` + `renderMathIn()` 渲染，并通过 `qStates`/`kpStates`/`convs`/`questions`/`kpData`/`fulltext`/`meta` 存入 localStorage。
- **需求 3（点击引用 chip 可删除）**：✓ 已达成。每个 chip 内嵌 `<span class="cite-chip-x">✕</span>` 与 `onclick="removeCite(...)"`，`removeCite()` 从 `_citeKp`/`_citeQ` Set 中 delete 后 `renderCiteList()` 重绘；`title` 提示「— 点击移除」；hover 时 ✕ opacity 0.55→1 视觉提示可点击。引用仍「仅本次有效，不存本地」，移除不影响 localStorage。
- **需求 4（引用 chip 单行 + 左右滑动）**：✓ 已达成（含本次 bugfix #26 的布局稳定性修复）。`.qt-cite-list` 用 `flex-wrap:nowrap;overflow-x:auto` 强制单行水平滚动；4px 高细滚动条（Webkit + Firefox `scrollbar-width:thin`）；chip `flex-shrink:0` 不被压缩；新增 chip 后 `el.scrollLeft=el.scrollWidth` 自动滚到最右；`.qt-hint`/label/button 均 `flex-shrink:0` 保证布局稳定。

---

## L6.5.1 · 2026.07.05 17:31（UTC+8）

L6.5.1 是一次紧急 bug 修复版本，修复用户报告的「修改题目后新题目保存不了」严重 bug。两个发行版（开发者版 L6.5.1-d / 普通版 L6.5.1）同步发布，仅差版本水印与 API Key 两行。

**核心变更：修复「修改题目后状态丢失」严重 bug**

1. **根因定位**：状态持久化的身份判定函数 `_contentFP()` 把 `questions[0].text.slice(0,30)` 纳入指纹计算。`saveState` 时用当前（可能已被修改的）`questions` 算指纹存为 `payload.fp`；`loadState` 时用 HTML 原始的 `questions` 算 `_curFP`，与 `p.fp` 比较。当 AI 重写第 1 题（`rewriteQ` 把 `questions[0]` 整体替换为新题对象，`text` 字段变化）后，`payload.fp` 反映的是修改后的题干，而重载时 `_curFP` 反映的是 HTML 原始题干——两者不匹配，`_sameContent=false`，导致 `questions`/`appendedQuestions`/`qStates` 全部不恢复。用户表现为：「重写题目」或「#出题 新出的题」在刷新页面后全部消失。同理，`delQ` 删除第 1 题也会让 `questions[0].text` 变化（原第 2 题变成第 1 题），触发同一 bug。

2. **修复方案**：新增 `_origContentFp` 变量，在 `init()` 调用 `loadState()` **之前**，用 HTML 原始的 `questions`/`kpData` 计算指纹并锁定（此后任何修改都不影响它）。`saveState` 把这个原始指纹存为 `payload.origFp`（与原 `payload.fp` 并存，`fp` 保留向后兼容）。`loadState` 比较时优先用 `p.origFp`（新字段）判断身份，旧版 save（无 `origFp`）回退用 `p.fp`。这样重写/删除题目只改变 `questions` 数组本身，不改变 `_origContentFp`，身份判定始终匹配，全部状态正常恢复。

3. **指纹增强**：原 `_contentFP()` 只用 `questions[0].text` 前 30 字符 + `questions.length` + `kpData.length`，碰撞概率较高（不同 HTML 凑巧第 1 题前 30 字相同会被误判为同一个）。L6.5.1 新增 `_computeContentFp()` 函数，改用前 3 道题的题干（各前 30 字）+ 前 3 个分类名与各分类前 3 个知识点名，身份识别更精准。`_contentFP()` 改为返回 `_origContentFp`（若已锁定）或回退到 `_computeContentFp()`（实时计算）。

4. **payload 版本号升级 v:1 → v:2**：`saveState` 写入 `v:2` 与新字段 `origFp`；`loadState` 的版本校验从 `p.v!==1` 放宽为 `p.v!==1&&p.v!==2`，兼容旧版 save（v:1 无 `origFp`，回退用 `p.fp`，但因为旧 `fp` 是修改后指纹，旧 save 仍会不匹配——这是预期行为，因为旧 save 本身就是有 bug 的）。

5. **localStorage key 前缀改为 `tlh_L651_`**：避免加载 L6.5 的旧状态。旧状态（`tlh_L65_` 前缀）里 `origFp` 字段缺失，`loadState` 会回退到 `p.fp`，但 `p.fp` 是 L6.5 旧逻辑算出的「修改后指纹」，重载时仍会与 HTML 原始指纹不匹配——所以必须升级前缀让用户从干净状态开始。清除缓存按钮仍按 `tlh_` 前缀匹配，会一次性清掉 `tlh_L60_`~`tlh_L651_` 所有版本的数据。

6. **版本号统一更新为 L6.5.1 / L6.5.1-d**：页眉水印、SKILL、README、文件名示例、localStorage key 前缀、inject.py 文档字符串同步。两个发行版的 template.html 仅差版本水印（`L6.5.1-d 生成` vs `L6.5.1 生成`）与 API Key（`sk-...` vs `<your-api-key>`）两行。

---

## L6.5 · 2026.07.05 16:55（UTC+8）

L6.5 是一次「九项功能迭代」的中型更新，覆盖用户提出的 9 项需求：API 余额查询、AI 提问引用、选项染色修复、答题概览染色修复、批阅按钮颜色互换、目录按钮移位、知识点序号上移、测验进度条回归、再出题自选知识点。两个发行版（开发者版 L6.5-d / 普通版 L6.5）同步发布，仅差版本水印与 API Key 两行。

**核心变更 1：API 余额查询（Feature 1）**
1. **新增 DeepSeek API 余额查询**：在右栏价格栏（`#price-bar`）新增「💳 余额 ¥XX.XX」字段，调用 DeepSeek 官方余额接口 `GET https://api.deepseek.com/user/balance`（文档：https://api-docs.deepseek.com/zh-cn/api/get-user-balance），解析 `balance_infos[0].total_balance` 并显示。具体改动：
   - 新增 `BALANCE_URL` 常量、`_balanceCache`/`_balanceLast`/`_balanceBusy` 三个缓存变量。
   - 新增 `fetchBalance(force)` 函数：带 60 秒内存缓存（避免频繁请求），`force=true` 时强制刷新；使用与聊天相同的 `Authorization: Bearer KEY` 头。
   - 新增 `refreshBalance(force)` 函数：调用 `fetchBalance` 并更新 `#api-balance` 元素的文本与 title；查询失败时显示「—」。
   - 在 `toks()` 末尾调用 `refreshBalance()`（每次 token 统计更新时顺带刷新余额，但有 60 秒缓存保护，不会真频繁请求）。
   - 在 `init()` 与 marked/katex 加载完成的 interval 回调中各调用一次 `refreshBalance(true)` 强制初始化余额。
   - 余额数字可点击（`onclick="refreshBalance(true)"`，光标变手形），方便用户手动刷新。
2. **余额与用量并排显示**：余额 span 紧跟在「📊 全部累计」之后，与当前对话费用、全部累计费用在同一行，符合「余额显示在输入框下方，和用量放在一起」的需求。

**核心变更 2：AI 提问引用知识点/题目（Feature 2）**
3. **新增「📎 引用」按钮**：在右栏 `.quiz-toggle-bar`（出题模式开关所在栏）中，于出题模式 label 之后、提示文字之前，新增一个「📎 引用」按钮（class `qt-cite-btn`，橙色描边、悬停反色）。
4. **引用浮窗**：点击「📎 引用」弹出 `#cite-modal` 浮窗，分两区列出全部知识点（按分类，带 `[分类名]` 标签）与全部题目（带题型标签 + 题号 + 题干预览），每项前有复选框，可多选。知识点列表用 `_kpFlat`（已通过 `_rebuildKpFlat()` 构建），题目列表用 `allQ()`。
5. **引用 chips 即时显示**：确定后，在「📎 引用」按钮右侧（`.qt-cite-list` 容器）以小 chip 形式显示已引用的内容——知识点 chip 蓝色（📖 + 名称）、题目 chip 橙色（📝 + 第N题），点击引用按钮可再次打开浮窗修改。
6. **引用只对一次提问有效**：在 `sendChat()` 的非再生路径中，发送前调用 `buildCiteContext()` 把引用内容拼成上下文文本（知识点列出名称+描述，题目列出题干+选项+答案+作答/批阅情况），追加到 `msg` 末尾；追加后立即调用 `clearCite()` 清空 `_citeKp`/`_citeQ` 两个 Set 并刷新 chip 显示。引用情况**不保存到 localStorage**（两个 Set 是纯内存变量，刷新即失）。
7. **再生路径不引用**：`sendChat(regenOpts)` 的再生路径不注入引用上下文（引用只对新提问生效）。

**核心变更 3：选择题选项染色即时化（Feature 3）**
8. **CSS `:has(input:checked)` 替代 JS 驱动的 `selected` 类**：原 `.option.selected` 规则只在 `renderOne` 渲染时根据 `q.__selected` 添加 `selected` 类，但 `uP()`（选项 onchange）只更新 JS 状态、不重新渲染，导致点击选项后背景色不变。L6.5 把规则改为 `.option.selected,.option:has(input:checked){...}`——`:has(input:checked)` 由浏览器原生维护，input 的 `checked` 状态变化时立即生效，无需 JS 重新渲染。这对单选（radio 切换）、多选/不定项（checkbox 勾选/取消）都即时生效；排除选项（excluded）由于 `rQ()` 会重新渲染且 disabled+hidden 的 input 不会被 `:checked` 命中，不受影响。

**核心变更 4：批阅栏答题概览每题染色（Feature 4）**
9. **移除 `.answer-table tr:nth-child(even) td` 规则**：原 CSS 第 294 行有 `.answer-table tr:nth-child(even) td{background:var(--bg-soft)}`，这会覆盖偶数行 `<td>` 的背景色，导致偶数行的内联 `<tr style="background:...">` 状态色被 `--bg-soft` 遮住（奇数行 `<td>` 透明、能透出 `<tr>` 的状态色）。视觉效果就是「只有偶数题有状态色，奇数题没有」。L6.5 直接删除该规则，所有行的 `<td>` 背景透明，内联 `<tr>` 的状态色（绿/红/黄/灰）全部透出，每题都正确染色。

**核心变更 5：批阅按钮颜色互换（Feature 5）**
10. **「📝 批阅本题」改为橙色、「✅ 全部批阅」改为白色**：原 HTML 中 `#q-grade-one`（批阅本题）是 `btn btn-secondary`（白灰底）、`#q-submit-all`（全部批阅）是 `btn btn-accent`（橙底）。L6.5 把两个 class 互换——`#q-grade-one` 改为 `btn btn-accent`（橙色），`#q-submit-all` 改为 `btn btn-secondary`（白色）。`flex:1` 内联样式不变，三个按钮（🔄 再出几道题 / 📝 批阅本题 / ✅ 全部批阅）仍等宽并列；橙色现在落在单题批阅上，更突出「先批当前题」的渐进操作路径。

**核心变更 6：教材目录按钮移到模式切换框左侧（Feature 6）**
11. **`#head-toc` 移到 `.content-tabs` 之前**：原 `.content-head` 内顺序为 `.ttl` → `.content-tabs`（四个模式 tab）→ `#head-toc`（目录按钮，仅教材原文视图显示）。L6.5 调整为 `.ttl` → `#head-toc` → `.content-tabs`，即目录按钮位于四个模式切换框的左边。`.content-head` 是 flex 布局，`.ttl` 有 `flex:1` 占满剩余空间，所以目录按钮与模式 tab 都靠右排列，顺序由 DOM 顺序决定。`switchView()` 中 `tocBtn.style.display=(v==='full'&&...)` 的可见性逻辑不变。

**核心变更 7：知识点序号移到标题处（Feature 7）**
12. **标题处显示「第 X / N 个知识点」**：原 `rKP()` 在知识点主体内容末尾（`h+='</div>'` 之后）追加一行 `<div style="text-align:center;...">第 X / N 个知识点</div>` 显示序号。L6.5 把序号移到 `#kp-title-text` 标题里——`tt.innerHTML='📖 '+md(it.name)+' <span class="kp-num">（第 '+(_kpIdx+1)+' / '+_kpFlat.length+' 个知识点）</span>'`，新增 `.kp-num` CSS（小字、浅灰、正常字重）让序号在标题中以辅助信息形式呈现。原底部计数行替换为注释 `// L6.5：翻页提示已移到知识点标题处（上方），此处不再重复显示`。

**核心变更 8：测验进度条回归 + 新标题格式（Feature 8）**
13. **测验标题格式改为「第x/x题  已答x/x，得分x/x（xx%）」**：原 `updateQuizProgress()` 输出 `第 X/N 题 · 已答 A/N · 得分 S/G (P%)`（用 `·` 分隔）。L6.5 改为 `第 X/N 题  已答 A/N，得分 S/G (P%)`——`第x/x题`后接两个空格，再接`已答x/x`，逗号接`得分x/x（xx%）`，与用户指定的样式一致。
14. **新增 4 段式进度条**：在 `.quiz-head` 内 `#quiz-progress-text` 之后新增 `<div class="quiz-progress-bar" id="quiz-progress-bar">` 容器，内含 4 个 `<div class="qpb-seg">` 段：
    - `.earned`（绿色 `--success`）：已拿到的分值——客观题全对算 1 分、半对算 0.5 分；主观题按 `__score`（0~1）算。
    - `.lost`（红色 `--error`）：做了但没拿到的分值——客观题全错算 1 分、半对算 0.5 分；主观题按 `1-__score` 算。
    - `.pending`（蓝色 `--info`）：做了还没批阅的分值——`!q.__locked && isAnswered`（已答未提交）或 `q.__grading`（AI 批阅中）或主观题 `__verdict==='ungraded'`。
    - `.untouched`（透明/不填色）：没做的分值——`!q.__locked && !isAnswered`。
    每段宽度按 `该段分值/总题数*100%` 设置，`transition:width .3s ease` 让宽度变化有平滑动画。`.quiz-progress-bar` 容器 `display:flex;width:100%;height:8px;border-radius:4px;gap:1px`，`flex-wrap:wrap` 让进度条换行到标题下方独立成行。
15. **进度条 title 提示**：容器有 `title="绿=已拿分 / 红=做了没拿分 / 蓝=做了没批 / 灰=没做"`，鼠标悬停显示图例。

**核心变更 9：再出题自选知识点（Feature 9）**
16. **侧重选项新增「自选知识点（可多选）」**：原再出题弹窗 `#quiz-modal` 的「🎯 侧重」radio 组只有「全部知识点」和「薄弱知识点」两个选项。L6.5 新增第三个 `value="custom"` 的 radio「自选知识点（可多选）」，并在三个 radio 上都加 `onchange="updKpFocus()"`。
17. **自选知识点复选框列表**：选中「自选知识点」时，`updKpFocus()` 显示 `#kp-focus-box`（`display:''`）并调用 `buildKpFocusList()` 构建列表——遍历 `_kpFlat`，每个知识点一个 `<label class="cite-item"><input type="checkbox" data-kpidx="i"> [分类] 名称</label>`，复用引用浮窗的 `.cite-item` 样式。列表只构建一次（`el.dataset.built` 标记），避免每次切换 radio 都重建。
18. **`eNQ()` 处理自选模式**：`f==='custom'` 时，收集 `#kp-focus-list input[type=checkbox]:checked` 的知识点名称；若一个都没选，`toast('请至少勾选 1 个知识点…')` 并 return；否则拼成 `（侧重以下知识点：名称A、名称B、…）` 追加到出题 prompt。prompt 里的侧重标签也从二元 `'薄弱知识点'/'全部知识点'` 改为三元 `'薄弱知识点'/'自选知识点'/'全部知识点'`。

**版本号与持久化**
19. **localStorage key 前缀改为 `tlh_L65_`**：避免加载 L6.4 的旧状态导致兼容问题（L6.5 新增了引用相关的内存变量，但未改变 localStorage 结构；前缀升级是预防性措施）。清除缓存按钮仍按 `tlh_` 前缀匹配，会一次性清掉 `tlh_L60_`~`tlh_L65_` 所有版本的数据。
20. **版本号统一更新为 L6.5 / L6.5-d**：页眉水印、SKILL、README、文件名示例、localStorage key 前缀、inject.py 文档字符串同步。两个发行版的 template.html 仅差版本水印（`L6.5-d 生成` vs `L6.5 生成`）与 API Key（`sk-...` vs `<your-api-key>`）两行。

---

## L6.4 · 2026.07.05 12:13（UTC+8）

L6.4 是一次聚焦「AI 输出上限 + 测验栏按钮交互」的小版本更新，覆盖用户提出的 2 项核心需求。两个发行版（开发者版 L6.4-d / 普通版 L6.4）同步发布，仅差版本水印与 API Key 两行。

**核心变更 1：所有 AI 输出 token 上限拉满到 384000**
1. **聊天 / 出题 / 批阅 / 重写 / 讲解 / AI 演示全部拉满**：原代码中各 AI 调用的 `max_tokens` 限制不一——聊天流式输出无显式上限（走 DeepSeek API 默认值，常被默认上限截断）、`#出题` 模式 JSON 数组输出 `max_tokens:8192`、AI 批阅 `max_tokens:8192`、AI 重写题目/知识点 `max_tokens:4096`、AI 生成/编辑演示 `max_tokens:8192`、AI 详解（`explainKP`/`_doExplainQ`）流式输出无显式上限。L6.4 起：所有 AI 调用的 `max_tokens` 一律改为 DeepSeek 支持的最大值 **384000**，确保长答案详解、大题库 JSON 数组、复杂演示代码、长 reasoning_content 都不会被中途截断。具体改动：
   - `sendChat` 的 `_bdObj`：基础对象添加 `max_tokens:384000`（非 `#出题` 模式也生效）；`#出题` 模式下的 `_bdObj.max_tokens=384000`（原 8192 → 384000）。
   - `continueGen` 的 `_bdObj2`：基础对象添加 `max_tokens:384000`；`#出题` 续写模式下的 `_bdObj2.max_tokens=384000`。
   - `_doAiGenDemo`（AI 生成/编辑演示）：`max_tokens:8192` → `max_tokens:384000`。
   - `_doRewriteQ`（AI 重写题目）：`max_tokens:4096` → `max_tokens:384000`。
   - `_doRewriteKP`（AI 重写知识点）：`max_tokens:4096` → `max_tokens:384000`。
   - `explainKP`（知识点 AI 详解）：原本无 `max_tokens`，新增 `max_tokens:384000`。
   - `_doExplainQ`（题目 AI 详解）：原本无 `max_tokens`，新增 `max_tokens:384000`。
   - `gradeSubjective`（AI 批阅主观题）：`max_tokens:8192` → `max_tokens:384000`。
2. **唯一例外：对话标题自动命名**：仍保留 `max_tokens:32`。原因——对话标题限制 ≤7 字，32 token 已绰绰有余；保持小上限可省 token、避免 AI 误输出多余内容。该调用走 `FLASH` 模型 + `thinking:{type:'disabled'}`，是非思考模式的轻量调用，无需拉满。
3. **SKILL.md 同步说明**：在「JSON Output 模式」段落末尾新增 L6.4 说明，明确「所有 AI 调用的 `max_tokens` 一律拉满到 384000」与「对话标题命名例外」。

**核心变更 2：测验栏按钮交互调整**
4. **单题批阅按钮挪到底部按钮区**：原位于顶部测验导航栏的 `<button id="q-grade-one">📝 批阅</button>`（class `quiz-nav-btn success`，与「上一题 / 答题卡 / 下一题」并列）挪到底部按钮区，改名为「📝 批阅本题」（class `btn btn-secondary`，与「🔄 再出几道题」「✅ 全部批阅」并列，三者都 `flex:1` 等宽）。顶部导航栏只保留「上一题 / 答题卡 / 下一题」三个导航按钮，职责更纯粹——顶部只做切换，底部做批阅/出题操作。
5. **「✅ 全部批阅」按钮智能隐藏**：原 `updateQuizNav` 函数中，「全部批阅」按钮的显示/隐藏仅依赖当前是否在最后一题（`_qIdx>=all.length-1` 时显示，否则隐藏）。L6.4 改为按未批阅情况决定：
   - 收集所有未批阅题目的下标 `ungradedIdxList`；
   - 若 `ungradedIdxList.length===0`（全部已批）→ 隐藏「全部批阅」（无未批题可点）；
   - 若 `ungradedIdxList.length===1 && ungradedIdxList[0]===all.length-1`（只剩最后一题未批）→ 隐藏「全部批阅」（用「📝 批阅本题」即可，无需走全部批阅流程触发 AI 批阅多道题）；
   - 其余情况 → 显示「全部批阅」。
   该逻辑独立于当前 `_qIdx`——无论用户停在哪一题，只要全局未批情况满足隐藏条件，「全部批阅」就隐藏。
6. **最后一题「下一题」按钮始终显示但禁用**：原 `updateQuizNav` 中，最后一题时 `nextBtn.style.display='none'`（隐藏「下一题」）。L6.4 改为始终 `nextBtn.style.display=''`（显示），并 `nextBtn.disabled=(_qIdx>=all.length-1)`（最后一题时禁用）。这样按钮位稳定，不会因为切到最后一题就突然少一个按钮导致视觉跳动；按钮变灰禁用的视觉反馈也比直接消失更直观。
7. **`gradeOne` 函数无需改动**：原 `gradeOne(i)` 函数本体未改，只改了它的触发按钮位置与样式。

**版本号与持久化**
8. **localStorage key 前缀改为 `tlh_L64_`**：避免加载 L6.3 的旧状态结构导致兼容问题（虽然 L6.4 的状态结构与 L6.3 几乎一致，但前缀升级可避免任何潜在的兼容性问题）。清除缓存按钮仍按 `tlh_` 前缀匹配，会一次性清掉 `tlh_L60_`、`tlh_L61_`、`tlh_L62_`、`tlh_L63_`、`tlh_L64_` 等所有版本的数据。
9. **版本号统一更新为 L6.4 / L6.4-d**：页眉水印、SKILL、README、文件名示例、localStorage key 前缀同步。两个发行版（开发者版 L6.4-d / 普通版 L6.4）的 template.html 仅差版本水印（`L6.4-d 生成` vs `L6.4 生成`）与 API Key（`sk-...` vs `<your-api-key>`）两行。

---

## L6.3 · 2026.07.05 09:41（UTC+8）

L6.3 是一次「生成流程重构 + 演示强制性」的更新，覆盖用户提出的 2 项核心需求：

**核心变更 1：分文件生成（重构生成流程）**
1. **AI 将教材原文、知识点、演示、题目分开来写**：L6.2 及之前，AI 把所有数据（书名/章节/摘要/教材全文/知识点/演示/题目）塞进一个 `data.json`，再由 inject.py 注入模板。L6.3 改为五类源文件分写：
   - `meta.json`：`{book, chapter, summary}`（书名/章节/摘要）
   - `fulltext.md`：教材原文（规范 Markdown）
   - `kp.json`：知识点分类数组（**不含 demo 字段**），结构 `[{cat, items:[{name, desc}]}, ...]`
   - `questions.json`：题目数组
   - `demos/{ci}_{ii}.html`：每个知识点的演示独立 HTML 文件（`{ci}` 是分类下标，`{ii}` 是该分类 items 下标）
2. **inject.py 改为目录输入**：`python3 inject.py <input_dir> <output.html> [template.html] [--key <api-key>]`（普通版支持 `--key`，开发者版不需要）。脚本读取整个源文件目录，组装成完整 data 对象后注入模板。SKILL.md 的「生成方式」从五步改为六步，新增「创建工作目录 data/ 与 data/demos/」步骤。
3. **演示 `</script>` 自动转义**：L6.2 及之前，AI 在写演示代码（内嵌在 data.json 的 demo 字段里）时必须把 `</script>` 手动转义为 `<\/script>`，否则外层 `<script type="application/json">` 块会被提前关闭。L6.3 由于演示改为独立 HTML 文件，AI 写演示时直接写正常的 `</script>`，inject.py 在组装 JSON 时自动把 demo 内容里的 `</script>` 替换为 `<\/script>`。这避免了 AI 经常忘记转义或误转义导致的演示空白问题。
4. **fulltext/kp/questions 残留 `</script>` 拦截**：inject.py 在组装后用正则 `(?<!\\)</script` 扫描整个 JSON，若发现未转义的 `</script>`（来自 fulltext.md / kp.json / questions.json 中的 script 标签），报错并提示位置。demo 部分由于已经转义过，不会再被命中。
5. **成功输出增加统计**：inject.py 成功时打印 `✅ 已生成：…（知识点 N 个 / 演示 N 个 / 题目 M 道）`，方便确认演示数量与知识点数量一致。

**核心变更 2：演示从可选改为强制**
6. **每个知识点都必须有演示**：L6.2 及之前，知识点可附 `demo` 字段（可选）；无 demo 时页面显示「➕ 添加演示」与「🤖 AI 生成」按钮，用户可手动创建或让 AI 自动生成。L6.3 起演示是强制性的——AI 生成时必须为每个知识点产出对应的 `demos/{ci}_{ii}.html` 演示文件。inject.py 会强制校验：遍历 kp.json 的每一个 item，检查 `demos/{ci}_{ii}.html` 是否存在，缺任何一个都报错退出，错误信息明确指出是哪个分类的哪个知识点缺演示。
7. **SKILL.md 演示强制性铁律**：在生成方式中新增第 4 步「演示强制性铁律（L6.3）」，明确要求"无论知识点是公式、概念还是方法，都必须产出可交互的演示。即使是纯文字概念，也可以做成翻卡、拖拽配对、填空检验等交互形式"。
8. **页面 demo 系统提示词强化**：`_demoSysPrompt` 函数新增一段【L6.3 重要】提示，告知 AI"演示是知识点的强制配套——无论知识点是公式、概念还是方法，都必须产出可交互的演示，不能以'不适合做演示'为由拒绝或敷衍。即使是纯文字概念，也可以做成翻卡、拖拽配对、填空检验等交互形式"。适用于运行时「🤖 AI 生成」/「🤖 AI 编辑」按钮的 AI 调用。
9. **页面 demo 空状态文案更新**：原空状态显示「本知识点暂无交互式演示 / 点击「➕ 添加演示」可手动创建，或点击「🤖 AI 生成」让 AI 自动生成」。L6.3 改为「本知识点的演示已被移除 / L6.3 起每个知识点生成时都强制附带演示；如需恢复，点击「🤖 AI 生成」或「➕ 添加演示」」。空状态理论上不会再出现（生成时都有演示），仅在用户手动删空演示时显示。
10. **模板示例数据补齐演示**：原示例数据中 `kpData[1].items[0]`（示例：动能定理）没有 demo，L6.3 补上一个「动能定理可视化」演示（合外力/位移/初动能三滑块，实时计算 W 与 Ek₂），让模板直接双击打开时也能体现「每个知识点都有演示」的 L6.3 特性。
11. **`_doRewriteKP` 提示词版本标签更新**：把【L6.2 demo 字段铁律】改为【L6.3 demo 字段铁律】，内容不变（运行时 AI 重写知识点时若附带 demo，仍需遵循 `<\/script>` 转义规则，因为重写结果是 JSON Output 模式直接写入 localStorage，不经 inject.py）。

**版本号与持久化**
12. **localStorage key 前缀改为 `tlh_L63_`**：避免加载 L6.2 的旧状态结构导致兼容问题。清除缓存按钮会一次性清掉 `tlh_L60_`、`tlh_L61_`、`tlh_L62_`、`tlh_L63_` 等所有前缀的数据。
13. **版本号统一更新为 L6.3 / L6.3-d**：页眉水印、SKILL、README、文件名示例、localStorage key 前缀、`_doRewriteKP` 提示词中的 demo 字段说明同步。两个发行版（开发者版 L6.3-d / 普通版 L6.3）的 template.html 仅差版本水印与 API Key 两行。

**L6.3 后续修订 · 2026.07.05 09:47（UTC+8）—— 演示框高度 bug 修复 + 全屏 + 适应一屏**
14. **修复演示重载高度累积 bug**：原 `autoResizeDemo` 在读 `doc.body.scrollHeight` 前未先把 iframe 自身高度归零。由于 iframe 高度被设大后，其内部 `body` 会被撑到那个高度（即使内容只有一点点），`scrollHeight` 因此返回上次的 inflated 值，下次再 `+20` 又累积，多次「🔄 重跑」或刷新后演示框出现大段空白。修复：`tryResize` 在测量前先 `frame.style.height='0px'`，让 body 收缩到真实内容高度，再读 `scrollHeight` 得到准确值；测量后再设回目标高度。同时 `rerunDemo` 在重新赋值 `srcdoc` 前先 `disconnect` 旧 `MutationObserver`（避免观察已废弃的 document）并把 `frame.style.height` 重置为 `200px`，从源头杜绝累积。
15. **演示全屏查看**：演示工具栏新增「⛶ 全屏」按钮（class `fs-btn`，蓝色系区分于紫色编辑按钮）。点击后 `fullscreenDemo(ci,ii)` 创建 `position:fixed;inset:0;z-index:9999` 的全屏浮层（class `kp-demo-fullscreen`），顶部一条渐变 bar 显示知识点名 + ✕ 关闭按钮，下方 `kpfs-body` 撑满剩余空间放 iframe（`srcdoc` 用知识点当前 `it.demo`）。关闭方式三选一：①按 Esc 键（`keydown` 监听器）；②点右上角 ✕ 按钮（`onclick="closeFullscreenDemo()"`）；③点击遮罩空白处（`overlay` 或 `.kpfs-body`，但不响应 iframe 内部点击——因为 iframe 捕获了点击事件不会冒泡到父文档）。打开时 `document.body.style.overflow='hidden'` 阻止背景滚动，关闭时还原。新增 `closeFullscreenDemo()` 函数移除浮层、解绑监听器、还原 overflow。
16. **演示高度限制一屏内可见**：原 `.kp-demo-frame` 用 `min-height:560px` 强制演示框至少 560px 高，长演示会撑出很长一段、需要滚动整个知识点区才能看完。L6.3 改为：① 移除 `min-height:560px`，改为 `min-height:200px`（防压扁）+ `max-height:calc(100vh - 280px)`（视口高减去约 280px 顶部留白，保证一屏内可放下）；② `autoResizeDemo` 的 `tryResize` 也按此上限 `Math.min(h+12, maxH)` 截断，超出时由 iframe 内部滚动而非撑开外层。这样无论演示内容多长，非全屏下也能在一屏内看完演示主体，需要看完整时可点「⛶ 全屏」展开。

**L6.3 后续修订 · 2026.07.05 10:06（UTC+8）—— 演示自动注入 KaTeX + Markdown**
17. **每个演示都默认支持 LaTeX + Markdown 渲染**：原 `_demoSysPrompt` 把 KaTeX 标为"可选，需要时才用"，要求 AI 在演示 HTML 的 `<head>` 里手动引入 KaTeX CSS + JS + auto-render CDN，并在 `<body>` 末尾调用 `renderMathInElement`。AI 经常忘记引入或引入出错，导致演示里的 `$...$` 公式显示成原始字符。L6.3 改为**页面自动注入**方案：新增 `wrapDemoSrcdoc(raw)` 函数，在把演示 HTML 设到 iframe 的 `srcdoc` 之前先包装一层——注入 KaTeX CSS + KaTeX JS + auto-render + marked JS + 一套 `.md` 元素的基础 Markdown 样式（标题/列表/表格/代码块/blockquote 等）+ 一个启动脚本。启动脚本在 DOM 加载后：① 用 `marked.parse` 渲染所有 `class="md"` 的元素（将其 `textContent` 当 Markdown 解析）；② 对整个 `document.body` 跑 `renderMathInElement` 把 `$...$` / `$$...$$` 渲染成公式。启动脚本还把 `bootRender` 暴露为 `window._demoRender`，演示内部 JS 动态改内容后可手动调用重新渲染。
18. **`wrapDemoSrcdoc` 的 `<\/script>` 还原**：演示 HTML 存储在 JSON 字符串里时，`</script>` 必须转义为 `<\/script>`（避免外层 `<script type="application/json">` 提前关闭）。`wrapDemoSrcdoc` 在包装前先把 `<\/script>` 还原成正常的 `</script>`，这样 iframe srcdoc 里的 `<script>` 标签能正确闭合、JS 正常执行。页面加载数据时也同步把每个 `it.demo` 里的 `<\/script>` 还原成 `</script>`（在 IIFE 加载循环里），让存储值统一为正常形式、编辑框里看到的也是正常 `</script>`。
19. **`_demoSysPrompt` 重写公式/Markdown 段落**：把原来的"公式渲染（可选，需要时才用）+ 手动引入 CDN"段落改为"公式与 Markdown 渲染（L6.3：自动注入，无需手动引入 CDN）"段落，明确告知 AI：① 直接用 `$...$` / `$$...$$` 写公式；② Markdown 文字放在 `class="md"` 的元素里；③ 动态更新后调 `window._demoRender()`；④ 不要重复引入 katex/marked CDN。删除了原来要求 AI 手动引入 KaTeX CDN 的 5 行模板代码与 `renderMathInElement` 调用说明。
20. **`_doRewriteKP` 提示词更新**：把【L6.3 demo 字段铁律】里"JSON 字符串里的 `</script>` 必须写作 `<\/script>`"改为"演示里直接写正常的 `</script>` 即可，无需手动转义——页面会用 wrapDemoSrcdoc 自动包装并注入 KaTeX + marked"；并新增"不要在 demo 里引入 katex/marked CDN（页面已自动注入）"。
21. **两处 `srcdoc` 赋值改用 `wrapDemoSrcdoc`**：① `rKP` 渲染演示 iframe 时（`demo-frame-{ci}-{ii}`）；② `fullscreenDemo` 全屏浮层的 iframe。两处都从 `escAttr(it.demo)` 改为 `escAttr(wrapDemoSrcdoc(it.demo))`。
22. **模板示例演示更新**：把 `learning-data` 里两个示例演示（动能计算器、动能定理可视化）改为使用新约定——加了一个 `class="md"` 的说明 div（含 `$...$` 公式与 Markdown 加粗/列表），结果区的 `E<sub>k</sub>` 改为 `$E_k=$`，演示内部 JS 在 `upd()` 末尾调 `window._demoRender()` 重新渲染动态变化的公式。让模板直接双击打开就能体现"每个演示都支持 LaTeX + Markdown"的 L6.3 特性。

---

## L6.2 · 2026.07.05 09:07（UTC+8）

L6.2 是一次聚焦「交互式演示体验 + 用户反馈 bug 修复」的更新，覆盖用户反馈的 6 个问题 + 后续 1 个布局 bug 修复：

**交互式演示重大增强**
1. **AI 编辑现有演示代码**：原有无 demo 时才能「🤖 AI 生成」，L6.2 新增「🤖 AI 编辑」按钮（有 demo 时显示），可让 AI 基于现有代码进行修改/优化。点击后弹出补充要求输入框，AI 会输出完整的修改后 HTML 文档（不是 diff），保存到 `it.demo` 并立即渲染。与 AI 生成共用 `_doAiGenDemo` 函数，通过 `existingDemo` 参数区分。
2. **演示 iframe 自动适配高度**：原 `.kp-demo-frame` 固定 `min-height:280px`，内容超出时 iframe 内部出现滚动条，用户得在演示区内滑鼠标。L6.2：① 默认 `min-height` 提升到 560px；② 新增 `autoResizeDemo(frame)` 函数，iframe `onload` 时读取 `contentDocument.body.scrollHeight` 自动设置高度，并通过 `MutationObserver` 监听内容变化动态调整，确保演示区永远不出现内部滚动条。
3. **AI 演示提示词大幅强化**：原提示词简短且要求 AI 把 `</script>` 写作 `<\/script>`（反斜杠转义），但演示是通过 iframe 的 srcdoc 渲染的（不存在外层 script 标签会被提前关闭的问题），导致 AI 生成的 `<\/script>` 在 srcdoc 中无法闭合 script 标签，整个页面空白。L6.2 重写 `_demoSysPrompt` 提示词：
   - 明确要求 AI 输出以 `<!DOCTYPE html>` 开头、`</html>` 结尾的完整 HTML 文档；
   - **明确禁止** AI 对 `</script>` 做反斜杠转义（必须写正常的 `</script>`）；
   - 提供完整的 HTML 结构模板（DOCTYPE / head / style / body / script）；
   - 列出 7 条常见错误（误写 `<\/script>`、输出代码围栏、用 prompt/alert、访问 localStorage、用 ES module、遗漏闭合标签、JS 在 DOM 加载前操作）；
   - 详细的 KaTeX CDN 引入示例；
   - 视觉要求细化：布局宽敞、padding 至少 16px、控件间距 8~12px。
4. **演示代码后处理兜底**：`_doAiGenDemo` 在保存 demo 前增加 `content.replace(/<\\\/script>/g,'</script>')`，把 AI 误写的 `<\/script>` 自动修正为 `</script>`，即使提示词明确要求 AI 仍可能误写。同时改进 markdown 代码围栏剥离逻辑：仅当首尾确实有围栏时才剥离（原 regex `^[\s\S]*?```...` 会误删 HTML 内的 ``` 字符串）。
5. **AI 演示 token 独立分桶**：原 `aiGenDemo` 调用 `addAux('rewrite',model,usage)`，演示生成的 token 计入「✏️ AI 重写」分桶，用户无法单独查看演示生成的开销。L6.2 新增 `aux.demo={}` 分桶，AI 生成/编辑演示的 token 计入「🤖 AI 演示」分桶；`globalMU`、`openStats`、`renderStats`、`loadState` 同步更新。

**用户反馈 bug 修复**
6. **教材目录/知识点概览/答题卡浮层移出滚动容器**：原 `.toc-overlay`、`.kp-overlay`、`.answer-card-overlay` 用 `position:absolute;inset:0` 且嵌套在 `#content-body`（左栏滚动容器）内。当用户在教材原文视图滚动到中下部时，点击「📑 目录」按钮，浮层会出现在内容顶部（已滚出视野），用户必须先滚回顶部才能看到浮层。L6.2 将三个浮层移出 `#content-body`，改为 `#col-content` 的直接子元素，并给 `#col-content` 加 `position:relative`，使浮层 `position:absolute` 相对于整个左栏定位，无论滚动到哪里都能覆盖整个左栏可见区域。
7. **清除缓存功能强化**：原 `clearAllCache` 函数直接 `location.reload()`，用户点击后页面瞬间重载，看不到任何反馈，误以为"不管用"。L6.2：① 清除后用 `sessionStorage.setItem('tlh_just_cleared', N)` 标记"刚清除 N 条"；② 重载后 `init` 函数检测此标记，弹 toast「✅ 缓存已清除（共 N 条），页面已回到初始状态」；③ 清除前先弹 toast「✅ 已清除 N 条缓存数据，正在重新加载…」并延迟 300ms 再 reload，让用户看到反馈；④ 增加多重兜底：先收集所有 `tlh_` 与 `tlhL` 前缀的 key，逐个 `removeItem` 并计数，再扫一遍确认无残留，最后 `location.reload(true)` 失败则降级到 `window.location.href=window.location.href` 再降级到 `location.reload()`。

**布局 bug 修复（二次审查）**
8. **测验栏双滚动条修复**：原 `.content-body` 设置 `overflow-y:auto`，而测验视图内部 `.quiz-body` 也设置 `overflow-y:auto`（flex:1）。当题目的 AI 解析很长时，`.quiz-body` 会出现内部滚动条（左侧），同时 `.content-body` 也会出现外部滚动条（右侧），两个滚动条并存且会把整个测验栏（含 head/nav/buttons）挤下去。L6.2：① 将 `.content-body` 改为 `overflow:hidden`，让它不再自身滚动，只作为各视图的容器；② 给 `#fulltext-area` 与 `#analysis-area` 加 `flex:1; overflow-y:auto` 内联样式，使这两个视图各自内部滚动（原来 fulltext 视图靠 content-body 滚动、analysis 视图靠 content-body 兜底滚动）；③ `getScrollContainer` 函数更新：full 视图返回 `fulltext-area`、analysis 视图返回 `analysis-area`（原来分别返回 content-body 和 analysis-area||content-body）；④ `jumpToToc` 改为操作 `fulltext-area`（原来操作 content-body）；⑤ 滚动监听 `attachScroll` 改为监听 `fulltext-area`（原来监听 content-body）。修复后：测验视图只有 `.quiz-body` 一个滚动条，head/nav/buttons 永远固定显示在栏内。

**版本号与持久化**
9. **localStorage key 前缀改为 `tlh_L62_`**：避免加载 L6.1 的旧状态结构导致兼容问题。清除缓存按钮会一次性清掉 `tlh_L60_`、`tlh_L61_`、`tlh_L62_` 等所有前缀的数据。
10. **版本号统一更新为 L6.2 / L6.2-d**：页眉水印、SKILL、README、文件名示例、localStorage key 前缀、`_doRewriteKP` 提示词中的 demo 字段说明同步。

---

## L6.1 · 2026.07.04 22:45（UTC+8）

L6.1 是一次聚焦「细节修复 + 实用新功能」的小版本更新，覆盖用户反馈的 9 个问题：

**渲染与排版修复**
1. **知识点标题/目录/概览支持 Markdown+LaTeX 渲染**：原 `rKP()` 中知识点标题用 `md()` 渲染后未调用 `renderMathIn()`，导致标题里的公式不渲染；知识点概览浮层与教材目录浮层此前用 `esc()` 直接转义，公式与 Markdown 标记全部显示为原始字符。L6.1 修复：三处均改用 `md()` 渲染并在设值后调用 `renderMathIn()`，标题/分类名/目录条目里的 `$...$`、`**加粗**` 等现在都能正常显示。
2. **清理 LaTeX 长度/间距命令**：新增 `cleanLatexLen()` 函数，自动清理 `\[4pt]`、`\[2ex]`、`\vspace{...}`、`\hspace{...}`、`\vskip`、`\hskip`、`\smallskip`、`\medskip`、`\bigskip`、`\vfill`、`\hfill`、`\newline`、`\par` 等会破坏 Markdown 渲染的 LaTeX 命令。`fixMath()` 与 `md()` 均接入此函数作为兜底；非数学部分还会清理裸 `[Npt]`/`[Nex]`。同时在所有 AI 系统提示词（聊天/出题/批阅/重写/讲解/AI 生成 demo）中加入【L6.1 长度命令铁律】，从源头禁止 AI 生成这些命令。

**AI 详解 bug 修复**
3. **修复题目 AI 详解流式输出失效**：`_doExplainQ` 的流式读取循环里漏了「140ms 节流刷新 UI」这一段（`explainKP` 有，`_doExplainQ` 没有），导致生成时 UI 永远不更新、始终显示「🧠 思考中…约 0 tok」。L6.1 补上 `var now=Date.now();if(now-_lastP>=140){_lastP=now;rQ();refreshAnalysis();}`，题目详解现在与知识点详解一样会流式刷新正文。
4. **刷新后详解状态自愈**：`loadState()` 恢复题目/知识点详解状态时，若发现 `__explainStatus` 仍为 `thinking` 或 `generating`（说明生成过程被刷新打断），自动重置为 `done`（有内容）或 `null`（无内容），避免刷新后永远卡在「思考中」。

**批阅与判分**
5. **不定项选择题支持部分正确算一半分**：`gradeObjective()` 原来只对 `multiple` 类型应用「漏选但没错选 → partial」规则，`indeterminate` 是严格匹配。L6.1 将规则扩展到 `indeterminate`：完全答对 → correct；漏选但没错选 → partial（半对）；错选或全错 → wrong。所有判断 `q.type==='multiple'&&q.__partial` 的地方（答题卡、状态类、得分统计、批阅数据视图、错题列表等）同步改为 `(q.type==='multiple'||q.type==='indeterminate')&&q.__partial`。测验页面不定项提示文字也加上「漏选但没错选可得一半分」。

**UI 修复与新增**
6. **AI 用量统计弹窗移出左栏**：原 `.stats-overlay` 用 `position:absolute;inset:0` 且嵌套在 `#content-body`（左栏）内，导致弹窗只覆盖左栏。L6.1 将 `<div id="stats-overlay">` 移到 `body` 直接子元素（与 `quiz-modal`、`extra-modal` 同级），CSS 改为 `position:fixed;top:0;left:0;width:100%;height:100%`，覆盖整个视口并居中显示。
7. **移除题目左上角重复的「📝 批阅」按钮**：每道题的 `q-tools` 工具栏里原来有一个「📝 批阅」按钮（`gradeBtn`），与测验导航栏的「📝 批阅」按钮（`#q-grade-one`）功能完全重复。L6.1 移除题目内的 `gradeBtn`，只保留导航栏的批阅按钮。
8. **答题卡当前题高亮 + 关闭按钮光标修复**：原 `.answer-dot.active` 只是 `border-width:3px;transform:scale(1.05)`，不够显眼。L6.1 改为 `border-width:4px` + `box-shadow:0 0 0 2px var(--primary-light),0 4px 10px rgba(58,90,156,.35)` + `font-weight:700`，用粗体边框 + 外圈光晕 + 加粗数字三重高亮当前题。同时为所有 `.close-x` 元素加 `cursor:pointer;user-select:none`，修复答题卡/知识点概览关闭按钮显示「I 形」文本光标的 bug（原 CSS 只为 `.toc-box .close-x` 和 `.stats-box .close-x` 设了 `cursor:pointer`，未覆盖 `.answer-card-box .close-x` 和 `.kp-overview-box .close-x`）。

**新功能**
9. **AI 自动生成交互式演示**：每个知识点在无 `demo` 时，除原有「➕ 添加演示」（手动编辑）外，新增「🤖 AI 生成」按钮。点击后弹出补充要求输入框（可指定要滑块/动画/公式推导等），确认后调用 DeepSeek（思考强度跟随当前设置）生成完整 HTML 文档（含 `<!DOCTYPE html>`、`<style>`、`<script>`，自包含、蓝紫主题配色、KaTeX CDN 渲染公式），自动剥离可能的 Markdown 代码围栏，保存到 `it.demo` 并立即渲染到 iframe。用量计入「✏️ AI 重写」分桶。
10. **左上角清除缓存按钮**：页面 header 左上角新增「🗑 清除缓存」按钮。点击后弹出确认框（列出会被清除的数据：对话/作答/批阅/详解/demo/设置），确认后遍历 `localStorage` 删除所有以 `tlh_` 开头的 key（覆盖所有版本、所有章节的缓存），然后 `location.reload()` 重新加载。取代了原来散落在「知识点为空」「测验为空」错误页里的「🔄 清除缓存重载」按钮。

**版本号与持久化**
11. **localStorage key 前缀改为 `tlh_L61_`**：避免加载 L6.0.1 的旧状态结构导致兼容问题。清除缓存按钮会一次性清掉 `tlh_L60_` 与 `tlh_L61_` 等所有前缀的数据。
12. **版本号统一更新为 L6.1 / L6.1-d**：页眉水印、SKILL、README、文件名示例、localStorage key 前缀同步。

**L6.1 二次审查 bug 修复（同版本号，代码内补丁）**
13. **delQ 删除题目后 _qIdx 偏移**：删除当前题之前的题时，`_qIdx` 没有前移，导致删除后跳到下一题。修复：`if(i<_qIdx){_qIdx--;}`。
14. **_startRegen 重新生成时 _qIdx 偏移**：同上，删除旧生成的题目后 `_qIdx` 也需要按"删除前 _qIdx 之前的题数"前移。修复：先统计 `_removedBeforeIdx`，过滤后 `_qIdx-=_removedBeforeIdx`。
15. **chat() / chatP() 缺少 null 检查**：若 `#chat-messages` 元素尚未就绪，`c.scrollTop` 会抛错。修复：函数开头加 `if(!c)return;`。
16. **sendChat / _startRegen 在 str=true 时静默返回**：用户点击"发送"或"重新生成"时如果已有消息在生成，函数直接 `return` 不提示，用户以为按钮失灵。修复：改为 `toast('有消息正在生成，请先停止或等待完成')` 后再返回。
17. **aiGenDemo 无并发保护**：用户在演示生成中再次点击「🤖 AI 生成」会发起并发请求，两个 fetch 竞争写入 `it.demo`。修复：新增 `_aiGenDemoBusy` 字典，进入时置 true，`finally` 中置 false，重复点击时 toast 提示"正在生成中"。
18. **_doRewriteKP / _doRewriteQ 不清除过时 AI 详解**：重写知识点或题目后，旧的 `__explain` / `__explainContent` 仍指向旧内容，用户切换"显 AI/显原"会看到与新内容不匹配的详解。修复：重写后清空 `__explain`、`__explainStatus`、`__explainContent`、`__explained`、`__origExplanation` 等字段，强制用户重新生成详解。
19. **tkFinal 在 _us 缺失时崩溃**：`var u=m._us,rea=u.rea||0` 若 `m._us` 为 undefined 会抛 TypeError。修复：`var u=m._us||{hit:0,miss:0,out:0,rea:0};`。
20. **答题卡当前题高亮被状态类覆盖**：CSS 中 `.answer-dot.active` 写在 `.answer-dot.todo/.done/.correct/.wrong/.partial` 之前，同优先级下后者覆盖前者的 `border-color`，导致当前题的蓝色边框被状态色（绿/红/黄）盖掉。修复：将 `.answer-dot.active` 移到所有状态类之后，并对 `border-color` 加 `!important` 确保高亮始终可见。
21. **rKP / rQ 错误页的清除缓存按钮与新 clearAllCache 不一致**：原内联按钮用 `localStorage.removeItem(stateKey())` 只清当前章节缓存，与新「🗑 清除缓存」按钮（清所有 `tlh_` 前缀）行为不一致。修复：错误页按钮统一改为 `onclick="clearAllCache()"`，文案改为「🗑 清除缓存重载」。
22. **AI 生成交互式演示改为流式输出**：原 `_doAiGenDemo` 用 `stream:false`，用户只能看到静态的「🤖 AI 正在生成交互式演示…」提示，无法知道进度。L6.1 改为 `stream:true` + `stream_options:{include_usage:true}`，与 `explainKP` / `sendChat` 一致的流式读取循环。生成过程中实时显示：思考阶段「🧠 思考中…约 N tok（仅显示估算，不展示思考过程）」，生成阶段「📝 生成代码中…约 N tok」+ 代码末尾 300 字符的暗色预览框（`<pre>` + esc 转义，避免 HTML 标签干扰）。140ms 节流刷新 UI。若用户在生成中切换到其他知识点（`emptyBox` 已脱离 DOM），`updStatus` 通过 `document.body.contains(emptyBox)` 检测后静默跳过，生成仍会在后台完成并保存到对应知识点。

---

## L6.0.1 · 2026.07.04 21:30（UTC+8）

L6.0.1 基于 DeepSeek 官方 API 文档，为所有需要 JSON 输出的 AI 调用启用专属的 JSON Output 模式，并按官方建议优化了 API 调用逻辑：

**JSON Output 模式（DeepSeek 官方推荐）**
1. **#出题 模式**：`sendChat` 在 `#出题` 指令触发时，请求体中添加 `response_format:{type:'json_object'}` 与 `max_tokens:8192`，确保 AI 输出合法 JSON 数组，避免解析失败。续写（continueGen）时同样启用。
2. **AI 批阅**：`gradeSubjective` 请求体中添加 `response_format:{type:'json_object'}` 与 `max_tokens:8192`，确保批阅结果（评分 + 评语 + 看法评价）为合法 JSON。
3. **AI 重写题目**：`_doRewriteQ` 请求体中添加 `response_format:{type:'json_object'}` 与 `max_tokens:4096`。
4. **AI 重写知识点**：`_doRewriteKP` 请求体中添加 `response_format:{type:'json_object'}` 与 `max_tokens:4096`。
5. 所有涉及 JSON 输出的 system prompt 均已包含 "JSON" 字样与格式样例（DeepSeek 官方要求：使用 JSON Output 时 prompt 中必须含 json 字样并给出格式样例）。

**API 调用逻辑优化（按 DeepSeek 官方建议）**
6. **思考模式参数**：DeepSeek 官方文档指出思考模式下 `temperature` / `top_p` 等参数不生效（不会报错但无效）。本版保留这些参数以兼容非思考模式（`thinking:{type:'disabled'}` 时仍生效），不删除。
7. **多轮对话上下文**：确认已按官方建议——在两个 user 消息之间，未进行工具调用的 assistant 的 `reasoning_content` 无需回传给 API（当前代码仅回传 `content`，不回传 `reasoning_content`，符合官方建议）。
8. **上下文硬盘缓存**：DeepSeek 的硬盘缓存默认开启、无需修改代码。当前代码已正确读取 `usage.prompt_cache_hit_tokens` 与 `prompt_cache_miss_tokens` 并纳入 token 统计。system prompt 结构保持稳定（人设 → 教材 → 摘要 → 知识点 → 题库），有利于缓存命中。
9. **对话前缀续写**：`continueGen` 已正确使用 `base_url=beta`、最后一条消息 `role=assistant` + `prefix=true`，符合官方 Beta 功能要求。

**Bug 修复（聊天分支功能）**
10. **修复查看历史快照时重复渲染 assistant 消息**：`chat()` 函数中，当 `isSnap=true`（使用历史快照渲染）时，未跳过下一条 assistant 消息，导致 DOM 中出现重复的 assistant 消息。修复：在 `isSnap=true` 分支中也执行 `i++` 跳过下一条 assistant。

---

## L6.0 · 2026.07.04 12:00（UTC+8）

L6.0 是一次大刀阔斧的换代重构，从三栏布局回归两栏，知识点与题目均改为单页展示，并引入交互式演示等全新能力：

**开发者的话**

我曾经基于v5.6继续更新了v6系列，一直更新到v6.4。但是发现v6系列增加的功能几乎没用，而且需要的AI性能/tokens/bug多了很多。所以我决定放弃v6系列，重新回到v5.6，换个更新方向开发了现在的L6系列。v6系列的zip仍然留档，如果你感兴趣的话可以找我要，但是我不会再更新这个系列或者维护它的bug了。

**布局与导航**
1. **三栏改两栏**：移除独立的中栏「测验」，改为左栏顶部 tab 切换「知识点 / 教材原文 / 测验 / 批阅数据」四个子视图；右栏仍为 AI 对话。列宽可拖动。
2. **目录跳转 bug 修复**：修复 v5.6 中点教材目录浮层条目无法跳到对应位置的 bug——原代码操作的是 `fulltext-area.scrollTop`（无 `overflow-y:auto`），实际滚动的是其祖先 `content-body`；L6.0 改为操作正确的滚动容器。

**知识点重构（重点）**
3. **单页展示**：左栏知识点视图一页只展示一个知识点，顶部导航「上一个 / 目录 / 下一个」；点「目录」弹出知识点概览浮层（按分类列出全部知识点，点击跳转）。
4. **交互式演示**：每个知识点可选附 `demo` 字段（HTML+CSS+JS 字符串），在 sandboxed iframe 中独立渲染为可交互的演示界面。点「✏️ 编辑」可手动修改代码并保存；点「🔄 重跑」可重新运行；让 AI 重写知识点时可要求附带 demo。AI 在生成 HTML 时会对每个知识点认真打磨：文字、公式、交互式演示都能让学生一目了然看懂且不失严谨，三者均支持 AI 后期修改。
5. **AI 详解可收起 / 流式**：保留 v5.6 的 AI 详解能力，知识点与题目的详解右上角有「👁 收起 / 👁 展开」按钮；思考阶段显示「🧠 思考中…约 N tok」，生成阶段流式填充正文。

**测验重构**
6. **单页一题一屏**：测验视图一屏只显示一道题，无滚动列表，改为「上一题 / 答题卡 / 批阅 / 下一题」按钮切换。最后一题时「下一题」按钮位置变为「全部批阅」。
7. **答题卡**：新增答题卡浮层，圆形彩点网格显示做题情况——白色=未做、蓝色=做了没批、绿色=对、红色=错、黄色=半对。答题卡高度只够两行，鼠标滚轮可滚动查看更多题目。
8. **多选题批阅规则重做**：多选题漏选但没错选得一半分（partial），完全答对得满分，错选或全错得 0 分。批阅视图与得分统计中多选题半对按 0.5 分计算。

**教材原文**
9. **特殊内容高亮**：教材原文中的定义 / 公式 / 定理 / 推论 / 引理 / 性质 / 例题 / 注释若以 blockquote + 对应标记开头，页面会自动套上彩色边框与标签，把整段内容包到样式内，一目了然。
   - `> 📖 **定义** ...` → 蓝色边框「📖 定义」
   - `> 📐 **公式** ...` → 橙色边框「📐 公式」（居中）
   - `> 📊 **定理** ...` → 紫色边框「📊 定理」
   - `> 📎 **推论** ...` → 绿色边框「📎 推论」
   - `> 📝 **引理** ...` → 青色边框「📝 引理」
   - `> 💡 **性质** ...` → 粉色边框「💡 性质」
   - `> 📖 **例题** ...` 或 `> 【例 X.Y】 ...` → 橙色边框「📖 例题」（沿用 v5.6）
   - `> 📝 **注释** ...` → 灰色边框「📝 注释」

**AI 与公式**
10. **行内公式格式优化**：原 v5.6 的 `applyDisplayStyle` 对所有行内公式无脑加 `\displaystyle` 与 `\dfrac`；L6.0 改为智能判断：
    - 行内公式仅当含 `\sum` `\int` `\lim` `\prod` `\oint` `\bigcup` `\bigcap` `\max` `\min` 等大型运算符时才加 `\displaystyle`；其他不加。
    - 含 `\frac` 的（除上下标 `_{...}`/`^{...}` 内的小字外）一律改 `\dfrac`；上下标内的 `\frac` 保持原样。
    - **行间公式 `$$...$$` 内不写 `\displaystyle`，不写 `\dfrac`，分数用 `\frac`**。
11. **理解强度替代深度理解**：聊天设置区的「🔬 深度理解」开关改为「💡 理解强度」下拉，三档：
    - **无**：系统提示词只有最基本人设与输出要求，不含知识点/题库/教材全文，最省 token。
    - **标准**：含教材摘要、全部知识点、全部题目及作答情况（默认；等同原 v5.6「深度理解 关闭」）。
    - **深度**：在标准基础上附教材全文（FULLTEXT），理解最精准但最费 token（等同原 v5.6「深度理解 开启」）。
12. **SKILL.md 精简**：删除冗余表述、合并重复段落、压缩示例，token 消耗量显著下降，但功能完全没有删减。

**UI 与杂项**
13. **整体 UI 重做**：配色升级为现代蓝紫渐变 + 暖橙强调，圆角与阴影更柔和，按钮 hover 反馈更明显；表格、blockquote、KaTeX 行间公式等均补齐样式。
14. **状态持久化扩展**：localStorage 现额外保存当前知识点索引、当前题目索引、各知识点 demo 代码与 AI 详解状态，刷新/重开后回到原位。
15. **版本号统一**：全局更新为 L6.0 / L6.0-d，页眉水印、SKILL、README、文件名示例、localStorage key 前缀（`tlh_L60_`）同步。

---

## v5.6 · 2026.06.30 10:30（UTC+8）

v5.6 围绕 AI 详解体验、出题交互、教材原文保真度与状态持久化做了 10 项功能改进：

**AI 详解**
1. **详解可收起**：知识点与题目的 AI 详解右上角新增「👁 收起 / 👁 展开」按钮，可一键隐藏详解内容；题目的 AI 详解与原解析可通过「💡 显原 / 🤖 显 AI」按钮互相切换，便于对比。
2. **详解流式输出**：「🔎 讲解」改为流式生成。思考阶段在原位显示「🧠 思考中…约 N tok（仅显示估算，不展示思考过程）」；生成阶段流式填充正文带闪烁光标。**不展示思考过程本身，只显示估算的思考 token 数**，避免长思考时白屏。

**出题交互**
3. **出题模式开关**：聊天输入框上方新增「📝 出题模式」复选框。开启后发送的每条消息会自动在开头加上 `#出题 ` 指令，AI 会以 JSON 形式出题并写入题库；关闭时为普通对话。开关状态持久化。
4. **无 #出题 也出题**：旧版逻辑中，学生让 AI 出题但消息里没有 `#出题` 指令时，AI 直接拒绝出题。v5.6 改为：AI 用普通 Markdown 文本形式出题（含题干、选项、参考答案、解析），但不会输出 JSON 数组、也不会写入题库——只作为对话中的练习内容展示。只有显式 `#出题` 才会以 JSON 形式输出并写入题库。
5. **选择题选项强制 A/B/C/D**：options 键必须为大写字母 A/B/C/D...，严禁 0/1/2/3 等数字格式。SKILL.md 在多处反复强调；页面 `normOptsFull` 也增加了兜底，遇到数字键会自动转为对应字母（0→A、1→B…）。

**教材原文**
6. **教材原文不得删减**：SKILL.md 铁律升级——AI 生成 fulltext 字段时必须忠实保留全部原文内容，不得删减、不得省略、不得"概括"。包括正文段落、例题、定理证明、注释、表格、公式等。只允许做格式转写（如 PDF 两栏排版 → 单栏 Markdown）。
7. **教材目录浮层**：教材原文视图栏标题新增「📑 目录」按钮，点击弹出浮层显示本章节的章/节/小节结构（解析自 fulltext 中的 `##`/`###`/`####` 标题）。点击任一条目自动关闭浮层并将教材原文滚动到该位置。
8. **例题显眼样式**：教材原文中的例题若以 blockquote + 「📖 例题」或「【例 X.Y」开头，页面会自动给它套上橙色边框 + 「📖 例题」标签的显眼样式（class `ft-example`），一眼区分例题与知识点。

**状态持久化**
9. **三栏滚动位置互相独立**：批阅数据、教材原文、知识点、测验四个滚动位置互相独立保存到 localStorage。切回任一视图都会恢复该视图上次离开时的位置。`quizScroll`（测验）、`analysisScroll`（批阅数据）、`kpScroll`（知识点）、`fullScroll`（教材原文）四个变量互不干扰。

**AI 提示词**
10. **排除选项写入提示词**：学生在多选/不定项题中右键排除的选项，会作为「我已排除的选项：A、C」写入 AI 系统提示词。AI 会据此分析学生的排除思路是否合理，给出更贴合的讲解。

---

## v5.5 · 2026.06.28 08:42（UTC+8）

v5.5 聚焦三栏交互细节修复、AI 讲解能力扩展，以及教材原文 / 深度理解两大新功能：

**布局与栏标题**
1. **栏标题真正吸顶**：修复知识点 / 测验栏标题在下滑时上方露出内容的问题——移除栏位顶部内边距、让标题自带内边距并贴合栏顶，滚动时标题始终钉在最上方。
2. **测验栏标题显示批阅概览**：标题在「已答 X/总数」之外，新增「得分 X/总分」、橙色得分条与百分比（主观题按 AI 评分÷10 折算，仅统计已批阅题目）。

**AI 能力**
3. **新增「🔎 讲解」详解功能**：每个知识点、每道已批阅题目的右上角新增讲解按钮。知识点详解显示在该卡片所有内容下方；题目详解会替换原解析，且选择题【逐个选项】讲为什么对/错、填空题【按空】、解答题【按小问】拆解。用量计入底部「🔎 AI 详解」分桶。
4. **强化 displaystyle 要求**：聊天、出题两处系统提示词均加重「行内公式必须以 `\\displaystyle` 开头、分数一律 `\\dfrac` 而非 `\\frac`」的铁律与逐处自检要求。
5. **出题解析规范升级**：出题时要求 explanation 详细且分型——选择题逐选项、填空题按空、解答题按小问讲解。
6. **AI 出题专用指令 `#出题`**：只有消息中显式包含 `#出题` 才会进入出题模式（输出 JSON、隐藏生成过程并写入题库）；否则一律当普通对话用文字回答，不再凭关键词猜测出题意图。「📋 出题」弹窗已自动带上该指令。

**新功能**
7. **教材原文查看**：新增 `fulltext` 数据字段，AI 生成时把所学章节教材全文转写为规范 Markdown 填入；左栏标题上的按钮可在「知识点」与「（渲染后的）教材原文」间切换，无原文时按钮自动隐藏。
8. **AI 深度理解开关**：聊天设置区新增「🔬 深度理解」勾选项。开启后系统提示词附带教材全文，理解更精准但更费 token；关闭则只含摘要与知识点，省钱但理解较弱。状态随页面持久化。

**作答交互**
9. **被排除选项可一键选中**：多选 / 不定项题中被红叉排除的选项，左键单击即可直接取消排除并选中，无需先右键还原。

**Bug 修复**
10. **发送空消息 / 残留输入框修复**：修复点击「发送」按钮时把鼠标事件误当作重新生成参数、导致发出空内容且输入框文本不清空的问题；空白提示词现在无法发送（快捷键路径本就正常）。
11. **重新生成后的用量统计修复**：某条消息被重新生成后，当前对话的 token 与计价统计现已包含所有历史生成版本，而非只算最新一条。
12. **类名冲突修复**：题目「讲解」按钮与既有解析框的样式类名冲突已修正；知识点标题增加右边距，避免与右上角按钮重叠。

**版本与文档**
13. **版本号统一**：全局更新为 v5.5 / v5.5-d，页眉水印、SKILL、README、文件名示例同步。

---

## v5.0 · 2026.06.27 10:40（UTC+8）

v5.0 是一次较大的交互与功能升级，覆盖测验、批阅、聊天三栏的多处体验改进与 bug 修复：

**布局与批阅**
1. **批阅数据并入中间栏**：移除右下角可拖动的「📊」悬浮球与悬浮窗，改为在中间「测验」栏标题上加切换按钮，在「测验」与「批阅数据」之间切换显示，节省屏幕空间、避免遮挡。
2. **测验进度移入栏标题**：测验栏标题实时显示「已答 X/总数」与迷你进度条，按已作答题数递增（不再等到批阅后才更新）；旧版进度条从不填充的 bug 一并修复。
3. **知识点 / 测验栏标题置顶吸附**：滚动列内容时两栏标题始终固定在顶部。
4. **从批阅返回测验自动恢复滚动位置**：离开测验前记录滚动位置并持久化，返回时回到原处。
5. **每题单独「批阅本题」按钮**：每道题右上角可单独批阅；总提交批阅时会跳过已批阅的题目，不重复计费。
6. **批阅后追加新题的计分修复**：批阅后再出的新题显示「未批阅」而非判错；总分只统计已批阅的题目。

**测验作答**
7. **客观题右键排除选项**：多选 / 不定项题可右键点击某选项将其标记为排除（红色 ✕、删除线、禁用），再次右键取消；排除状态持久化。

**聊天与生成**
8. **关闭其它对话不再中断本次生成**：流式生成改用稳定对象引用，关闭无关对话不会打断正在进行的生成。
9. **中键快速删除对话**：鼠标中键点击对话标签即可删除该对话。
10. **Ctrl+Enter（或 Cmd+Enter）发送消息**。
11. **被停止的回复可「继续生成」**：对中途停止的回复，新增「▶️ 继续生成」按钮，基于 DeepSeek「对话前缀续写」（beta）接着原文续写，思考内容亦可延续。
12. **被停止的消息在历史导航中正常显示**：停止标记、原始文本与思考过程均随生成历史快照持久化。
13. **重写 / 重新批阅 / 重新生成可附加额外要求**：触发时弹出输入框，可填写额外说明；重写一道已批阅的主观题后会自动重新批阅。
14. **用户消息改为左对齐**，与助手消息统一阅读方向。
15. **空内容发送修复**：杜绝空 `content` 导致 API 报「missing field content」。

**AI 输出规范**
16. **加强禁用 `\cdotp`**：在聊天、出题、重写、批阅各系统提示中强化，乘号一律 `\cdot`。
17. **统一简体中文输出**：聊天、出题、自动命名等所有 AI 输出统一使用简体中文。
18. **选择题题干不含选项**：出题时单选/多选/不定项的题干不再混入各选项内容，选项只放在 options 字段。

**版本与文档**
19. **版本号统一**：全局版本号更新为 v5.0 / v5.0-d，页眉水印随发行版区分。
20. **生成文件名标准化**：统一为 `技能版本_教材_章节.html`（如 `v5.0-d_线性代数_6.2特征向量与特征值.html`）。
21. **更新记录加时间戳**：自本版起每条记录标注 UTC+8 发布时间，并为既往版本补全时间。

---

## v4.5 · 2026.06.25 17:36（UTC+8）

v4.5 在 v4.4 基础上重写聊天栏的「重新生成」体验：

1. **薛定谔按钮修复**：旧逻辑在流式完成后先调 `chat()` 再把 `str` 置 `false`，导致渲染时 `!str` 仍为 `false`、重新生成按钮从不出现。现改为 `str=false` 先于 `chat()`，按钮 100% 显示。
2. **被停止的回答也可重新生成**：按下「⏹ 停止」后，助手消息带 `_aborted` 标记但 `_st=false`，满足渲染条件，立即出现重新生成按钮。
3. **生成历史导航（类 Claude.ai `< N/M >`）**：每条用户消息分配唯一 `_slotId`，`_gens[]` 存储该位置所有生成版本（用户提问内容 + 对应助手快照）。每次重新生成推入新槽并保留旧槽，用户消息右下角显示 `‹ N/M ›` 箭头，可在历史版本间自由切换查看，不影响会话主线。导航状态随 localStorage 持久化，刷新后仍可翻阅。
4. **编辑提示词后重新生成**：用户消息右下角增加 ✏️ 编辑按钮，点击展开行内编辑区，修改后点「重新生成」即以新内容发起请求，旧版本仍保留在 `‹ 1/2 ›` 里可回溯。
5. **页面标题加版本水印**：header 小字新增「由 textbook-learning-helper v4.5 生成」，便于用户在导出的 HTML 中追溯来源。

---

## v4.4 · 2026.06.25 16:53（UTC+8）

v4.4 在 v4.3 基础上新增双发行版机制与 README 文档：

1. **双发行版（开发者版 / 普通版）**：从本版起，每次发布均同时提供两个 zip 包。开发者版（`-d` 后缀）保留 API Key 原样写入模板，并在 SKILL.md 中要求 Claude 每次生成 HTML 后都提醒开发者分享前须清除 Key；普通版将模板中的 Key 替换为占位符 `<your-api-key>`，SKILL.md 在生成 HTML 前强制检查 Key 是否已填写，未填写则拒绝生成并主动询问用户提供 Key。
2. **inject.py 新增 `--key` 参数**（仅普通版）：普通版 inject.py 支持 `--key <api-key>` 参数，收到参数后自动将模板中的 `<your-api-key>` 替换为真实 Key 后再执行注入；若模板仍含占位符且未传 `--key`，则报错退出。
3. **新增 README.md**：两个发行版各附一份中文 README，包含技能介绍、使用说明、许可证、开发者信息等内容；开发者版另加内部保密提示，普通版另加 Key 填写指引。

---

## v4.3 · 2026.06.25 15:52（UTC+8）

v4.3 在 v4.2 基础上修复 1 处交互 bug：

1. **多选题校验不再导致页面位移**：原逻辑在检测到多选题仅选 1 项时，会调用 `el.scrollIntoView({block:'center'})`，该 API 会连带滚动所有祖先可滚动容器，包括浏览器视口，导致三栏布局整体上移、顶部标题滚出视野。现改为直接操作 `#col-quiz` 列容器的 `scrollTop`，只在题目列内部定位，页面其余部分不受影响。

---

## v4.2 · 2026.06.25 10:34（UTC+8）

v4.2 在 v4.1 基础上修了几处运行时 bug 并做了无损优化，所有既有功能保留：

1. **移动端布局修复**：原 `@media(max-width:900px)` 用的是 `grid-template-columns`，但 `.main-layout` 是 flex 容器、该规则无效，窄屏下三栏被挤成一排。现改为竖向堆叠（隐藏拖动分隔条、各栏占满宽度），手机/窄窗也能正常使用；桌面端不受影响。
2. **Markdown 表格样式**：内嵌 AI 被要求用 GFM 表格作答，但此前 `.md-content table` 无样式、表格无边框错乱。现补齐表格/表头/斑马行样式。
3. **聊天历史省 token**：以往每轮都把"已生成题目"的整段 JSON 当历史重发，而该题库本就已在 system 上下文里。现历史中只放简短占位，省下重复 token，不影响模型对题目的感知。
4. **防抖保存**：填空/解答/看法输入框原先每次击键都全量序列化写 localStorage，长会话会卡。现按键路径改为防抖（500ms）保存，结构性操作与离开页面（`beforeunload`/页面隐藏）仍即时保存，杜绝丢数据。

---

## v4.1 · 2026.06.24 21:00（UTC+8）

v4.1 在 v4.0 基础上修复一处渲染问题，其余能力与 v4.0 完全一致：

1. **禁用 `\cdotp`**：`\cdotp` 在 KaTeX 下渲染错误，乘号一律改用 `\cdot`。SKILL 与内嵌 DeepSeek 的出题/批阅/重写/聊天系统提示均已写明该规则；同时在页面渲染入口 `fixMath()` 加了兜底替换，凡 `\cdotp`（含数据与任何 AI 输出）渲染前都自动转为 `\cdot`，不影响已有的 `\cdot`、`\cdotplus` 等。

---

## v4.0 · 2026.06.24 18:55（UTC+8）

v4.0 与 v3.7 运行时模板**完全一致**（六大题型、本地判分+AI 批阅、Markdown 全程渲染、多对话/计价/再出题、robustParse 双写兼容、autoMath 兜底、空白三栏三重防线、displaystyle 后处理等能力全部保留），仅优化技能的使用方式以省 token：

1. **模板抽离为 `references/template.html`**：不再嵌在 markdown 代码块里，生成时无需把整份模板读进上下文。
2. **新增注入脚本 `references/inject.py`**：你只产出 JSON 数据，脚本负责严格校验（含 `</script>` 拦截）并注入模板——避免逐字重打整份 HTML，省下大量输入与输出 token。
3. **精简文档**：移除冗长修复历史与重复说明，仅保留生成所需信息。

---

## v3.7 及更早

v3.7 及之前版本的更新记录已被删除，开发者也找不到了。
