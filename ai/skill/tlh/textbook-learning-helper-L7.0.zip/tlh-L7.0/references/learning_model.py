"""课本学习助手共用的数据模型 v2 与确定性题目质量门禁。"""

from __future__ import annotations

import hashlib
import math
import re
import unicodedata
from collections import Counter
from difflib import SequenceMatcher


SCHEMA_VERSION = 2
STANDARD_TYPES = {"single", "multiple", "indeterminate", "judge", "fill", "essay"}
PYTHON_TYPES = {"single", "multiple", "indeterminate", "judge", "code"}
_IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{2,127}$")
_BOUNDARY_HINT = re.compile(r"边界|最小|最大|零值|空值|负数|异常|越界|极端|boundary|edge|min|max|zero|empty|negative|invalid", re.I)
_DIFFICULTY = {
    "easy": "easy", "basic": "easy", "beginner": "easy", "基础": "easy", "简单": "easy", "容易": "easy",
    "medium": "medium", "normal": "medium", "intermediate": "medium", "中等": "medium", "一般": "medium", "普通": "medium",
    "hard": "hard", "advanced": "hard", "difficult": "hard", "困难": "hard", "较难": "hard", "高级": "hard",
}


class LearningModelError(ValueError):
    pass


def _text(value):
    return str(value or "").strip()


def _canonical(value):
    value = unicodedata.normalize("NFKC", _text(value)).casefold()
    value = re.sub(r"[`*_~$\\]", "", value)
    return "".join(character for character in value if character.isalnum())


def _distinctive_alnum(value):
    value = unicodedata.normalize("NFKC", _text(value)).casefold()
    return "".join(character for character in value if character.isalnum() and not ("\u3400" <= character <= "\u9fff"))


def stable_id(prefix, *parts):
    digest = hashlib.sha256("\x1f".join(_canonical(part) for part in parts).encode("utf-8")).hexdigest()[:16]
    return "%s-%s" % (prefix, digest)


def _identifier(value, fallback):
    value = _text(value) or fallback
    if not _IDENTIFIER.fullmatch(value):
        raise LearningModelError("稳定 ID 格式无效：%s（只能使用字母、数字、点、下划线、冒号或连字符）" % value)
    return value


def _aliases(value, *required):
    raw = value if isinstance(value, list) else ([] if value in (None, "") else [value])
    out = []
    for item in list(raw) + list(required):
        item = _text(item)
        if item and item not in out:
            out.append(item)
    return out


def _register_alias(alias_map, alias, entity_id):
    existing = alias_map.get(alias)
    if existing and existing != entity_id:
        raise LearningModelError("迁移别名 %s 同时指向 %s 与 %s；每个别名只能属于一个稳定 ID" % (alias, existing, entity_id))
    alias_map[alias] = entity_id


def _difficulty(value):
    raw = _text(value).lower()
    normalized = _DIFFICULTY.get(raw)
    if not normalized:
        raise LearningModelError("难度必须属于简单/中等/困难（或 easy/medium/hard），当前为：%s" % value)
    return normalized


def _explicit_answer(explanation):
    for line in _text(explanation).splitlines():
        match = re.match(r"^\s*(?:[-*>]\s*)*(?:\*\*)?(?:正确答案|答案)(?:\*\*)?\s*(?:[:：]|为)\s*([A-Z]{1,8}|对|错)(?:\s|[，,。；;]|$)", line.upper())
        if match:
            return match.group(1)
    return ""


def _question_similarity(left, right):
    distinctive_left, distinctive_right = _distinctive_alnum(left), _distinctive_alnum(right)
    left, right = _canonical(left), _canonical(right)
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    if min(len(left), len(right)) < 8:
        return 0.0
    score = SequenceMatcher(None, left, right).ratio()
    if distinctive_left != distinctive_right and (distinctive_left or distinctive_right):
        score = min(score, 0.89)
    return score


def _quality_gate(kp_data, questions, python_mode):
    allowed = PYTHON_TYPES if python_mode else STANDARD_TYPES
    types = Counter()
    difficulties = Counter()
    covered_ids = set()
    all_items = []
    categories = {}

    for category in kp_data:
        category_id = category["id"]
        categories[category_id] = set()
        for item in category.get("items") or []:
            all_items.append(item)
            categories[category_id].add(item["id"])

    for index, question in enumerate(questions):
        label = "第 %d 题" % (index + 1)
        qtype = _text(question.get("type"))
        if qtype not in allowed:
            raise LearningModelError("%s 的题型不属于当前版本允许范围" % label)
        types[qtype] += 1
        normalized_difficulty = _difficulty(question.get("difficulty"))
        question["difficultyLevel"] = normalized_difficulty
        difficulties[normalized_difficulty] += 1
        covered_ids.update(question.get("kpIds") or [])

        if qtype in {"single", "multiple", "indeterminate"}:
            options = question.get("options") or {}
            normalized_options = [_canonical(value) for value in options.values()]
            if len(normalized_options) != len(set(normalized_options)):
                raise LearningModelError("%s 含重复或仅标点不同的选项，干扰项质量不合格" % label)
            explicit = _explicit_answer(question.get("explanation"))
            if explicit and explicit != _text(question.get("answer")).upper():
                raise LearningModelError("%s 的解析声明答案 %s，但 answer 为 %s" % (label, explicit, question.get("answer")))
        elif qtype == "judge":
            explicit = _explicit_answer(question.get("explanation"))
            if explicit in {"对", "错"} and explicit != _text(question.get("answer")):
                raise LearningModelError("%s 的解析与判断答案矛盾" % label)

        if python_mode and qtype == "code":
            cases = question.get("testCases") or []
            names = [_text(case.get("name")) for case in cases if isinstance(case, dict)]
            if len(names) != len(set(names)):
                raise LearningModelError("%s 的 Python 检验组名称重复" % label)
            if not any(bool(case.get("boundary")) or _BOUNDARY_HINT.search(_text(case.get("name"))) for case in cases if isinstance(case, dict)):
                raise LearningModelError("%s 至少要有一组 boundary=true 或名称明确标注为边界/异常检验" % label)

    for left in range(len(questions)):
        for right in range(left + 1, len(questions)):
            similarity = _question_similarity(questions[left].get("text"), questions[right].get("text"))
            if similarity >= 0.92:
                raise LearningModelError("第 %d 题与第 %d 题过于相似（相似度 %.0f%%）" % (left + 1, right + 1, similarity * 100))

    minimum_types = 3 if python_mode else 4
    if len(questions) >= 6 and len(types) < minimum_types:
        raise LearningModelError("题型分布过于单一：至少覆盖 %d 种题型" % minimum_types)
    if types and max(types.values()) > max(3, math.ceil(len(questions) * 0.60)):
        raise LearningModelError("题型分布过于集中：单一题型不得超过全部题目的 60%%")
    if len(questions) >= 6 and len(difficulties) < 2:
        raise LearningModelError("难度分布过于单一：至少覆盖简单/中等/困难中的两档")

    required_coverage = min(len(all_items), len(questions), max(1, math.ceil(len(all_items) * 0.60)))
    if len(covered_ids) < required_coverage:
        raise LearningModelError("知识点覆盖不足：至少覆盖 %d 个，当前覆盖 %d 个" % (required_coverage, len(covered_ids)))
    if len(questions) >= len(categories):
        missing_categories = [category_id for category_id, item_ids in categories.items() if not covered_ids.intersection(item_ids)]
        if missing_categories:
            raise LearningModelError("知识点分类覆盖不足，未覆盖分类：%s" % "、".join(missing_categories))
    if python_mode and types.get("code", 0) < 1:
        raise LearningModelError("Python 学习页至少需要一道代码题")

    return {
        "passed": True,
        "questionCount": len(questions),
        "typeCounts": dict(sorted(types.items())),
        "difficultyCounts": dict(sorted(difficulties.items())),
        "knowledgePointCount": len(all_items),
        "coveredKnowledgePointCount": len(covered_ids),
    }


def upgrade_and_validate(meta, kp_data, questions, chapters=None, python_mode=False):
    """原地升级输入对象并返回要写入 learning-data 的 v2 元数据。"""
    if not isinstance(meta, dict):
        raise LearningModelError("meta.json 必须是对象")
    if not isinstance(kp_data, list) or not isinstance(questions, list):
        raise LearningModelError("kp.json 与 questions.json 必须是数组")

    book = _text(meta.get("book"))
    if not book:
        raise LearningModelError("meta.json 缺少 book")
    book_id = _identifier(meta.get("bookId"), stable_id("book", book))
    content_version = _text(meta.get("contentVersion") or meta.get("version") or "1")

    if chapters:
        chapter_records = chapters
    else:
        chapter_title = _text(meta.get("chapter")) or "当前章节"
        chapter_records = [{
            "id": meta.get("chapterId"),
            "title": chapter_title,
            "chapter": chapter_title,
            "summary": _text(meta.get("summary")),
            "aliases": meta.get("chapterAliases"),
            "version": meta.get("chapterVersion") or content_version,
        }]

    chapter_ids = []
    seen_chapter_ids = set()
    alias_map = {}
    for index, chapter in enumerate(chapter_records):
        title = _text(chapter.get("title") or chapter.get("chapter") or "第%d章" % (index + 1))
        chapter_id = _identifier(chapter.get("id"), stable_id("chapter", book_id, title))
        if chapter_id in seen_chapter_ids:
            raise LearningModelError("章节稳定 ID 重复：%s" % chapter_id)
        seen_chapter_ids.add(chapter_id)
        aliases = _aliases(chapter.get("aliases"), "legacy:chapter:%d" % index, "chapter-title:" + _canonical(title))
        chapter["id"] = chapter_id
        chapter["aliases"] = aliases
        chapter["version"] = _text(chapter.get("version") or content_version)
        chapter_ids.append(chapter_id)
        for alias in aliases:
            _register_alias(alias_map, alias, chapter_id)

    kp_by_name = {}
    kp_by_id = {}
    category_ids = set()
    knowledge_name_counts = Counter(
        _canonical(item.get("name"))
        for category in kp_data
        for item in (category.get("items") or [])
        if isinstance(item, dict) and _text(item.get("name"))
    )
    for category_index, category in enumerate(kp_data):
        category_name = _text(category.get("cat"))
        category_id = _identifier(category.get("id"), stable_id("kpc", book_id, category_name))
        if category_id in category_ids:
            raise LearningModelError("知识点分类稳定 ID 重复：%s" % category_id)
        category_ids.add(category_id)
        category["id"] = category_id
        category["aliases"] = _aliases(category.get("aliases"), "legacy:kpc:%d" % category_index)
        category["version"] = _text(category.get("version") or content_version)
        for alias in category["aliases"]:
            _register_alias(alias_map, alias, category_id)
        for item_index, item in enumerate(category.get("items") or []):
            name = _text(item.get("name"))
            item_id = _identifier(item.get("id"), stable_id("kp", book_id, category_name, name))
            if item_id in kp_by_id:
                raise LearningModelError("知识点稳定 ID 重复：%s" % item_id)
            item["id"] = item_id
            required_aliases = ["legacy:kp:%d:%d" % (category_index, item_index), "kp-name:%s:%s" % (_canonical(category_name), _canonical(name))]
            if knowledge_name_counts[_canonical(name)] == 1:
                required_aliases.append("kp-name:" + _canonical(name))
            item["aliases"] = _aliases(item.get("aliases"), *required_aliases)
            item["version"] = _text(item.get("version") or content_version)
            supplied_chapters = item.get("chapterIds") if isinstance(item.get("chapterIds"), list) else chapter_ids
            item["chapterIds"] = [_identifier(chapter_id, chapter_id) for chapter_id in supplied_chapters]
            if any(chapter_id not in chapter_ids for chapter_id in item["chapterIds"]):
                raise LearningModelError("知识点 %s 引用了不存在的章节 ID" % name)
            item["categoryId"] = category_id
            kp_by_name.setdefault(_canonical(name), []).append(item_id)
            kp_by_id[item_id] = item
            for alias in item["aliases"]:
                _register_alias(alias_map, alias, item_id)

    question_ids = set()
    for index, question in enumerate(questions):
        qtype = _text(question.get("type"))
        question_id = _identifier(question.get("id"), stable_id("q", book_id, qtype, question.get("text")))
        if question_id in question_ids:
            raise LearningModelError("questions.json 稳定 ID 重复：%s" % question_id)
        question_ids.add(question_id)
        question["id"] = question_id
        fingerprint = stable_id("qfp", qtype, question.get("text"), question.get("answer"), question.get("targetOutput"))
        question["aliases"] = _aliases(question.get("aliases"), "legacy:q:%d" % index, fingerprint)
        question["version"] = _text(question.get("version") or content_version)
        chapter_id = _identifier(question.get("chapterId"), chapter_ids[0])
        if chapter_id not in chapter_ids:
            raise LearningModelError("第 %d 题引用了不存在的章节 ID：%s" % (index + 1, chapter_id))
        question["chapterId"] = chapter_id
        supplied_kp_ids = question.get("kpIds") if isinstance(question.get("kpIds"), list) else []
        if not supplied_kp_ids:
            for token in re.split(r"[、,，;/；]+", _text(question.get("kp"))):
                matches = kp_by_name.get(_canonical(token), [])
                if len(matches) > 1:
                    raise LearningModelError("第 %d 题的 kp 名称“%s”在多个分类中同名，必须显式填写 kpIds" % (index + 1, token))
                supplied_kp_ids.extend(matches)
        supplied_kp_ids = list(dict.fromkeys(_text(item) for item in supplied_kp_ids if _text(item)))
        if not supplied_kp_ids or any(item not in kp_by_id for item in supplied_kp_ids):
            raise LearningModelError("第 %d 题的 kp 必须精确对应 kp.json 中的知识点名称或 kpIds" % (index + 1))
        question["kpIds"] = supplied_kp_ids
        for alias in question["aliases"]:
            _register_alias(alias_map, alias, question_id)

    quality_report = _quality_gate(kp_data, questions, python_mode)
    meta["schemaVersion"] = SCHEMA_VERSION
    meta["bookId"] = book_id
    meta["contentVersion"] = content_version
    meta["chapterId"] = chapter_ids[0]
    return {
        "schemaVersion": SCHEMA_VERSION,
        "bookId": book_id,
        "contentVersion": content_version,
        "chapterId": chapter_ids[0],
        "chapterIds": chapter_ids,
        "legacyAliases": alias_map,
        "qualityReport": quality_report,
    }
