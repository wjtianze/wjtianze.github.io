#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
L7.0 注入脚本（普通版，支持 --key）。

把 AI 分开写好的源文件整合后注入 template.html，产出最终学习页。

用法：
    python3 inject.py <input_dir> <output.html> [template.html] [--key <api-key>]

输入目录结构（L6.3 新增：分文件生成 + 演示强制性；L6.4/L6.5/L6.5.1/L7.0 沿用）：
    input_dir/
      meta.json          # {"book": "...", "chapter": "...", "summary": "..."}
      fulltext.md        # 教材原文（规范 Markdown，含 ## / ### 标题、公式 $...$ / $$...$$、blockquote 标记）
      kp.json            # [{"cat": "...", "items": [{"name": "...", "desc": "..."}]}, ...]  （不含 demo 字段）
      questions.json     # [{"type": "single", "text": "...", ...}, ...]
      demos/
        0_0.html         # kpData[0].items[0] 的交互式演示（完整 HTML 文档）
        0_1.html         # kpData[0].items[1] 的交互式演示
        1_0.html         # kpData[1].items[0] 的交互式演示
        ...              # 每个知识点都必须有对应的演示文件（L6.3 强制要求）

参数：
    <input_dir>          源文件目录（见上方结构）
    <output.html>        输出 HTML 文件路径
    [template.html]      可选，默认用本脚本同目录下的 template.html
    --key <api-key>      可选，把模板中的 <your-api-key> 替换为真实 Key。
                         若模板仍含占位符且未传此参数，脚本会报错退出。

脚本流程：
  ① 读取并校验所有源文件（meta / fulltext / kp / questions / demos）；
  ② 【强制演示校验】每个知识点 kpData[ci].items[ii] 必须有对应的 demos/{ci}_{ii}.html，
     缺任何一个都报错退出（L6.3 演示不再是可选）；
  ③ 自动把 demo HTML 中的 </script> 转义为 <\\/script>（JSON 字符串层面），
     这样 AI 写演示时可以用正常的 </script>，无需手动转义；
  ④ 组装成完整 data 对象 {book, chapter, summary, fulltext, kpData, questions}；
  ⑤ 拦截 fulltext / kp / questions 中可能残留的字面量 </script>；
  ⑥ 注入 API Key（若需要）；
  ⑦ 把模板中 id="learning-data" 的 <script> 块整体替换为真实数据；
  ⑧ 写出文件。

校验失败会非零退出并打印原因——据此回到对应源文件修数据即可。
"""
import sys, os, json, re

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from learning_model import LearningModelError, upgrade_and_validate

QUESTION_TYPES = {"single", "multiple", "indeterminate", "judge", "fill", "essay"}

def die(msg):
    print("注入失败：" + msg, file=sys.stderr)
    sys.exit(1)

def read_text(path):
    if not os.path.isfile(path):
        die("缺少文件：%s" % path)
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def read_json(path):
    raw = read_text(path)
    try:
        return json.loads(raw)
    except Exception as e:
        die("%s 不是合法 JSON（检查引号/逗号/括号配对）：%s" % (path, e))

def required_text(value, label):
    text = str(value or "").strip()
    if not text:
        die(label + " 不能为空")
    return text

def validate_questions(questions):
    if not 6 <= len(questions) <= 12:
        die("questions.json 必须包含 6–12 道题，当前为 %d 道" % len(questions))
    single_answers, combined_answers = [], []
    for index, question in enumerate(questions):
        label = "questions.json 第 %d 题" % (index + 1)
        if not isinstance(question, dict):
            die(label + "必须是对象")
        qtype = str(question.get("type") or "").strip()
        if qtype not in QUESTION_TYPES:
            die(label + "的 type 必须是 single/multiple/indeterminate/judge/fill/essay 之一")
        for field, name in (("text", "题干 text"), ("kp", "知识点 kp"),
                            ("difficulty", "难度 difficulty"), ("explanation", "解析 explanation")):
            required_text(question.get(field), label + "的" + name)
        if qtype in {"single", "multiple", "indeterminate"}:
            options = question.get("options")
            if not isinstance(options, dict) or len(options) < 2:
                die(label + "的 options 必须是至少含两个选项的对象")
            keys = list(options.keys())
            if any(not isinstance(key, str) or not re.fullmatch(r"[A-Z]", key) for key in keys):
                die(label + "的选项键必须是大写字母 A/B/C/D…")
            if keys != sorted(keys) or keys != [chr(65 + offset) for offset in range(len(keys))]:
                die(label + "的选项键必须从 A 起连续并按字母顺序排列")
            for key, value in options.items():
                required_text(value, label + "的选项 " + key)
            answer = "".join(sorted(set(re.sub(r"[^A-Z]", "", str(question.get("answer") or "").upper()))))
            if answer != str(question.get("answer") or "").strip().upper():
                die(label + "的 answer 必须是已排序且不重复的大写选项字母")
            if not answer or any(key not in options for key in answer):
                die(label + "的 answer 引用了不存在的选项")
            if qtype == "single" and len(answer) != 1:
                die(label + "为单选题，answer 必须恰好包含一个选项")
            if qtype == "multiple" and len(answer) < 2:
                die(label + "为多选题，answer 必须至少包含两个选项")
            if qtype == "single":
                single_answers.append(answer)
            else:
                combined_answers.append(answer)
        elif qtype == "judge":
            if str(question.get("answer") or "").strip() not in {"对", "错"}:
                die(label + "为判断题，answer 只能写“对”或“错”")
        else:
            required_text(question.get("answer"), label + "的参考答案 answer")
    if len(single_answers) >= 4:
        counts = [single_answers.count(letter) for letter in "ABCD"]
        if min(counts) == 0 or max(counts) - min(counts) > 1:
            die("单选题答案位置不平衡：A/B/C/D 必须尽量均匀分布")
    elif len(single_answers) > 1 and len(set(single_answers)) == 1:
        die("单选题答案位置重复集中在同一选项，请先打乱并核对答案与解析")
    if len(combined_answers) >= 3 and len(set(combined_answers)) < 2:
        die("多选/不定项答案组合过于单一，请覆盖不同合法组合")

def validate_demo_source(source, path):
    if re.search(r"<\\/script\s*>", source, re.I):
        die("演示文件不得手工写 <\\/script>，请正常写 </script>：%s" % path)
    if re.search(r"\b(?:alert|confirm|prompt)\s*\(", source):
        die("演示不得调用 alert()/confirm()/prompt()：%s" % path)
    if re.search(r"document\.cookie|\blocalStorage\b|\bsessionStorage\b|\bparent\s*\.", source):
        die("演示不得访问 Cookie、本地存储或父页面变量：%s" % path)
    if re.search(r"<script\b[^>]*\btype\s*=\s*['\"]?module|\bimport\s*(?:\(|[^;\n]+\bfrom\b)|\bexport\s+(?:default|const|let|var|function|class|\{)", source, re.I):
        die("演示不得使用 ES module/import/export：%s" % path)
    if re.search(r"<script\b[^>]*\bsrc\s*=|<link\b[^>]*\bhref\s*=|\b(?:fetch|XMLHttpRequest|WebSocket|EventSource)\b", source, re.I):
        die("演示必须自包含且不得主动联网：%s" % path)
    if re.search(r"(?:href|src)\s*=\s*['\"]\s*javascript:", source, re.I):
        die("演示不得使用 javascript: 网址：%s" % path)
    interactive = re.search(r"<(?:input|button|select|textarea)\b", source, re.I) or re.search(
        r"(?:addEventListener\s*\(\s*['\"](?:click|input|change|pointer|mouse|touch|key|drag)|on(?:click|input|change|pointer|mouse|touch|key|drag)\s*=)",
        source, re.I)
    if not interactive:
        die("演示缺少可操作控件或交互事件：%s" % path)
    for style in re.findall(r"<style\b[^>]*>([\s\S]*?)</style\s*>", source, re.I):
        for selector, declarations in re.findall(r"([^{}]+)\{([^{}]*)\}", style):
            if re.search(r"(?:\.fill\b|\.bar-fill\b|\.meter-fill\b|progress|progressbar)", selector, re.I) \
                    and re.search(r"\b(?:transition|animation)(?:-[\w-]+)?\s*:", declarations, re.I):
                die("进度指示元素不得使用 transition/animation 补间：%s" % path)

def main():
    # 解析参数，剥离 --key
    raw_args = sys.argv[1:]
    key_val = None
    pos_args = []
    i = 0
    while i < len(raw_args):
        if raw_args[i] == '--key':
            if i + 1 >= len(raw_args):
                die("--key 后缺少 API Key")
            key_val = raw_args[i + 1]
            i += 2
        elif raw_args[i].startswith("--"):
            die("未知参数：" + raw_args[i])
        else:
            pos_args.append(raw_args[i])
            i += 1

    if len(pos_args) < 2 or len(pos_args) > 3:
        die("用法：python3 inject.py <input_dir> <输出.html> [template.html] [--key <api-key>]")
    in_dir, out_path = pos_args[0], pos_args[1]
    tpl_path = pos_args[2] if len(pos_args) > 2 else \
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "template.html")

    if not os.path.isdir(in_dir):
        die("输入路径不是目录：%s" % in_dir)

    in_dir = os.path.abspath(in_dir)
    demos_dir = os.path.join(in_dir, "demos")

    # ① 读取源文件
    meta = read_json(os.path.join(in_dir, "meta.json"))
    fulltext = read_text(os.path.join(in_dir, "fulltext.md"))
    kpData = read_json(os.path.join(in_dir, "kp.json"))
    questions = read_json(os.path.join(in_dir, "questions.json"))

    # 基本字段校验
    if not isinstance(meta, dict):
        die("meta.json 必须是对象 {book, chapter, summary}")
    if not isinstance(kpData, list):
        die("kp.json 必须是数组 [{cat, items:[{name,desc}]}, ...]")
    if not isinstance(questions, list):
        die("questions.json 必须是数组 [{type, text, ...}, ...]")
    required_text(meta.get("book"), "meta.json 的教材名 book")
    required_text(meta.get("chapter"), "meta.json 的章节名 chapter")
    required_text(meta.get("summary"), "meta.json 的摘要 summary")
    if not fulltext.strip():
        die("fulltext.md 不能为空")
    if not kpData:
        die("kp.json 至少要包含一个知识点分类")
    validate_questions(questions)

    # ② 强制演示校验 + 组装 demo
    for ci, cat in enumerate(kpData):
        if not isinstance(cat, dict) or not str(cat.get("cat") or "").strip():
            die("kp.json 第 %d 个分类缺少 cat 字段" % ci)
        items = cat.get("items") or []
        if not isinstance(items, list) or not items:
            die("kp.json 第 %d 个分类的 items 必须是非空数组" % ci)
        for ii, it in enumerate(items):
            if not isinstance(it, dict) or not str(it.get("name") or "").strip():
                die("kp.json 第 %d 个分类的第 %d 个知识点缺少 name 字段" % (ci, ii))
            required_text(it.get("desc"), "kp.json 第 %d 个分类的第 %d 个知识点 desc" % (ci, ii))
            demo_path = os.path.join(demos_dir, "%d_%d.html" % (ci, ii))
            if not os.path.isfile(demo_path):
                die(
                    "演示缺失：kp.json 第 %d 个分类「%s」的第 %d 个知识点「%s」没有对应的演示文件 %s\n"
                    "L6.3 起演示是强制性的——每个知识点都必须有 demos/%d_%d.html。"
                    % (ci, cat.get("cat", ""), ii, it.get("name", ""), demo_path, ci, ii)
                )
            demo_html = read_text(demo_path)
            if not demo_html.strip():
                die("演示文件为空：%s（知识点「%s」必须有可运行的演示）" % (demo_path, it.get("name", "")))
            validate_demo_source(demo_html, demo_path)
            # ③ 自动转义 </script> —— AI 写演示时用正常 </script>，这里统一转义
            demo_html = re.sub(r"</script\s*>", "<\\/script>", demo_html, flags=re.I)
            it["demo"] = demo_html

    try:
        model_v2 = upgrade_and_validate(meta, kpData, questions, python_mode=False)
    except LearningModelError as exc:
        die("数据模型 v2 / 题目质量门禁未通过：%s" % exc)

    # ④ 组装完整 data
    data = {
        **model_v2,
        "book": meta.get("book", ""),
        "chapter": meta.get("chapter", ""),
        "summary": meta.get("summary", ""),
        "fulltext": fulltext,
        "kpData": kpData,
        "questions": questions,
    }

    # ⑤ 拦截 fulltext / kp.desc / questions 中残留的字面量 </script>
    #    （demo 已经转义过，不会再被命中）
    pretty = json.dumps(data, ensure_ascii=False, indent=2)
    bad = re.search(r'(?<!\\)</script', pretty, re.IGNORECASE)
    if bad:
        snippet = pretty[max(0, bad.start() - 80):bad.start() + 80]
        die(
            "源文件中含字面量 </script>（会提前关闭 learning-data 的 <script> 块）：\n"
            "  位置附近：%s\n"
            "请把对应源文件里的 </script> 改写为 <\\/script>，或删除该 script 标签。"
            % snippet.replace("\n", "\\n")
        )

    # ⑥ 读取模板 + 注入 API Key
    with open(tpl_path, "r", encoding="utf-8") as f:
        tpl = f.read()
    if re.search(r"var KEY='sk-[A-Za-z0-9_-]{12,}", tpl):
        die("模板不得预先内嵌真实 API Key；请保留 <your-api-key> 占位符并通过 --key 注入")
    if key_val:
        if not re.fullmatch(r"sk-[A-Za-z0-9_-]{12,}", key_val):
            die("--key 不是合法的 DeepSeek API Key 格式")
        tpl = tpl.replace("'<your-api-key>'", json.dumps(key_val, ensure_ascii=True))
    elif "<your-api-key>" in tpl:
        die(
            "模板中 DeepSeek API Key 仍为占位符 <your-api-key>，无法生成可用的 HTML。\n"
            "请使用 --key 参数传入真实 Key：\n"
            "  python3 inject.py data 输出.html --key sk-你的Key"
        )

    # ⑦ 注入 learning-data 块
    pat = re.compile(
        r'(<script[^>]*id="learning-data"[^>]*>)(.*?)(</script>)',
        re.DOTALL,
    )
    if not pat.search(tpl):
        die('模板里找不到 id="learning-data" 的 script 块')
    new_html = pat.sub(lambda m: m.group(1) + "\n" + pretty + "\n" + m.group(3), tpl, count=1)

    # ⑧ 写出
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(new_html)

    # 统计
    n_kp = sum(len(c.get("items") or []) for c in kpData)
    print("✅ 已生成：%s（知识点 %d 个 / 演示 %d 个 / 题目 %d 道）"
          % (out_path, n_kp, n_kp, len(questions)))

if __name__ == "__main__":
    main()
