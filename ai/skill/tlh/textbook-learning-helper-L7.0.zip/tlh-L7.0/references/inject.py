#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
L7.0 注入脚本（普通版，支持 --key）。

把 AI 分开写好的源文件整合后注入 template.html，产出最终学习页。

用法：
    python3 inject.py <input_dir> <output.html> [template.html] [--key <api-key>]

输入目录结构（L6.3 新增：分文件生成 + 演示强制性；L6.4/L6.5/L6.5.1/L7.0 沿用）：
    input_dir/
      meta.json          # {"book": "...", "chapter": "...", "summary": "..."}
      fulltext.md        # 教材原文（规范 Markdown，含 ## / ### 标题、公式 $...$ / $$...$$、blockquote 标记）
      kp.json            # [{"cat": "...", "items": [{"name": "...", "desc": "..."}]}, ...]  （不含 demo 字段）
      questions.json     # [{"type": "single", "text": "...", ...}, ...]
      demos/
        0_0.html         # kpData[0].items[0] 的交互式演示（完整 HTML 文档）
        0_1.html         # kpData[0].items[1] 的交互式演示
        1_0.html         # kpData[1].items[0] 的交互式演示
        ...              # 每个知识点都必须有对应的演示文件（L6.3 强制要求）

参数：
    <input_dir>          源文件目录（见上方结构）
    <output.html>        输出 HTML 文件路径
    [template.html]      可选，默认用本脚本同目录下的 template.html
    --key <api-key>      可选，把模板中的 <your-api-key> 替换为真实 Key。
                         若模板仍含占位符且未传此参数，脚本会报错退出。

脚本流程：
  ① 读取并校验所有源文件（meta / fulltext / kp / questions / demos）；
  ② 【强制演示校验】每个知识点 kpData[ci].items[ii] 必须有对应的 demos/{ci}_{ii}.html，
     缺任何一个都报错退出（L6.3 演示不再是可选）；
  ③ 自动把 demo HTML 中的 </script> 转义为 <\\/script>（JSON 字符串层面），
     这样 AI 写演示时可以用正常的 </script>，无需手动转义；
  ④ 组装成完整 data 对象 {book, chapter, summary, fulltext, kpData, questions}；
  ⑤ 拦截 fulltext / kp / questions 中可能残留的字面量 </script>；
  ⑥ 注入 API Key（若需要）；
  ⑦ 把模板中 id="learning-data" 的 <script> 块整体替换为真实数据；
  ⑧ 写出文件。

校验失败会非零退出并打印原因——据此回到对应源文件修数据即可。
"""
import sys, os, json, re

def die(msg):
    print("注入失败：" + msg, file=sys.stderr)
    sys.exit(1)

def read_text(path):
    if not os.path.isfile(path):
        die("缺少文件：%s" % path)
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def read_json(path):
    raw = read_text(path)
    try:
        return json.loads(raw)
    except Exception as e:
        die("%s 不是合法 JSON（检查引号/逗号/括号配对）：%s" % (path, e))

def main():
    # 解析参数，剥离 --key
    raw_args = sys.argv[1:]
    key_val = None
    pos_args = []
    i = 0
    while i < len(raw_args):
        if raw_args[i] == '--key' and i + 1 < len(raw_args):
            key_val = raw_args[i + 1]
            i += 2
        else:
            pos_args.append(raw_args[i])
            i += 1

    if len(pos_args) < 2:
        die("用法：python3 inject.py <input_dir> <输出.html> [template.html] [--key <api-key>]")
    in_dir, out_path = pos_args[0], pos_args[1]
    tpl_path = pos_args[2] if len(pos_args) > 2 else \
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "template.html")

    if not os.path.isdir(in_dir):
        die("输入路径不是目录：%s" % in_dir)

    in_dir = os.path.abspath(in_dir)
    demos_dir = os.path.join(in_dir, "demos")

    # ① 读取源文件
    meta = read_json(os.path.join(in_dir, "meta.json"))
    fulltext = read_text(os.path.join(in_dir, "fulltext.md"))
    kpData = read_json(os.path.join(in_dir, "kp.json"))
    questions = read_json(os.path.join(in_dir, "questions.json"))

    # 基本字段校验
    if not isinstance(meta, dict):
        die("meta.json 必须是对象 {book, chapter, summary}")
    if not isinstance(kpData, list):
        die("kp.json 必须是数组 [{cat, items:[{name,desc}]}, ...]")
    if not isinstance(questions, list):
        die("questions.json 必须是数组 [{type, text, ...}, ...]")

    # ② 强制演示校验 + 组装 demo
    for ci, cat in enumerate(kpData):
        if not isinstance(cat, dict) or "cat" not in cat:
            die("kp.json 第 %d 个分类缺少 cat 字段" % ci)
        items = cat.get("items") or []
        if not isinstance(items, list):
            die("kp.json 第 %d 个分类的 items 必须是数组" % ci)
        for ii, it in enumerate(items):
            if not isinstance(it, dict) or "name" not in it:
                die("kp.json 第 %d 个分类的第 %d 个知识点缺少 name 字段" % (ci, ii))
            demo_path = os.path.join(demos_dir, "%d_%d.html" % (ci, ii))
            if not os.path.isfile(demo_path):
                die(
                    "演示缺失：kp.json 第 %d 个分类「%s」的第 %d 个知识点「%s」没有对应的演示文件 %s\n"
                    "L6.3 起演示是强制性的——每个知识点都必须有 demos/%d_%d.html。"
                    % (ci, cat.get("cat", ""), ii, it.get("name", ""), demo_path, ci, ii)
                )
            demo_html = read_text(demo_path)
            if not demo_html.strip():
                die("演示文件为空：%s（知识点「%s」必须有可运行的演示）" % (demo_path, it.get("name", "")))
            # ③ 自动转义 </script> —— AI 写演示时用正常 </script>，这里统一转义
            demo_html = demo_html.replace("</script>", "<\\/script>")
            it["demo"] = demo_html

    # ④ 组装完整 data
    data = {
        "book": meta.get("book", ""),
        "chapter": meta.get("chapter", ""),
        "summary": meta.get("summary", ""),
        "fulltext": fulltext,
        "kpData": kpData,
        "questions": questions,
    }

    # ⑤ 拦截 fulltext / kp.desc / questions 中残留的字面量 </script>
    #    （demo 已经转义过，不会再被命中）
    pretty = json.dumps(data, ensure_ascii=False, indent=2)
    bad = re.search(r'(?<!\\)</script', pretty, re.IGNORECASE)
    if bad:
        snippet = pretty[max(0, bad.start() - 80):bad.start() + 80]
        die(
            "源文件中含字面量 </script>（会提前关闭 learning-data 的 <script> 块）：\n"
            "  位置附近：%s\n"
            "请把对应源文件里的 </script> 改写为 <\\/script>，或删除该 script 标签。"
            % snippet.replace("\n", "\\n")
        )

    # ⑥ 读取模板 + 注入 API Key
    with open(tpl_path, "r", encoding="utf-8") as f:
        tpl = f.read()
    if key_val:
        tpl = tpl.replace("'<your-api-key>'", "'" + key_val + "'")
    elif "<your-api-key>" in tpl:
        die(
            "模板中 DeepSeek API Key 仍为占位符 <your-api-key>，无法生成可用的 HTML。\n"
            "请使用 --key 参数传入真实 Key：\n"
            "  python3 inject.py data 输出.html --key sk-你的Key"
        )

    # ⑦ 注入 learning-data 块
    pat = re.compile(
        r'(<script[^>]*id="learning-data"[^>]*>)(.*?)(</script>)',
        re.DOTALL,
    )
    if not pat.search(tpl):
        die('模板里找不到 id="learning-data" 的 script 块')
    new_html = pat.sub(lambda m: m.group(1) + "\n" + pretty + "\n" + m.group(3), tpl, count=1)

    # ⑧ 写出
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(new_html)

    # 统计
    n_kp = sum(len(c.get("items") or []) for c in kpData)
    print("✅ 已生成：%s（知识点 %d 个 / 演示 %d 个 / 题目 %d 道）"
          % (out_path, n_kp, n_kp, len(questions)))

if __name__ == "__main__":
    main()
