---
name: textbook-learning-helper
description: >-
  分析教材（含数理化 PDF/扫描件），提取指定章节知识点并生成可离线打开的交互式 HTML 学习页。两栏布局：左栏可切换「知识点 / 教材原文 / 测验 / 错题本 / 批阅数据」五个视图，右栏为 DeepSeek AI 对话；列宽可拖动。知识点单页展示且强制附交互式演示；测验与错题本均一题一屏；支持六大题型（单选/多选/不定项/判断/填空/解答），客观题本地判分，主观题 AI 批阅；多选/不定项漏选但没错选得一半分。内嵌 DeepSeek 聊天（V4 Flash / V4 Pro），含出题模式、AI 详解、AI 重写纠错、再出题、引用知识点/题目、多对话管理、Token 统计、API 余额查询等功能。答案/解析/作答/看法/评语均按 Markdown+KaTeX 实时渲染。点击页面内任意公式可复制其 LaTeX 源码；标题栏有 LaTeX 公式助手弹窗（数学/物理/化学/通用，按学科×难度分类，点击即复制）。当用户说"学习第X节"等务必使用本技能。数学公式用 $...$ 或 $$...$$。
---

# textbook-learning-helper

把教材某章/节生成一个可离线打开、可与 DeepSeek 对话的交互式 HTML 学习页：两栏布局——左栏可一键切换「知识点 / 教材原文 / 测验 / 错题本 / 批阅数据」，右栏为 AI 对话；列宽可拖动。

## 生成方式

## ⚠️ 生成前必读：API Key 检查（普通版专属）

本技能是**普通版**，模板 `references/template.html` 中的 DeepSeek API Key 默认为占位符 `<your-api-key>`。**在执行第 5 步「注入并校验」之前，你必须先检查用户是否已提供有效的 API Key**：

1. 若用户在对话中明确提供了 API Key（格式为 `sk-...`），则调用 inject.py 时加上 `--key <用户提供的Key>` 参数（见第 5 步）。
2. 若用户**未提供** API Key，**绝对不要继续生成 HTML**。请直接回复用户：
   > ⚠️ 本技能需要调用 DeepSeek API，但你尚未提供 API Key。请前往 [platform.deepseek.com](https://platform.deepseek.com) → API Keys → 创建新 Key，然后把 Key（格式为 `sk-...`）发给我，我才能生成可用的学习页。

模板（`references/template.html`）**不需要读进上下文**。你把**教材原文、知识点、演示、题目分别写到不同文件**，再用 `inject.py` 整合注入。六步不可颠倒：

1. **提取教材文本**：判断是文本型还是扫描/图像型；图像型先 OCR。**铁律：fulltext 必须忠实保留全部原文（含例题、注释、表格、公式），不得删减或概括**，只允许做格式转写。
2. **创建工作目录** `data/` 与 `data/demos/`：
   ```bash
   mkdir -p data/demos
   ```
3. **分文件写出五类源文件**（用 Write 工具，或 `cat > file << 'EOF'`）：
   - `data/meta.json`：`{"book": "教材名", "chapter": "章节名", "summary": "摘要（可含公式与 **加粗**）"}`
   - `data/fulltext.md`：教材**全文**，规范 Markdown（`##`/`###` 标题、段落分行、公式遵守规则）。**铁律：必须忠实保留全部原文**。
   - `data/kp.json`：知识点分类数组，**不含 demo 字段**。结构 `[{"cat": "分类名", "items": [{"name": "知识点名", "desc": "简述（可含公式）"}, ...]}, ...]`。
   - `data/questions.json`：题目数组。公共字段 `text`、`type`、`kp`、`difficulty`、`explanation`。选择题 `options` 键必须 A/B/C/D 大写字母。主观题写好 `answer` 与 `explanation`。总量 6–12 题，六大题型智能搭配。
   - `data/demos/{ci}_{ii}.html`：**每个知识点的交互式演示**（强制要求）。`{ci}` 是该知识点在 kp.json 中的分类下标（从 0 开始），`{ii}` 是该知识点在该分类 items 中的下标。例如 `demos/0_0.html` 对应 `kpData[0].items[0]`，`demos/1_2.html` 对应 `kpData[1].items[2]`。每个文件是一个完整的 HTML 文档（`<!DOCTYPE html>` 开头，`</html>` 结尾），自包含、可在 sandboxed iframe 中独立运行。**写演示时 `</script>` 直接写正常的，inject.py 会自动转义；不需要手动写 `<\/script>`**。
   - 新数据应在教材、章节、知识点和题目中显式填写稳定 `id`、`version` 与可选 `aliases`；题目同时填写 `chapterId`、`kpIds`。旧数据可省略，注入器会确定性升级到数据模型 v2。字段、迁移和质量门禁详见 [数据模型 v2](references/data-model-v2.md)。
4. **演示强制性铁律**：kp.json 里**每一个 item** 都必须有对应的 `demos/{ci}_{ii}.html`。无论知识点是公式、概念还是方法，都必须产出可交互的演示。即使是纯文字概念，也可以做成翻卡、拖拽配对、填空检验等交互形式。inject.py 会校验，缺任何一个演示文件都会报错退出。
5. **注入并校验**（注意：必须传 `--key`，否则脚本报错）：
   ```bash
   python3 references/inject.py data "L7.0_线性代数_6.2特征向量与特征值.html" --key sk-用户的Key
   ```
   - 文件名格式：`技能版本_教材_章节.html`（技能版本即当前版本号，如 `L7.0`）。
   - 脚本会：① 校验所有源文件存在且合法；② **强制校验每个知识点都有对应演示文件**（缺则报错）；③ 自动把 demo HTML 中的 `</script>` 转义为 `<\/script>`（你无需手动转义）；④ 拦截 fulltext/kp/questions 中残留的字面量 `</script>`；⑤ 注入 API Key（把模板中的 `<your-api-key>` 替换为 `--key` 传入的值）；⑥ 组装并注入模板。
   - 若脚本因 `<your-api-key>` 占位符报错：说明你忘了传 `--key`，请先向用户索要 Key 再重试。
   - 脚本报错 → 按提示修对应源文件后重跑；成功（打印「✅ 已生成：…（知识点 N 个 / 演示 N 个 / 题目 M 道）」）→ 用 present_files 呈现。

> 仅当注入脚本不可用时退回手动方式：复制 `template.html`，先把 `var KEY='<your-api-key>'` 中的 `<your-api-key>` 替换为用户的真实 Key，再把 `id="learning-data"` 的 `<script>` 块内容整体替换为你手动组装的 JSON（注意 demo 里的 `</script>` 要写作 `<\/script>`）。

### 公式与书写规则（适用于 fulltext.md / kp.json / questions.json）

- 数学内容一律用 `$...$`（行内）或 `$$...$$`（行间），绝不用 `\[...\]`、`\(...\)`。
- 反斜杠命令（`\frac`、`\xi`、`\vec` 等）整体包进 `$...$`，不裸露在外。
- **乘号一律用 `\cdot`，绝不用 `\cdotp`**（会渲染错误）。
- **长度命令铁律**：严禁使用 LaTeX 长度/间距命令——`\[4pt]`、`\[2ex]`、`\vspace{...}`、`\hspace{...}`、`\vskip`、`\hskip`、`\smallskip`、`\medskip`、`\bigskip`、`\vfill`、`\hfill`、`\newline`、`\par` 等。需要换行就真正换行。
- **选择题 options 的键必须是大写字母 A/B/C/D...**，严禁 0/1/2/3 数字键。
- 生成题库时必须打乱并平衡答案位置：单选在 A/B/C/D 间尽量均匀，多选和不定项覆盖不同合法组合；打乱后逐题核对选项、答案与解析一致。页面对后续 AI 新增题也会在写入题库前自动重排。
- **行内公式格式优化**：
  - **行内公式 $...$**：仅当含 `\sum` `\int` `\lim` `\prod` `\oint` `\bigcup` `\bigcap` `\max` `\min` 等大型运算符时才加 `\displaystyle`；其他情况不要加。
  - 含 `\frac` 的（除上下标小字外）一律写 `\dfrac`；上下标 `_{...}` 或 `^{...}` 内的 `\frac` 保持原样。
  - **行间公式 $$...$$**：不要写 `\displaystyle`，不要写 `\dfrac`，分数用 `\frac`。
  - 生成 JSON 时无需手动加 `\displaystyle` 或 `\dfrac`——页面 `applyDisplayStyle` 函数会自动按上述规则处理。

### 演示 HTML 写作规则（demos/{ci}_{ii}.html）

- 必须是完整 HTML 文档：`<!DOCTYPE html>` 开头，`</html>` 结尾；也接受 HTML 片段（页面会自动包装）。
- 自包含：所有 CSS 写在 `<style>` 内，所有 JS 写在 `<script>` 内；不得引用本地外部文件。
- **`</script>` 直接写正常的**，inject.py 会自动转义为 `<\/script>` 注入到 JSON 字符串里。**绝对不要**在演示文件里写 `<\/script>`（反斜杠转义）。
- **公式与 Markdown 渲染（自动注入，无需手动引入 CDN）**：页面会自动为每个演示注入 KaTeX（公式）与 marked（Markdown）库，你**无需**在演示里手动引入任何 CDN 或调用 `renderMathInElement`。直接按下面规则写即可：
  - **数学公式**：直接用 `$...$`（行内）或 `$$...$$`（行间）写，页面会自动用 KaTeX 渲染。
  - **Markdown 文字说明**：把 Markdown 文本放在带 `class="md"` 的元素里，页面会自动用 marked 渲染。支持标题、列表、表格、代码块、粗体斜体、blockquote 等 GFM 语法。
  - **动态更新内容后重新渲染**：如果你的 JS 动态修改了 `.md` 元素的内容或插入了新的 `$...$` 公式，调用 `window._demoRender()` 即可重新跑一遍 marked + KaTeX 渲染。
  - **不要在演示里重复引入 katex/marked CDN**（页面已自动注入，重复引入可能导致冲突或加载失败）。
- LaTeX 规范：乘号用 `\cdot`，禁止 `\cdotp`；禁止 `\[ \]` 与 `\( \)`；禁止 LaTeX 长度命令。
- 必须【交互式】：有滑块、按钮、输入框、下拉框等控件，让学生操作并实时观察结果变化；不能只是静态展示。
- 视觉美观：用现代 CSS（渐变 background、box-shadow、border-radius、平滑 transition）；配色用蓝紫主题（主色 `#3a5a9c`、强调 `#ff7a45`、背景 `#f4f6fb`、文字 `#1c2438`）；字体 `system-ui, -apple-system, "Segoe UI", sans-serif`。
- 布局宽敞：内容居中、padding 充足（至少 16px）、控件间距 8~12px。
- 不要使用 `prompt()` / `alert()` / `confirm()`（sandbox 限制）；用页面内 DOM 显示反馈。
- 不要访问 `document.cookie`、`localStorage`、`parent.xxx`（sandbox 限制）。
- 不要使用 ES module（import/export）——用普通 `<script>` 即可。
- 控件必须有初始值，JS 放在 body 末尾的 `<script>` 里或用 `window.onload`。

### 教材原文特殊内容高亮（fulltext.md 中使用）

blockquote + 标记开头的段落会自动套上对应彩色边框样式：

- `> 📖 **定义** ...` → 蓝色边框「📖 定义」
- `> 📐 **公式** ...` → 橙色边框「📐 公式」（居中）
- `> 📊 **定理** ...` → 紫色边框「📊 定理」
- `> 📎 **推论** ...` → 绿色边框「📎 推论」
- `> 📝 **引理** ...` → 青色边框「📝 引理」
- `> 💡 **性质** ...` → 粉色边框「💡 性质」
- `> 📖 **例题** ...` 或 `> 【例 X.Y】 ...` → 橙色边框「📖 例题」
- `> 📝 **注释** ...` → 灰色边框「📝 注释」

## 数据字段（inject.py 组装后的最终 JSON 结构）

- `book` 教材名；`chapter` 章节名；`summary` 摘要（可含公式与 **加粗**）。
- `fulltext`：教材**全文**（来自 fulltext.md），规范 Markdown。左栏「教材原文」视图渲染，带「📑 目录」浮层。
- `kpData`：分类数组（来自 kp.json + demos/），元素 `{cat, items}`，`items` 每项 `{name, desc, demo}`。
  - `name` 知识点名称；`desc` 简述（可含公式与 **加粗**）。
  - `demo`（强制）：交互式演示 HTML 代码（来自 `demos/{ci}_{ii}.html`），在 sandboxed iframe 中渲染。可手动编辑或让 AI 修改/生成。
- `questions`：题目数组（来自 questions.json）。公共字段：`text`、`type`、`kp`、`difficulty`、`explanation`。按题型：
  - `single` 单选：`options` 键 A/B/C/D；`answer` 单个大写字母。
  - `multiple` 多选：`options` 同上；`answer` ≥2 个大写字母。**漏选但没错选得一半分**。
  - `indeterminate` 不定项：`options` 同上；`answer` ≥1 个大写字母。**漏选但没错选同样得一半分**。
  - `judge` 判断：可省 `options`；`answer` 写 `"对"`/`"错"`。
  - `fill` 填空：无 `options`；`answer` 为参考答案。
  - `essay` 解答：无 `options`；`answer` 为分步参考解答。

## 页面功能（了解即可，无需额外操作）

- **两栏布局**：左栏顶部 tab 切换「知识点 / 教材原文 / 测验 / ❌ 错题本 / 批阅数据」五个视图，右栏为 AI 对话。教材原文视图有「📑 目录」按钮可弹出教材目录浮层（按章/节/小节跳转）。
- **知识点单页**：一页一个知识点，顶部导航「上一个 / 目录 / 下一个」。每个知识点含文字描述、公式、**交互式演示（强制）**、可选 AI 详解。文字、公式、演示均可由 AI 重写或用户手动编辑。演示在 sandboxed iframe 中独立运行，自动注入 KaTeX + Markdown，支持编辑/重跑/AI 编辑/全屏。
- **测验单页**：一屏一题，顶部「上一题 / 答题卡 / 下一题」按钮切换；底部「🔄 再出几道题 / 📝 批阅本题 / ✅ 全部批阅」。答题卡为圆形彩点网格（白=未做、蓝=做了没批、绿=对、红=错、黄=半对），当前题高亮。单选/多选/不定项均可右键排除选项（红叉）。
- **错题本视图**：自动收集所有已批阅但未全对的题目（错题 + 半对题）。一题一屏格式与测验相同。底部「🔄 重新作答此题」（清除状态跳到测验）/「📝 跳到测验此题」（保留状态跳转）。有错题卡浮层。
- **批阅数据视图**：显示总分、全对数、答题概览表、错题订正建议、薄弱知识点排名。
- **六大题型 + 判分**：客观题本地即时判分；主观题由 AI（max 思考）按 0–10 评分给评语，可「🔄 重新批阅」。多选/不定项漏选但没错选得一半分。
- **DeepSeek 聊天**：支持 V4 Flash / V4 Pro，思考强度（无 / high / max），理解强度三档（无 / 标准 / 深度）。支持多对话管理、自动命名（≤7 字）、思考过程展示、回复重新生成与编辑、流式输出与中途停止。所有 AI 调用的 `max_tokens` 拉满到 384000（标题命名除外）。
- **出题模式**：聊天输入框上方复选框，开启后发送消息自动加 `#出题` 指令，AI 以 JSON 数组形式出题并写入题库。再出题弹窗可选题型数量、难度、侧重（全部/薄弱/自选知识点）。
- **AI 详解**：知识点 / 已批阅题目可一键生成详解（选择题按选项、填空按空、解答按小问拆解），支持流式输出与收起。
- **AI 重写纠错**：知识点 / 题目可让 AI 检查事实/公式/Markdown 错误并改正。
- **引用知识点/题目**：AI 输入框上方「📎 引用」按钮，可勾选任意知识点与题目作为本次提问上下文（仅本次有效，发送后自动清除）。
- **公式点击复制 LaTeX**：点击页面内任意公式（行内 `$...$` 或行间 `$$...$$`）即可复制其 LaTeX 源码到剪贴板（选项/按钮等交互元素内的公式除外，避免影响正常点击）。
- **LaTeX 公式助手弹窗**：标题栏「∑ LaTeX 助手」按钮打开。四个学科 tab（通用 / 数学 / 物理 / 化学）× 难度级别，含常用 LaTeX 公式（导数、偏导、积分、双重/三重/环路积分、矩阵、行列式、求和等），点击即复制。支持搜索（跨所有学科与难度匹配名称或 LaTeX 内容）。
- **Markdown + KaTeX 渲染**：答案、解析、AI 回复、作答、看法、评语均完整渲染。行内公式智能判断 `\displaystyle` 与 `\dfrac`，行间公式不动。聊天输入草稿自动持久化。
- **Token 统计与余额**：按模型分桶显示用量与计价，精确到 ¥0.00001；AI 演示独立分桶。右栏价格栏显示当前对话费用、全部累计费用、DeepSeek API 余额（60 秒缓存，点击刷新）。
- **状态持久化**：作答/批阅/对话（含草稿）/设置/各视图滚动位置/当前知识点与题目索引/错题本索引/demo 代码均存入 localStorage（与文件路径绑定）。左上角「🗑 清除缓存」一键清除并重载。
- **加密可移植档案**：标题栏可导出或预览导入 `.tlharchive`；密码只在页面内密码框输入，档案使用 PBKDF2-SHA256 + AES-256-GCM。导出默认排除密钥、账号认证、凭据、绝对路径和附件本体，并掩码消息里的高置信密钥/Bearer；导入不会用掩码覆盖当前本地秘密。普通版档案可迁移到 Codex 版，只恢复稳定 ID/别名能匹配的学习状态。

## 注意事项

- 知识点与题目务必写进各自的源文件（kp.json / questions.json），不要写进 JS 字符串/数组——公式里的 `\xi`、`\underline` 在 JS 字符串中是非法转义。
- **演示 HTML 文件里直接写正常的 `</script>`**，inject.py 会自动转义。**不要**在演示文件里写 `<\/script>`。
- **fulltext.md / kp.json / questions.json 中不得出现字面量 `</script>`**——这些文件会被 inject.py 拼进 JSON 后嵌入 `<script type="application/json">` 块，字面量 `</script>` 会让该块提前关闭、页面崩溃。inject.py 会拦截并报错。
- **不要在生成的 Markdown 中使用 LaTeX 长度命令**（`\[4pt]`、`\vspace`、`\hspace`、`\smallskip` 等），会破坏渲染。
- 模板内嵌的 DeepSeek API Key 会随 HTML 分发，分享前提醒用户更换。
- 若打开后页面为空或行为异常：点页面左上角的「🗑 清除缓存」按钮清掉所有 localStorage 后重载。

## ⚠️ 开发者提醒：每次生成 HTML 后必须提示（重要）

**这是普通用户版（L7.0）。** 每次成功生成 HTML 文件后（inject.py 打印「✅ 已生成」时），你**必须**在回复中附上以下提示，不得遗漏：

> ⚠️ **API Key 提醒**：生成的 HTML 文件内嵌了你提供的 DeepSeek API Key（在文件中搜索 `var KEY='sk-` 即可定位）。**分享该文件前，请先用文本编辑器打开，找到 `var KEY=` 那一行，把引号内的 Key 值删除或替换为空字符串**，否则任何拿到文件的人都能看到并消耗你的 API 额度。

**注意**：开发者版（L7.0-d，文件名含 `-d` 后缀）同样不再预置任何真实 Key；普通版与开发者版都必须由当前用户通过 `--key` 按需提供，技能源码和压缩包只保留占位符。

## 版本历史

版本更新记录见 `references/CHANGELOG.md`。当前版本：**L7.0**（普通版）。
