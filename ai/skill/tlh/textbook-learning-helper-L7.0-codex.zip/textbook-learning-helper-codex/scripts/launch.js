#!/usr/bin/env node
'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const { spawn, execFileSync } = require('node:child_process');
const { StandaloneCodexBridge, normalizeError } = require('./codex-bridge');

function parseArgs(argv) {
  const result = { file: '', codex: '', port: 0, open: true, fakeServer: '', statusFile: '' };
  for (const arg of argv) {
    if (arg === '--no-open') result.open = false;
    else if (arg.startsWith('--codex=')) result.codex = arg.slice(8);
    else if (arg.startsWith('--port=')) result.port = Number(arg.slice(7)) || 0;
    else if (arg.startsWith('--fake-server=')) result.fakeServer = arg.slice(14);
    else if (arg.startsWith('--status-file=')) result.statusFile = arg.slice(14);
    else if (!arg.startsWith('--') && !result.file) result.file = arg;
  }
  return result;
}

function isFile(file) {
  try { return !!file && fs.statSync(file).isFile(); } catch (_) { return false; }
}

function isProtectedWindowsApps(file) {
  return typeof file === 'string' && /[\\/]Program Files[\\/]WindowsApps[\\/]/i.test(file);
}

function managedDesktopCandidates(localAppData) {
  const root = localAppData && path.join(localAppData, 'OpenAI', 'Codex', 'bin');
  if (!root) return [];
  try {
    return fs.readdirSync(root, { withFileTypes: true })
      .filter(entry => entry.isDirectory() && /^[a-f0-9]{16,64}$/i.test(entry.name))
      .map(entry => path.join(root, entry.name, 'codex.exe'))
      .filter(isFile)
      .sort((left, right) => fs.statSync(right).mtimeMs - fs.statSync(left).mtimeMs);
  } catch (_) { return []; }
}

function pathCandidates() {
  if (process.platform !== 'win32') return ['codex'];
  try {
    return String(execFileSync('where.exe', ['codex'], {
      encoding: 'utf8',
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'ignore']
    }))
      .split(/\r?\n/).map(item => item.trim()).filter(Boolean);
  } catch (_) { return []; }
}

function resolveCodex(explicit) {
  const home = process.env.USERPROFILE || process.env.HOME || '';
  const candidates = [
    explicit,
    process.env.L7_CODEX_PATH,
    ...managedDesktopCandidates(process.env.LOCALAPPDATA || ''),
    home && path.join(home, '.local', 'bin', process.platform === 'win32' ? 'codex.exe' : 'codex'),
    process.env.APPDATA && path.join(process.env.APPDATA, 'npm', 'codex.cmd'),
    ...pathCandidates()
  ].filter(Boolean).filter(candidate => !isProtectedWindowsApps(candidate));
  return [...new Set(candidates)].find(candidate => candidate === 'codex' || isFile(candidate)) || '';
}

function spawnProcess(command, args, options) {
  if (process.platform === 'win32' && /\.(cmd|bat)$/i.test(command)) {
    const quote = value => '"' + String(value).replaceAll('"', '""') + '"';
    const line = [quote(command), ...args.map(quote)].join(' ');
    return spawn(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', line], options);
  }
  return spawn(command, args, options);
}

function openBrowser(url) {
  try {
    if (process.platform === 'win32') {
      const child = spawn(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', 'start "" "' + url.replaceAll('"', '') + '"'], {
        detached: true, stdio: 'ignore', windowsHide: true
      });
      child.unref();
    } else {
      const command = process.platform === 'darwin' ? 'open' : 'xdg-open';
      const child = spawn(command, [url], { detached: true, stdio: 'ignore' });
      child.unref();
    }
  } catch (_) {}
}

const MAX_JSON_BODY_BYTES = 8 * 1024 * 1024;
const MAX_ATTACHMENT_BYTES = 32 * 1024 * 1024;
const IMAGE_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.avif']);

function requestError(message, statusCode) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

function readJson(request, limit = MAX_JSON_BODY_BYTES) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let tooLarge = false;
    const chunks = [];
    request.on('data', chunk => {
      size += chunk.length;
      if (size > limit) {
        tooLarge = true;
        chunks.length = 0;
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => {
      if (tooLarge) {
        reject(requestError('请求内容过大，请缩短教材上下文后重试', 413));
        return;
      }
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
      catch (_) { reject(requestError('请求内容不是合法 JSON', 400)); }
    });
    request.on('error', reject);
  });
}

function readBuffer(request, limit = MAX_ATTACHMENT_BYTES) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let tooLarge = false;
    const chunks = [];
    request.on('data', chunk => {
      size += chunk.length;
      if (size > limit) {
        tooLarge = true;
        chunks.length = 0;
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => {
      if (tooLarge) {
        reject(requestError('单个附件不能超过 32MB', 413));
        return;
      }
      resolve(Buffer.concat(chunks));
    });
    request.on('error', reject);
  });
}

function sendJson(response, status, value) {
  const body = Buffer.from(JSON.stringify(value), 'utf8');
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  response.end(body);
}

function contentType(file) {
  const extension = path.extname(file).toLowerCase();
  if (extension === '.js') return 'text/javascript; charset=utf-8';
  if (extension === '.css') return 'text/css; charset=utf-8';
  if (extension === '.woff2') return 'font/woff2';
  if (extension === '.woff') return 'font/woff';
  if (extension === '.ttf') return 'font/ttf';
  if (extension === '.png') return 'image/png';
  if (extension === '.jpg' || extension === '.jpeg') return 'image/jpeg';
  if (extension === '.gif') return 'image/gif';
  if (extension === '.webp') return 'image/webp';
  if (extension === '.bmp') return 'image/bmp';
  if (extension === '.avif') return 'image/avif';
  return 'application/octet-stream';
}

function isInside(root, candidate) {
  const base = path.resolve(root);
  const target = path.resolve(candidate);
  return target === base || target.startsWith(base + path.sep);
}

function safeAttachmentName(value) {
  const original = path.basename(String(value || '附件'));
  const cleaned = original.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/[. ]+$/g, '').slice(0, 100);
  return cleaned || '附件';
}

function isImageBuffer(extension, body) {
  if (!Buffer.isBuffer(body) || body.length < 8) return false;
  if (extension === '.png') return body.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  if (extension === '.jpg' || extension === '.jpeg') return body[0] === 0xff && body[1] === 0xd8 && body[body.length - 2] === 0xff && body[body.length - 1] === 0xd9;
  if (extension === '.gif') return body.subarray(0, 6).toString('ascii') === 'GIF87a' || body.subarray(0, 6).toString('ascii') === 'GIF89a';
  if (extension === '.webp') return body.subarray(0, 4).toString('ascii') === 'RIFF' && body.subarray(8, 12).toString('ascii') === 'WEBP';
  if (extension === '.bmp') return body.subarray(0, 2).toString('ascii') === 'BM';
  if (extension === '.avif') return body.subarray(4, 12).toString('ascii').includes('ftyp');
  return false;
}

function createRuntime(options) {
  const htmlPath = path.resolve(options.file);
  if (!isFile(htmlPath)) throw new Error('找不到学习页：' + htmlPath);
  if (path.extname(htmlPath).toLowerCase() !== '.html') throw new Error('学习页必须是 HTML 文件');
  const fake = options.fakeServer && path.resolve(options.fakeServer);
  if (fake && !isFile(fake)) throw new Error('找不到假 App Server：' + fake);
  const codex = fake ? process.execPath : resolveCodex(options.codex);
  if (!codex) throw new Error('未找到可用的 Codex 命令行。请安装或登录 Codex，或使用 --codex=完整路径。');
  const bridge = new StandaloneCodexBridge({
    spawn: spawnProcess,
    command: codex,
    args: fake ? [fake] : ['app-server'],
    cwd: path.dirname(htmlPath),
    env: fake ? { L7_CODEX_FAKE_SERVER: '1' } : {}
  });
  const workspaceRoot = path.dirname(htmlPath);
  const attachmentRoot = path.join(workspaceRoot, '.l7-codex-attachments');
  return { htmlPath, codex, bridge, workspaceRoot, attachmentRoot };
}

async function startRuntime(options) {
  const runtime = createRuntime(options);
  const secret = crypto.randomBytes(24).toString('hex');
  const prefix = '/' + secret;
  let lastActivity = Date.now();
  runtime.bridge.on('stderr', text => { if (process.env.L7_CODEX_DEBUG === '1') process.stderr.write(text); });
  await runtime.bridge.ensureClient();

  const server = http.createServer(async (request, response) => {
    lastActivity = Date.now();
    const host = String(request.headers.host || '');
    if (!/^(127\.0\.0\.1|localhost)(:\d+)?$/i.test(host)) { sendJson(response, 403, { error: { message: '拒绝非本机请求' } }); return; }
    const url = new URL(request.url || '/', 'http://' + host);
    response.setHeader('Referrer-Policy', 'no-referrer');
    response.setHeader('X-Frame-Options', 'DENY');
    if (request.method === 'GET' && url.pathname.startsWith(prefix + '/assets/')) {
      const root = path.resolve(path.dirname(runtime.htmlPath), '.l7-codex-runtime', 'vendor');
      const relative = decodeURIComponent(url.pathname.slice((prefix + '/assets/').length)).replaceAll('/', path.sep);
      const file = path.resolve(root, relative);
      if (file !== root && !file.startsWith(root + path.sep) || !isFile(file)) { sendJson(response, 404, { error: { message: '资源不存在' } }); return; }
      const body = fs.readFileSync(file);
      response.writeHead(200, { 'Content-Type': contentType(file), 'Content-Length': body.length, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
      response.end(body);
      return;
    }
    if (request.method === 'GET' && url.pathname === prefix + '/page') {
      const config = '<script>window.__L7_CODEX_BRIDGE__=Object.freeze({base:' + JSON.stringify(prefix + '/api') + '});</script>';
      const source = fs.readFileSync(runtime.htmlPath, 'utf8');
      const localized = source.replaceAll('.l7-codex-runtime/vendor/', prefix + '/assets/');
      const html = localized.includes('<head>') ? localized.replace('<head>', '<head>\n' + config) : config + localized;
      const body = Buffer.from(html, 'utf8');
      response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': body.length, 'Cache-Control': 'no-store' });
      response.end(body);
      return;
    }
    if (!url.pathname.startsWith(prefix + '/api/')) { sendJson(response, 404, { error: { message: '页面不存在' } }); return; }
    const operation = url.pathname.slice((prefix + '/api/').length);
    try {
      if (request.method === 'GET' && operation === 'media') {
        const requested = String(url.searchParams.get('path') || '');
        const file = path.resolve(runtime.workspaceRoot, requested);
        const realRoot = fs.realpathSync(runtime.workspaceRoot);
        let realFile = '';
        try { realFile = fs.realpathSync(file); } catch (_) {}
        if (!requested || !isInside(runtime.workspaceRoot, file) || !realFile || !isInside(realRoot, realFile) || !isFile(realFile) || !IMAGE_EXTENSIONS.has(path.extname(realFile).toLowerCase())) {
          throw requestError('图片不存在或不在当前学习包目录内', 404);
        }
        const body = fs.readFileSync(realFile);
        response.writeHead(200, {
          'Content-Type': contentType(realFile),
          'Content-Length': body.length,
          'Content-Disposition': 'inline',
          'Cache-Control': 'no-store',
          'X-Content-Type-Options': 'nosniff'
        });
        response.end(body);
        return;
      }
      if (request.method !== 'POST') throw requestError('只允许 POST 请求', 405);
      if (operation === 'attachments') {
        const body = await readBuffer(request);
        if (!body.length) throw requestError('附件内容为空', 400);
        const name = safeAttachmentName(url.searchParams.get('name'));
        const extension = path.extname(name).toLowerCase();
        const id = Date.now().toString(36) + '-' + crypto.randomBytes(8).toString('hex') + '-' + name;
        fs.mkdirSync(runtime.attachmentRoot, { recursive: true });
        const realWorkspaceRoot = fs.realpathSync(runtime.workspaceRoot);
        const realAttachmentRoot = fs.realpathSync(runtime.attachmentRoot);
        if (!isInside(realWorkspaceRoot, realAttachmentRoot)) throw requestError('附件目录不安全', 400);
        const file = path.join(realAttachmentRoot, id);
        if (!isInside(realAttachmentRoot, file)) throw requestError('附件名称无效', 400);
        fs.writeFileSync(file, body);
        sendJson(response, 200, { result: {
          id,
          name,
          path: file,
          size: body.length,
          mime: String(request.headers['content-type'] || 'application/octet-stream').split(';')[0],
          isImage: IMAGE_EXTENSIONS.has(extension) && isImageBuffer(extension, body)
        } });
        return;
      }
      const payload = await readJson(request);
      if (operation === 'run') {
        response.writeHead(200, {
          'Content-Type': 'application/x-ndjson; charset=utf-8',
          'Cache-Control': 'no-store',
          'X-Content-Type-Options': 'nosniff',
          'Transfer-Encoding': 'chunked'
        });
        const write = value => { if (!response.destroyed && !response.writableEnded) response.write(JSON.stringify(value) + '\n'); };
        try {
          const result = await runtime.bridge.run(payload, event => write({ kind: 'event', event }));
          write({ kind: 'result', result });
        } catch (error) {
          write({ kind: 'error', error: normalizeError(error) });
        }
        if (!response.writableEnded) response.end();
        return;
      }
      let result;
      if (operation === 'account') result = await runtime.bridge.readAccount();
      else if (operation === 'login') result = await runtime.bridge.login();
      else if (operation === 'logout') result = await runtime.bridge.logout();
      else if (operation === 'models') result = await runtime.bridge.listModels();
      else if (operation === 'rateLimits') result = await runtime.bridge.rateLimits();
      else if (operation === 'usage') result = await runtime.bridge.usage();
      else if (operation === 'interrupt') result = await runtime.bridge.interrupt(payload.runId);
      else if (operation === 'settings') result = { model: '', effort: 'medium', speed: 'standard', workspaceRoot: path.dirname(runtime.htmlPath) };
      else if (operation === 'shutdown') {
        sendJson(response, 200, { result: { stopped: true } });
        setImmediate(close);
        return;
      }
      else throw new Error('不支持的操作：' + operation);
      sendJson(response, 200, { result });
    } catch (error) {
      sendJson(response, Number(error && error.statusCode) || 500, { error: normalizeError(error) });
    }
  });

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(options.port || 0, '127.0.0.1', resolve);
  });
  const address = server.address();
  const pageUrl = 'http://127.0.0.1:' + address.port + prefix + '/page';
  const close = () => {
    server.close();
    runtime.bridge.stop();
    if (options.statusFile) {
      try { fs.unlinkSync(path.resolve(options.statusFile)); } catch (_) {}
    }
  };
  process.once('SIGINT', close);
  process.once('SIGTERM', close);
  const idle = setInterval(() => {
    if (Date.now() - lastActivity > 4 * 60 * 60 * 1000 && runtime.bridge.runs.size === 0) {
      clearInterval(idle);
      close();
    }
  }, 60000);
  if (typeof idle.unref === 'function') idle.unref();
  process.stdout.write('L7_CODEX_READY ' + pageUrl + '\n');
  if (options.statusFile) {
    const statusPath = path.resolve(options.statusFile);
    fs.mkdirSync(path.dirname(statusPath), { recursive: true });
    fs.writeFileSync(statusPath, JSON.stringify({ pid: process.pid, pageUrl, startedAt: new Date().toISOString() }), 'utf8');
  }
  if (options.open) openBrowser(pageUrl);
  return { ...runtime, server, pageUrl, close };
}

async function main(options = parseArgs(process.argv.slice(2))) {
  if (!options.file) throw new Error('用法：node launch.js <L7.0-codex_学习页.html> [--codex=路径] [--no-open]');
  await startRuntime(options);
}

if (require.main === module) {
  const options = parseArgs(process.argv.slice(2));
  main(options).catch(error => {
    if (options.statusFile) {
      try { fs.writeFileSync(path.resolve(options.statusFile) + '.error.log', String(error && error.stack || error), 'utf8'); } catch (_) {}
    }
    process.stderr.write('启动失败：' + String(error && error.message || error) + '\n');
    process.exitCode = 1;
  });
}

module.exports = { MAX_JSON_BODY_BYTES, MAX_ATTACHMENT_BYTES, parseArgs, resolveCodex, createRuntime, startRuntime, readJson, readBuffer, isInside, safeAttachmentName, isImageBuffer };
