'use strict';

const { EventEmitter } = require('node:events');
const readline = require('node:readline');

class CodexProtocolError extends Error {
  constructor(message, details) {
    super(message);
    this.name = 'CodexProtocolError';
    this.details = details || null;
    if (details && Number.isInteger(details.code)) this.code = details.code;
  }
}

class CodexAppServerClient extends EventEmitter {
  constructor(options = {}) {
    super();
    if (typeof options.spawn !== 'function') throw new TypeError('缺少 spawn 实现');
    this.spawn = options.spawn;
    this.command = options.command;
    this.args = Array.isArray(options.args) ? options.args.slice() : ['app-server'];
    this.cwd = options.cwd || process.cwd();
    this.env = { ...process.env, ...(options.env || {}) };
    this.clientInfo = {
      name: 'textbook_learning_helper_codex',
      title: '课本学习助手 L7.0-codex',
      version: '7.0-codex',
      ...(options.clientInfo || {})
    };
    this.capabilities = { experimentalApi: true, ...(options.capabilities || {}) };
    this.requestTimeoutMs = Number(options.requestTimeoutMs) > 0 ? Number(options.requestTimeoutMs) : 30000;
    this.child = null;
    this.reader = null;
    this.nextId = 1;
    this.pending = new Map();
    this.stderr = [];
    this.started = false;
    this.ready = false;
    this.stopping = false;
  }

  async start() {
    if (this.ready) return;
    if (this.started) return new Promise((resolve, reject) => {
      this.once('ready', resolve);
      this.once('fatal', reject);
    });
    if (!this.command) throw new Error('未找到 Codex 命令行，请在 Codex 管理中选择 codex.exe');
    this.started = true;
    this.stopping = false;
    try {
      this.child = this.spawn(this.command, this.args, {
        cwd: this.cwd,
        env: this.env,
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'pipe']
      });
    } catch (error) {
      this.started = false;
      throw error;
    }
    this.child.once('error', error => this._fatal(error));
    this.child.once('exit', (code, signal) => {
      if (!this.stopping) this._fatal(new Error('Codex App Server 已退出（代码 ' + String(code) + (signal ? '，信号 ' + signal : '') + '）'));
      this._resetProcess();
    });
    this.child.stderr.on('data', chunk => {
      const text = String(chunk || '');
      if (text) {
        this.stderr.push(text);
        if (this.stderr.length > 40) this.stderr.shift();
        this.emit('stderr', text);
      }
    });
    this.reader = readline.createInterface({ input: this.child.stdout, crlfDelay: Infinity });
    this.reader.on('line', line => this._onLine(line));

    try {
      await this.request('initialize', {
        clientInfo: this.clientInfo,
        capabilities: this.capabilities
      });
      this.notify('initialized', {});
      this.ready = true;
      this.emit('ready');
    } catch (error) {
      this.stop();
      throw error;
    }
  }

  request(method, params, timeoutMs) {
    if (!this.child || !this.child.stdin || this.child.stdin.destroyed) {
      return Promise.reject(new Error('Codex App Server 尚未运行'));
    }
    const id = this.nextId++;
    const message = { method, id };
    if (params !== undefined) message.params = params;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error('Codex App Server 请求超时：' + method));
      }, Number(timeoutMs) > 0 ? Number(timeoutMs) : this.requestTimeoutMs);
      this.pending.set(id, { method, resolve, reject, timeout });
      try { this._write(message); }
      catch (error) {
        clearTimeout(timeout);
        this.pending.delete(id);
        reject(error);
      }
    });
  }

  notify(method, params) {
    const message = { method };
    if (params !== undefined) message.params = params;
    this._write(message);
  }

  respond(id, result, error) {
    if (id === undefined || id === null) return;
    this._write(error ? { id, error } : { id, result: result === undefined ? {} : result });
  }

  _write(message) {
    if (!this.child || !this.child.stdin || this.child.stdin.destroyed) throw new Error('Codex App Server 连接已经关闭');
    this.child.stdin.write(JSON.stringify(message) + '\n');
  }

  _onLine(line) {
    const text = String(line || '').trim();
    if (!text) return;
    let message;
    try { message = JSON.parse(text); }
    catch (error) {
      this.emit('warning', new Error('Codex App Server 返回了无效 JSON：' + text.slice(0, 300)));
      return;
    }
    if (message.id !== undefined && (Object.prototype.hasOwnProperty.call(message, 'result') || message.error)) {
      const pending = this.pending.get(message.id);
      if (!pending) {
        this.emit('orphanResponse', message);
        return;
      }
      this.pending.delete(message.id);
      clearTimeout(pending.timeout);
      if (message.error) pending.reject(new CodexProtocolError(message.error.message || ('Codex 请求失败：' + pending.method), message.error));
      else pending.resolve(message.result);
      return;
    }
    if (message.id !== undefined && message.method) {
      this.emit('serverRequest', message);
      return;
    }
    if (message.method) this.emit('notification', message);
  }

  _fatal(error) {
    const failure = error instanceof Error ? error : new Error(String(error || 'Codex App Server 连接失败'));
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timeout);
      pending.reject(failure);
    }
    this.pending.clear();
    this.emit('fatal', failure);
  }

  _resetProcess() {
    if (this.reader) {
      try { this.reader.close(); } catch (_) {}
    }
    this.reader = null;
    this.child = null;
    this.started = false;
    this.ready = false;
  }

  stop() {
    this.stopping = true;
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timeout);
      pending.reject(new Error('Codex App Server 已停止'));
    }
    this.pending.clear();
    if (this.child) {
      try { this.child.kill(); } catch (_) {}
    }
    this._resetProcess();
  }
}

module.exports = { CodexAppServerClient, CodexProtocolError };
