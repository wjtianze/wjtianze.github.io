'use strict';

const { EventEmitter } = require('node:events');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { CodexAppServerClient } = require('./codex-client');

const EFFORTS = new Set(['minimal', 'low', 'medium', 'high', 'xhigh', 'max', 'ultra']);
const SPEEDS = new Set(['standard', 'fast']);
const MAX_TOOL_OUTPUT = 256 * 1024;

function normalizeError(error) {
  const source = error && typeof error === 'object' ? error : { message: String(error || '未知错误') };
  return {
    name: String(source.name || 'Error'),
    message: String(source.message || source || '未知错误'),
    code: source.code == null ? '' : String(source.code),
    details: source.details && typeof source.details === 'object' ? source.details : null
  };
}

function clipText(value, limit = MAX_TOOL_OUTPUT) {
  const text = String(value == null ? '' : value);
  if (Buffer.byteLength(text, 'utf8') <= limit) return text;
  const half = Math.max(1, Math.floor(limit / 2));
  return text.slice(0, half) + '\n\n…（工具结果过长，中间部分已省略）…\n\n' + text.slice(-half);
}

function persistGeneratedImage(sourcePath, workspaceRoot) {
  const source = path.resolve(String(sourcePath || ''));
  const root = path.resolve(String(workspaceRoot || process.cwd()));
  const extension = path.extname(source).toLowerCase();
  if (!['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.avif'].includes(extension)) return '';
  try {
    if (!fs.statSync(source).isFile()) return '';
    const outputRoot = path.join(root, '.l7-codex-generated-images');
    fs.mkdirSync(outputRoot, { recursive: true });
    const stem = path.basename(source, extension).replace(/[^\p{L}\p{N}._-]+/gu, '-').replace(/^-+|-+$/g, '').slice(0, 80) || 'image';
    const destination = path.join(outputRoot, Date.now().toString(36) + '-' + crypto.randomBytes(4).toString('hex') + '-' + stem + extension);
    fs.copyFileSync(source, destination);
    return destination;
  } catch (_) {
    return '';
  }
}

function flattenMessages(messages) {
  const images = [];
  const lines = [
    '下面是课本学习助手当前对话的完整上下文。把它作为学习对话记录处理，并回答最后一条用户消息。',
    '只在确有必要时使用工具；不得声称完成了未实际执行的操作。',
    '除公式、代码和专有名词外，思考摘要与最终回答统一使用简体中文。\n'
  ];
  for (const message of Array.isArray(messages) ? messages : []) {
    if (!message || typeof message !== 'object') continue;
    const role = message.role === 'assistant' ? '助手' : message.role === 'system' || message.role === 'developer' ? '上游说明' : '学生';
    const parts = Array.isArray(message.content) ? message.content : [message.content];
    const texts = [];
    for (const part of parts) {
      if (typeof part === 'string') { texts.push(part); continue; }
      if (!part || typeof part !== 'object') continue;
      if (['text', 'input_text', 'output_text'].includes(part.type)) texts.push(String(part.text || ''));
      if (part.type === 'image_url') {
        const raw = typeof part.image_url === 'string' ? part.image_url : part.image_url && part.image_url.url;
        if (typeof raw === 'string' && raw) images.push({ type: 'image', url: raw });
      }
      if (part.type === 'localImage' && typeof part.path === 'string') images.push({ type: 'localImage', path: part.path });
    }
    lines.push('【' + role + '】\n' + texts.join('\n'));
  }
  return [{ type: 'text', text: lines.join('\n\n') }, ...images];
}

function normalizeTokenUsage(params) {
  const source = params && (params.tokenUsage || params.usage || params);
  if (!source || typeof source !== 'object') return null;
  const total = source.total || source.totalUsage || source.last || source;
  const input = Number(total.inputTokens ?? total.input_tokens ?? total.promptTokens ?? total.prompt_tokens) || 0;
  const output = Number(total.outputTokens ?? total.output_tokens ?? total.completionTokens ?? total.completion_tokens) || 0;
  const cached = Number(total.cachedInputTokens ?? total.cached_input_tokens ?? total.cacheReadInputTokens) || 0;
  const totalTokens = Number(total.totalTokens ?? total.total_tokens) || input + output;
  if (!input && !output && !totalTokens) return null;
  return {
    input_tokens: input,
    output_tokens: output,
    prompt_tokens: input,
    completion_tokens: output,
    total_tokens: totalTokens,
    input_tokens_details: { cached_tokens: cached },
    prompt_tokens_details: { cached_tokens: cached }
  };
}

function toolDetails(item) {
  const type = String(item && item.type || 'tool');
  if (type === 'commandExecution') return {
    tool: '命令行',
    command: Array.isArray(item.command) ? item.command.join(' ') : String(item.command || ''),
    output: clipText(item.aggregatedOutput || (item.exitCode == null ? '' : '退出代码：' + item.exitCode))
  };
  if (type === 'fileChange') {
    const changes = Array.isArray(item.changes) ? item.changes : [];
    return {
      tool: '文件修改',
      command: changes.map(change => String(change.kind || '修改') + ' ' + String(change.path || '')).join('\n'),
      output: clipText(changes.map(change => change.diff || '').filter(Boolean).join('\n\n'))
    };
  }
  if (type === 'mcpToolCall') return {
    tool: [item.server, item.tool].filter(Boolean).join(' / ') || '扩展工具',
    command: clipText(JSON.stringify(item.arguments || {}, null, 2), 32000),
    output: clipText(item.error ? String(item.error.message || item.error) : JSON.stringify(item.result || {}, null, 2))
  };
  if (type === 'dynamicToolCall') return {
    tool: String(item.tool || '动态工具'),
    command: clipText(JSON.stringify(item.arguments || {}, null, 2), 32000),
    output: clipText(JSON.stringify(item.contentItems || {}, null, 2))
  };
  if (type === 'collabToolCall') return {
    tool: '协作工具 · ' + String(item.tool || ''),
    command: String(item.prompt || ''),
    output: String(item.agentStatus || '')
  };
  if (type === 'webSearch') return {
    tool: '网页搜索',
    command: String(item.query || item.action && (item.action.query || item.action.url) || ''),
    output: ''
  };
  if (type === 'imageView') return { tool: '查看图片', command: String(item.path || ''), output: '' };
  if (type === 'imageGeneration') return {
    tool: '生成图片',
    command: String(item.revisedPrompt || ''),
    output: String(item.savedPath || item.failure && item.failure.message || '')
  };
  return { tool: type, command: '', output: '' };
}

function isToolItem(item) {
  return !!item && ['commandExecution', 'fileChange', 'mcpToolCall', 'dynamicToolCall', 'collabToolCall', 'webSearch', 'imageView', 'imageGeneration'].includes(item.type);
}

class StandaloneCodexBridge extends EventEmitter {
  constructor(options = {}) {
    super();
    if (typeof options.spawn !== 'function') throw new TypeError('缺少 spawn 实现');
    this.spawn = options.spawn;
    this.command = options.command;
    this.args = Array.isArray(options.args) ? options.args : ['app-server'];
    this.cwd = options.cwd || process.cwd();
    this.env = options.env || {};
    this.client = null;
    this.accountState = null;
    this.modelState = [];
    this.permissionProfiles = undefined;
    this.runs = new Map();
    this.sandboxEnums = { thread: 'dangerFullAccess', turn: 'dangerFullAccess' };
  }

  async ensureClient() {
    if (this.client && this.client.ready) return this.client;
    if (this.client) this.client.stop();
    const client = new CodexAppServerClient({
      spawn: this.spawn,
      command: this.command,
      args: this.args,
      cwd: this.cwd,
      env: this.env,
      requestTimeoutMs: 60000
    });
    this.client = client;
    client.on('notification', message => this.onNotification(message));
    client.on('serverRequest', message => { void this.onServerRequest(message); });
    client.on('warning', error => this.emit('diagnostic', normalizeError(error)));
    client.on('stderr', text => this.emit('stderr', clipText(text, 8000)));
    client.on('fatal', error => {
      for (const run of this.runs.values()) this.finishRun(run, error);
      this.emit('fatal', normalizeError(error));
    });
    await client.start();
    return client;
  }

  findRun(params) {
    const threadId = params && params.threadId;
    const turnId = params && (params.turnId || params.turn && params.turn.id);
    for (const run of this.runs.values()) {
      if (threadId && run.threadId === threadId) return run;
      if (turnId && run.turnId === turnId) return run;
    }
    return null;
  }

  sendEvent(run, event) {
    if (!run || run.done) return;
    try { run.onEvent(event); } catch (_) {}
  }

  appendAgentMessage(run, itemId, phase, value) {
    const key = String(itemId || 'agent-message-without-id');
    const firstChunk = !run.agentMessageItems.has(key);
    run.agentMessageItems.add(key);
    const commentary = String(phase || '').toLowerCase() === 'commentary';
    const field = commentary ? 'reasoning' : 'content';
    let delta = String(value || '');
    if (firstChunk && run[field] && !/\n\s*$/.test(run[field]) && !/^\s*\n/.test(delta)) delta = '\n\n' + delta;
    run[field] += delta;
    this.sendEvent(run, {
      type: commentary ? 'run-reasoning' : 'run-content',
      runId: run.id,
      delta,
      [field]: run[field]
    });
  }

  finishRun(run, failure, turn) {
    if (!run || run.done) return;
    this.runs.delete(run.id);
    if (failure) {
      const error = failure instanceof Error ? failure : new Error(String(failure && failure.message || failure || 'Codex 运行失败'));
      this.sendEvent(run, { type: 'run-error', runId: run.id, error: normalizeError(error) });
      run.done = true;
      run.reject(error);
      return;
    }
    const result = {
      content: run.content,
      reasoning: run.reasoning,
      usage: run.usage,
      model: run.model,
      threadId: run.threadId,
      turnId: run.turnId,
      status: turn && turn.status || 'completed',
      finishReason: turn && turn.status === 'interrupted' ? 'interrupted' : 'stop'
    };
    result.images = run.images.slice();
    this.sendEvent(run, { type: 'run-completed', runId: run.id, result });
    run.done = true;
    run.resolve(result);
  }

  onNotification(message) {
    const method = String(message.method || '');
    const params = message.params || {};
    if (method === 'account/updated' || method === 'account/login/completed' || method === 'account/rateLimits/updated') {
      this.emit('account-event', { method, params });
    }
    if (method === 'thread/tokenUsage/updated') {
      const run = this.findRun(params);
      const usage = normalizeTokenUsage(params);
      if (run && usage) run.usage = usage;
      return;
    }
    const run = this.findRun(params);
    if (!run) return;
    if (method === 'turn/started') {
      run.turnId = params.turn && params.turn.id || run.turnId;
      this.sendEvent(run, { type: 'run-started', runId: run.id, threadId: run.threadId, turnId: run.turnId });
      return;
    }
    if (method === 'item/started') {
      const item = params.item || {};
      if (item.id) run.itemPhases.set(item.id, item.phase || item.type || '');
      if (isToolItem(item)) {
        const info = toolDetails(item);
        this.sendEvent(run, { type: 'run-tool-started', runId: run.id, callId: item.id || '', tool: info.tool, command: info.command });
      }
      return;
    }
    if (method === 'item/agentMessage/delta') {
      const delta = String(params.delta || '');
      const phase = run.itemPhases.get(params.itemId) || '';
      this.appendAgentMessage(run, params.itemId, phase, delta);
      return;
    }
    if (method === 'item/reasoning/summaryTextDelta' || method === 'item/reasoning/textDelta' || method === 'item/plan/delta') {
      const stepIndex = params.summaryIndex ?? params.summaryPartIndex ?? params.contentIndex ?? params.index;
      const key = String(params.itemId || method) + ':' + String(stepIndex == null ? method : stepIndex);
      const firstChunk = !run.reasoningItems.has(key);
      run.reasoningItems.add(key);
      let delta = String(params.delta || params.text || '');
      if (firstChunk && run.reasoning && !/\n\s*$/.test(run.reasoning) && !/^\s*\n/.test(delta)) delta = '\n\n' + delta;
      run.reasoning += delta;
      this.sendEvent(run, { type: 'run-reasoning', runId: run.id, delta, reasoning: run.reasoning });
      return;
    }
    if (method === 'item/commandExecution/outputDelta') {
      const key = String(params.itemId || '');
      run.toolOutput.set(key, (run.toolOutput.get(key) || '') + String(params.delta || ''));
      return;
    }
    if (method === 'item/completed') {
      const item = params.item || {};
      if (item.type === 'agentMessage' && item.text && !run.agentMessageItems.has(String(item.id || 'agent-message-without-id'))) {
        this.appendAgentMessage(run, item.id, item.phase || run.itemPhases.get(item.id) || '', item.text);
      }
      if (isToolItem(item)) {
        const info = toolDetails(item);
        if (!info.output && item.id && run.toolOutput.has(item.id)) info.output = clipText(run.toolOutput.get(item.id));
        const failed = item.status === 'failed' || item.status === 'declined' || item.error;
        this.sendEvent(run, {
          type: failed ? 'run-tool-failed' : 'run-tool-completed',
          runId: run.id,
          callId: item.id || '',
          tool: info.tool,
          command: info.command,
          ...(failed ? { error: normalizeError(item.error || item.status) } : { result: { out: info.output } })
        });
      }
      if (item.type === 'imageGeneration' && item.status !== 'failed' && !item.failure) {
        const persistedPath = item.savedPath ? persistGeneratedImage(item.savedPath, this.cwd) : '';
        const image = {
          path: persistedPath,
          url: !persistedPath && /^(?:data:image\/|https?:\/\/)/i.test(String(item.result || '')) ? String(item.result) : '',
          alt: 'AI 生成图片',
          revisedPrompt: String(item.revisedPrompt || '')
        };
        const key = image.path || image.url;
        if (key && !run.imageKeys.has(key)) {
          run.imageKeys.add(key);
          run.images.push(image);
          run.content += '\n\n[[TZ_CODEX_IMAGE:' + encodeURIComponent(JSON.stringify(image)) + ']]\n\n';
          this.sendEvent(run, { type: 'run-image', runId: run.id, image });
        }
      }
      return;
    }
    if (method === 'error') {
      run.lastError = params.error || params;
      return;
    }
    if (method === 'turn/completed') {
      const turn = params.turn || {};
      if (turn.status === 'failed') this.finishRun(run, new Error(turn.error && turn.error.message || run.lastError && run.lastError.message || 'Codex 回合失败'), turn);
      else this.finishRun(run, null, turn);
    }
  }

  async onServerRequest(message) {
    const client = this.client;
    if (!client) return;
    const method = String(message.method || '');
    try {
      if (method === 'item/commandExecution/requestApproval' || method === 'item/fileChange/requestApproval') {
        const available = message.params && message.params.availableDecisions;
        const decision = Array.isArray(available) && !available.includes('acceptForSession') ? 'accept' : 'acceptForSession';
        client.respond(message.id, decision);
        return;
      }
      if (method === 'item/permissions/requestApproval') {
        const params = message.params || {};
        client.respond(message.id, { permissions: params.permissions || params.requestedPermissions || [], scope: 'session' });
        return;
      }
      if (method === 'tool/requestUserInput' || method === 'item/tool/requestUserInput') {
        client.respond(message.id, { answers: {} });
        return;
      }
      if (method === 'mcpServer/elicitation/request') {
        client.respond(message.id, { action: 'decline', content: null });
        return;
      }
      client.respond(message.id, null, { code: -32601, message: '课本学习助手未实现该服务器请求：' + method });
    } catch (error) {
      client.respond(message.id, null, { code: -32000, message: String(error.message || error) });
    }
  }

  async readAccount() {
    const client = await this.ensureClient();
    this.accountState = await client.request('account/read', { refreshToken: false });
    return this.accountState;
  }

  async login() {
    const client = await this.ensureClient();
    return client.request('account/login/start', { type: 'chatgpt', useHostedLoginSuccessPage: true, appBrand: 'chatgpt' });
  }

  async logout() {
    const client = await this.ensureClient();
    const result = await client.request('account/logout');
    this.accountState = null;
    return result;
  }

  async listModels() {
    const client = await this.ensureClient();
    const result = await client.request('model/list', { limit: 100, includeHidden: false });
    this.modelState = Array.isArray(result && result.data) ? result.data : [];
    return result;
  }

  modelSupportsFast(modelId) {
    const model = this.modelState.find(item => (item.model || item.id) === modelId);
    if (!model) return false;
    const tiers = Array.isArray(model.serviceTiers) ? model.serviceTiers : [];
    const legacy = Array.isArray(model.additionalSpeedTiers) ? model.additionalSpeedTiers : [];
    return tiers.some(tier => tier && (tier.id === 'fast' || tier.value === 'fast')) || legacy.includes('fast');
  }

  modelSupportsEffort(modelId, effort) {
    const model = this.modelState.find(item => (item.model || item.id) === modelId);
    if (!model) return false;
    const supported = Array.isArray(model.supportedReasoningEfforts) ? model.supportedReasoningEfforts : [];
    return supported.some(item => typeof item === 'string' ? item === effort : item && (item.reasoningEffort || item.effort) === effort);
  }

  defaultEffort(modelId) {
    const model = this.modelState.find(item => (item.model || item.id) === modelId);
    if (!model) return 'medium';
    const supported = Array.isArray(model.supportedReasoningEfforts) ? model.supportedReasoningEfforts : [];
    const first = supported[0];
    return model.defaultReasoningEffort || (typeof first === 'string' ? first : first && (first.reasoningEffort || first.effort)) || 'medium';
  }

  async resolvePermissionProfiles(client) {
    if (this.permissionProfiles !== undefined) return this.permissionProfiles;
    try {
      const result = await client.request('permissionProfile/list', { cwd: this.cwd });
      this.permissionProfiles = result && Array.isArray(result.data) ? result.data : [];
    } catch (error) {
      const text = String(error && error.message || error || '');
      if (Number(error && error.code) !== -32601 && !/method not found|unknown method|not implemented|未实现/i.test(text)) throw error;
      this.permissionProfiles = null;
    }
    return this.permissionProfiles;
  }

  profileAllowed(profiles, id) {
    return Array.isArray(profiles) && profiles.some(profile => profile && profile.id === id && profile.allowed !== false);
  }

  isAutoReviewUnavailable(error) {
    const message = String(error && error.message || error || '');
    return /approvalsReviewer|approvals_reviewer|auto_review|auto-review|on-request/i.test(message)
      && /unknown|unsupported|not supported|not allowed|disallowed|invalid|expected|不可用|不支持|不允许/i.test(message);
  }

  alternateSandbox(value) {
    return ({ workspaceWrite: 'workspace-write', 'workspace-write': 'workspaceWrite', dangerFullAccess: 'danger-full-access', 'danger-full-access': 'dangerFullAccess' })[value] || value;
  }

  async requestLegacy(client, scope, method, createParams) {
    const selected = this.sandboxEnums[scope];
    const fallback = this.alternateSandbox(selected);
    try { return await client.request(method, createParams(selected)); }
    catch (error) {
      const message = String(error && error.message || error || '');
      if (!/unknown variant/i.test(message) || !message.includes(selected) || !message.includes(fallback)) throw error;
      this.sandboxEnums[scope] = fallback;
      return client.request(method, createParams(fallback));
    }
  }

  async run(payload, onEvent = () => {}) {
    const id = payload && typeof payload.runId === 'string' && /^[a-zA-Z0-9-]{8,80}$/.test(payload.runId)
      ? payload.runId : 'l7c-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
    if (this.runs.has(id)) throw new Error('Codex 运行 ID 重复');
    const client = await this.ensureClient();
    if (!this.modelState.length) await this.listModels();
    const defaultModel = this.modelState.find(item => item.isDefault) || this.modelState[0];
    const model = typeof payload.model === 'string' && payload.model ? payload.model : defaultModel && (defaultModel.model || defaultModel.id);
    const effort = EFFORTS.has(payload.effort) ? payload.effort : this.defaultEffort(model);
    const speed = SPEEDS.has(payload.speed) ? payload.speed : 'standard';
    if (!this.modelSupportsEffort(model, effort)) throw new Error('当前模型不支持思考强度 ' + effort + '：' + String(model || '默认模型'));
    if (speed === 'fast' && !this.modelSupportsFast(model)) throw new Error('当前模型不支持快速回答：' + String(model || '默认模型'));
    const profiles = await this.resolvePermissionProfiles(client);
    const common = {
      ...(model ? { model } : {}),
      cwd: this.cwd,
      serviceName: 'textbook_learning_helper_codex',
      serviceTier: speed === 'fast' ? 'fast' : null,
      ephemeral: true
    };
    let mode = '';
    let threadResult;
    if (this.profileAllowed(profiles, ':workspace')) {
      try {
        threadResult = await client.request('thread/start', {
          ...common,
          approvalPolicy: 'on-request',
          approvalsReviewer: 'auto_review',
          permissions: ':workspace',
          runtimeWorkspaceRoots: [this.cwd]
        });
        mode = 'auto-review';
      } catch (error) {
        if (!this.isAutoReviewUnavailable(error) || !this.profileAllowed(profiles, ':danger-full-access')) throw error;
      }
    }
    if (!threadResult && Array.isArray(profiles) && this.profileAllowed(profiles, ':danger-full-access')) {
      threadResult = await client.request('thread/start', { ...common, approvalPolicy: 'never', permissions: ':danger-full-access', runtimeWorkspaceRoots: [this.cwd] });
      mode = 'full-profile';
    }
    if (!threadResult && profiles === null) {
      threadResult = await this.requestLegacy(client, 'thread', 'thread/start', sandbox => ({ ...common, approvalPolicy: 'never', sandbox }));
      mode = 'full-legacy';
    }
    if (!threadResult) throw new Error('当前账号或组织策略既不允许自动审批，也不允许完全访问');
    const threadId = threadResult && threadResult.thread && threadResult.thread.id;
    if (!threadId) throw new Error('Codex App Server 未返回线程 ID');
    const promise = new Promise((resolve, reject) => {
      this.runs.set(id, {
        id, threadId, turnId: '', model: model || '', content: '', reasoning: '', usage: null,
        itemPhases: new Map(), toolOutput: new Map(), images: [], imageKeys: new Set(), agentMessageItems: new Set(), reasoningItems: new Set(),
        lastError: null, done: false, onEvent, resolve, reject
      });
    });
    try {
      const turnCommon = {
        threadId,
        input: flattenMessages(payload.messages),
        cwd: this.cwd,
        ...(model ? { model } : {}),
        ...(effort ? { effort } : {}),
        serviceTier: speed === 'fast' ? 'fast' : null,
        summary: payload.thinking === false ? 'none' : 'concise'
      };
      let turnResult;
      if (mode === 'auto-review') {
        try {
          turnResult = await client.request('turn/start', { ...turnCommon, approvalPolicy: 'on-request', approvalsReviewer: 'auto_review', permissions: ':workspace' });
        } catch (error) {
          if (!this.isAutoReviewUnavailable(error) || !this.profileAllowed(profiles, ':danger-full-access')) throw error;
          mode = 'full-profile';
        }
      }
      if (!turnResult && mode === 'full-profile') turnResult = await client.request('turn/start', { ...turnCommon, approvalPolicy: 'never', permissions: ':danger-full-access' });
      if (!turnResult && mode === 'full-legacy') turnResult = await this.requestLegacy(client, 'turn', 'turn/start', sandbox => ({ ...turnCommon, approvalPolicy: 'never', sandboxPolicy: { type: sandbox } }));
      const run = this.runs.get(id);
      if (run) run.turnId = turnResult && turnResult.turn && turnResult.turn.id || '';
    } catch (error) {
      this.finishRun(this.runs.get(id), error);
    }
    return promise;
  }

  async interrupt(runId) {
    const run = this.runs.get(String(runId || ''));
    if (!run || !run.threadId || !run.turnId) return { interrupted: false };
    const client = await this.ensureClient();
    await client.request('turn/interrupt', { threadId: run.threadId, turnId: run.turnId });
    return { interrupted: true };
  }

  async rateLimits() {
    return (await this.ensureClient()).request('account/rateLimits/read');
  }

  async usage() {
    return (await this.ensureClient()).request('account/usage/read');
  }

  stop() {
    for (const run of this.runs.values()) this.finishRun(run, new Error('课本学习助手正在退出'));
    if (this.client) this.client.stop();
    this.client = null;
  }
}

module.exports = { StandaloneCodexBridge, flattenMessages, normalizeTokenUsage, toolDetails, normalizeError, persistGeneratedImage };
