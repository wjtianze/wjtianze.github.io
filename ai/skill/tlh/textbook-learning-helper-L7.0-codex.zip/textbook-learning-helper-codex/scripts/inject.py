#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
L7.0-codex 注入脚本（独立 Codex App Server 版，无 API Key 参数）。

把 AI 分开写好的源文件整合后注入 template.html，产出最终学习页。

用法：
    python scripts/inject.py <input_dir> <output.html> [template.html]

输入目录结构（沿用分文件生成与演示强制规范）：
    input_dir/
      meta.json          # {"book": "...", "chapter": "...", "summary": "..."}
      fulltext.md        # 教材原文（规范 Markdown，含 ## / ### 标题、公式 $...$ / $$...$$、blockquote 标记）
      kp.json            # [{"cat": "...", "items": [{"name": "...", "desc": "..."}]}, ...]  （不含 demo 字段）
      questions.json     # [{"type": "single", "text": "...", ...}, ...]
      demos/
        0_0.html         # kpData[0].items[0] 的交互式演示（完整 HTML 文档）
        0_1.html         # kpData[0].items[1] 的交互式演示
        1_0.html         # kpData[1].items[0] 的交互式演示
        ...              # 每个知识点都必须有对应的演示文件（L6.3 强制要求）

脚本流程：
  ① 读取并校验所有源文件（meta / fulltext / kp / questions / demos）；
  ② 【强制演示校验】每个知识点 kpData[ci].items[ii] 必须有对应的 demos/{ci}_{ii}.html，
     缺任何一个都报错退出（L6.3 演示不再是可选）；
  ③ 自动把 demo HTML 中的 </script> 转义为 <\\/script>（JSON 字符串层面），
     这样 AI 写演示时可以用正常的 </script>，无需手动转义；
  ④ 组装成完整 data 对象 {book, chapter, summary, fulltext, kpData, questions}；
  ⑤ 拦截 fulltext / kp / questions 中可能残留的字面量 </script>；
  ⑥ 把模板中 id="learning-data" 的 <script> 块整体替换为真实数据；
  ⑦ 写出学习页；
  ⑧ 复制独立本地运行时，并生成配套 Windows 启动脚本。

校验失败会非零退出并打印原因——据此回到对应源文件修数据即可。
"""
import sys, os, json, re, shutil

def die(msg):
    print("注入失败：" + msg, file=sys.stderr)
    sys.exit(1)

def read_text(path):
    if not os.path.isfile(path):
        die("缺少文件：%s" % path)
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def read_json(path):
    raw = read_text(path)
    try:
        return json.loads(raw)
    except Exception as e:
        die("%s 不是合法 JSON（检查引号/逗号/括号配对）：%s" % (path, e))

def main():
    if len(sys.argv) < 3:
        die("用法：python scripts/inject.py <input_dir> <输出.html> [template.html]")
    in_dir, out_path = sys.argv[1], sys.argv[2]
    tpl_path = sys.argv[3] if len(sys.argv) > 3 else \
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "template.html")

    if not os.path.isdir(in_dir):
        die("输入路径不是目录：%s" % in_dir)

    in_dir = os.path.abspath(in_dir)
    demos_dir = os.path.join(in_dir, "demos")

    # ① 读取源文件
    meta = read_json(os.path.join(in_dir, "meta.json"))
    fulltext = read_text(os.path.join(in_dir, "fulltext.md"))
    kpData = read_json(os.path.join(in_dir, "kp.json"))
    questions = read_json(os.path.join(in_dir, "questions.json"))

    # 基本字段校验
    if not isinstance(meta, dict):
        die("meta.json 必须是对象 {book, chapter, summary}")
    if not isinstance(kpData, list):
        die("kp.json 必须是数组 [{cat, items:[{name,desc}]}, ...]")
    if not isinstance(questions, list):
        die("questions.json 必须是数组 [{type, text, ...}, ...]")

    # ② 强制演示校验 + 组装 demo
    for ci, cat in enumerate(kpData):
        if not isinstance(cat, dict) or "cat" not in cat:
            die("kp.json 第 %d 个分类缺少 cat 字段" % ci)
        items = cat.get("items") or []
        if not isinstance(items, list):
            die("kp.json 第 %d 个分类的 items 必须是数组" % ci)
        for ii, it in enumerate(items):
            if not isinstance(it, dict) or "name" not in it:
                die("kp.json 第 %d 个分类的第 %d 个知识点缺少 name 字段" % (ci, ii))
            demo_path = os.path.join(demos_dir, "%d_%d.html" % (ci, ii))
            if not os.path.isfile(demo_path):
                die(
                    "演示缺失：kp.json 第 %d 个分类「%s」的第 %d 个知识点「%s」没有对应的演示文件 %s\n"
                    "L6.3 起演示是强制性的——每个知识点都必须有 demos/%d_%d.html。"
                    % (ci, cat.get("cat", ""), ii, it.get("name", ""), demo_path, ci, ii)
                )
            demo_html = read_text(demo_path)
            if not demo_html.strip():
                die("演示文件为空：%s（知识点「%s」必须有可运行的演示）" % (demo_path, it.get("name", "")))
            # ③ 自动转义 </script> —— AI 写演示时用正常 </script>，这里统一转义
            demo_html = demo_html.replace("</script>", "<\\/script>")
            it["demo"] = demo_html

    # ④ 组装完整 data
    data = {
        "book": meta.get("book", ""),
        "chapter": meta.get("chapter", ""),
        "summary": meta.get("summary", ""),
        "fulltext": fulltext,
        "kpData": kpData,
        "questions": questions,
    }

    # ⑤ 拦截 fulltext / kp.desc / questions 中残留的字面量 </script>
    #    （demo 已经转义过，不会再被命中）
    pretty = json.dumps(data, ensure_ascii=False, indent=2)
    # 仅检查非 demo 部分是否有未转义 </script>：用正则找出所有未转义的 </script>
    bad = re.search(r'(?<!\\)</script', pretty, re.IGNORECASE)
    if bad:
        # 定位是哪个字段
        snippet = pretty[max(0, bad.start() - 80):bad.start() + 80]
        die(
            "源文件中含字面量 </script>（会提前关闭 learning-data 的 <script> 块）：\n"
            "  位置附近：%s\n"
            "请把对应源文件里的 </script> 改写为 <\\/script>，或删除该 script 标签。"
            % snippet.replace("\n", "\\n")
        )

    # ⑥ 注入 learning-data 块
    with open(tpl_path, "r", encoding="utf-8") as f:
        tpl = f.read()
    pat = re.compile(
        r'(<script[^>]*id="learning-data"[^>]*>)(.*?)(</script>)',
        re.DOTALL,
    )
    if not pat.search(tpl):
        die('模板里找不到 id="learning-data" 的 script 块')
    new_html = pat.sub(lambda m: m.group(1) + "\n" + pretty + "\n" + m.group(3), tpl, count=1)

    # ⑦ 写出学习页
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(new_html)

    # ⑧ 写出独立运行入口。浏览器不读取账号文件，只连接本机回环桥；桥再通过
    #    Codex App Server 复用 Codex 已保存的 ChatGPT 登录状态。
    output_dir = os.path.dirname(os.path.abspath(out_path)) or os.getcwd()
    runtime_dir = os.path.join(output_dir, ".l7-codex-runtime")
    os.makedirs(runtime_dir, exist_ok=True)
    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    for runtime_name in ("launch.js", "codex-client.js", "codex-bridge.js", "start.vbs", "status-url.js"):
        source = os.path.join(scripts_dir, runtime_name)
        if not os.path.isfile(source):
            die("技能运行时缺少文件：%s" % source)
        shutil.copy2(source, os.path.join(runtime_dir, runtime_name))
    vendor_source = os.path.join(os.path.dirname(scripts_dir), "assets", "vendor")
    vendor_target = os.path.join(runtime_dir, "vendor")
    if not os.path.isdir(vendor_source):
        die("技能运行时缺少本地渲染依赖：%s" % vendor_source)
    if os.path.isdir(vendor_target):
        shutil.rmtree(vendor_target)
    shutil.copytree(vendor_source, vendor_target)

    output_name = os.path.basename(os.path.abspath(out_path))
    command_name = "启动_%s.cmd" % os.path.splitext(output_name)[0]
    command_path = os.path.join(output_dir, command_name)
    command = (
        "@echo off\r\n"
        "chcp 65001 >nul\r\n"
        "setlocal EnableExtensions\r\n"
        "where node.exe >nul 2>nul\r\n"
        "if errorlevel 1 (\r\n"
        "  echo 启动失败：未找到 Node.js。请先在 Codex 中让助手安装或配置本地启动环境。\r\n"
        "  pause\r\n"
        "  exit /b 1\r\n"
        ")\r\n"
        "set \"L7_RUNTIME=%%~dp0.l7-codex-runtime\"\r\n"
        "del /q \"%%L7_RUNTIME%%\\launch.status.json\" \"%%L7_RUNTIME%%\\launch.status.json.error.log\" >nul 2>nul\r\n"
        "wscript.exe //B //NoLogo \"%%L7_RUNTIME%%\\start.vbs\" \"node.exe\" \"%%L7_RUNTIME%%\\launch.js\" \"%%~dp0%s\" \"--status-file=%%L7_RUNTIME%%\\launch.status.json\" \"--no-open\"\r\n"
        "if errorlevel 1 goto launch_failed\r\n"
        "for /L %%%%I in (1,1,20) do (\r\n"
        "  if exist \"%%L7_RUNTIME%%\\launch.status.json\" goto launch_ready\r\n"
        "  if exist \"%%L7_RUNTIME%%\\launch.status.json.error.log\" goto launch_failed\r\n"
        "  ping 127.0.0.1 -n 2 >nul\r\n"
        ")\r\n"
        "echo 启动失败：本地服务在 20 秒内没有就绪。\r\n"
        ":launch_failed\r\n"
        "if exist \"%%L7_RUNTIME%%\\launch.status.json.error.log\" type \"%%L7_RUNTIME%%\\launch.status.json.error.log\"\r\n"
        "pause\r\n"
        "exit /b 1\r\n"
        ":launch_ready\r\n"
        "set \"L7_PAGE_URL=\"\r\n"
        "for /f \"usebackq delims=\" %%%%U in (`node.exe \"%%L7_RUNTIME%%\\status-url.js\" \"%%L7_RUNTIME%%\\launch.status.json\"`) do set \"L7_PAGE_URL=%%%%U\"\r\n"
        "if not defined L7_PAGE_URL goto open_failed\r\n"
        "start \"\" \"%%L7_PAGE_URL%%\"\r\n"
        "if errorlevel 1 goto open_failed\r\n"
        "endlocal\r\n"
        "exit /b 0\r\n"
        ":open_failed\r\n"
        "echo 本地服务已启动，但未能自动打开默认浏览器。\r\n"
        "echo 请查看：%%L7_RUNTIME%%\\launch.status.json\r\n"
        "pause\r\n"
        "endlocal\r\n"
        "exit /b 1\r\n"
    ) % output_name
    # 首两行只有 ASCII：先关闭命令回显并切换到 UTF-8，再解析后续中文。
    # 不写 BOM，避免部分 cmd.exe 把 BOM 当成首条命令的一部分，导致 @echo off 失效。
    with open(command_path, "w", encoding="utf-8", newline="") as f:
        f.write(command)

    # 统计
    n_kp = sum(len(c.get("items") or []) for c in kpData)
    print("✅ 已生成：%s（知识点 %d 个 / 演示 %d 个 / 题目 %d 道）"
          % (out_path, n_kp, n_kp, len(questions)))
    print("✅ AI 启动入口：%s" % command_path)

if __name__ == "__main__":
    main()
