#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
L8.0-codex 注入脚本（独立 Codex App Server 版，无 API Key 参数）。

把 AI 分开写好的源文件整合后注入 template.html，产出最终学习页。

用法：
    python scripts/inject.py <input_dir> <output.html> [template.html]

输入目录结构：
    input_dir/
      meta.json          # 单章节含 book/chapter/summary；多章节含 chapters 数组
      chapters/*.md      # 多章节时每章一个 Markdown 文件；单章节兼容 fulltext.md
      kp.json            # [{"cat": "...", "items": [{"name": "...", "desc": "..."}]}, ...]  （不含 demo 字段）
      questions.json     # [{"type": "single", "text": "...", ...}, ...]
      demos/             # 可选；只放确实需要预置的演示
        0_0.html         # kpData[0].items[0] 的交互式演示（完整 HTML 文档）
        0_1.html         # kpData[0].items[1] 的交互式演示
        1_0.html         # kpData[1].items[0] 的交互式演示
        ...              # 没有对应文件的知识点仍可正常构建，页面内可按需生成

脚本流程：
  ① 读取并校验所有必需源文件（meta / fulltext / kp / questions）；
  ② 若存在 demos/{ci}_{ii}.html，则校验并注入对应演示；未提供演示不报错；
  ③ 自动把 demo HTML 中的 </script> 转义为 <\\/script>（JSON 字符串层面），
     这样 AI 写演示时可以用正常的 </script>，无需手动转义；
  ④ 组装成完整 data 对象 {book, chapter, summary, fulltext, chapters, kpData, questions}；
  ⑤ 拦截 fulltext / kp / questions 中可能残留的字面量 </script>；
  ⑥ 把模板中 id="learning-data" 的 <script> 块整体替换为真实数据；
  ⑦ 写出学习页；
  ⑧ 复制独立本地运行时，并生成配套 Windows 启动脚本。

校验失败会非零退出并打印原因——据此回到对应源文件修数据即可。
"""
import sys, os, json, re, shutil, urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from learning_model import LearningModelError, upgrade_and_validate

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".avif", ".svg"}
QUESTION_TYPES = {"single", "multiple", "indeterminate", "judge", "fill", "essay"}

def die(msg):
    print("注入失败：" + msg, file=sys.stderr)
    sys.exit(1)

def read_text(path):
    if not os.path.isfile(path):
        die("缺少文件：%s" % path)
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def read_json(path):
    raw = read_text(path)
    try:
        return json.loads(raw)
    except Exception as e:
        die("%s 不是合法 JSON（检查引号/逗号/括号配对）：%s" % (path, e))

def safe_source_path(in_dir, value):
    value = str(value or "").strip()
    if not value:
        die("章节缺少 file 字段")
    if os.path.isabs(value):
        die("章节 file 不能使用输入目录之外的绝对路径：%s" % value)
    real_input = os.path.realpath(in_dir)
    candidate = os.path.abspath(os.path.join(in_dir, value))
    real_candidate = os.path.realpath(candidate)
    try:
        inside = os.path.commonpath([real_input, real_candidate]) == real_input
    except ValueError:
        inside = False
    if not inside:
        die("章节 file 不能越出输入目录：%s" % value)
    return candidate

def required_text(value, label):
    text = str(value or "").strip()
    if not text:
        die(label + " 不能为空")
    return text

def validate_questions(questions):
    if not 6 <= len(questions) <= 12:
        die("questions.json 必须包含 6–12 道题，当前为 %d 道" % len(questions))
    single_answers, combined_answers = [], []
    for index, question in enumerate(questions):
        label = "questions.json 第 %d 题" % (index + 1)
        if not isinstance(question, dict):
            die(label + "必须是对象")
        qtype = str(question.get("type") or "").strip()
        if qtype not in QUESTION_TYPES:
            die(label + "的 type 必须是 single/multiple/indeterminate/judge/fill/essay 之一")
        for field, name in (("text", "题干 text"), ("kp", "知识点 kp"),
                            ("difficulty", "难度 difficulty"), ("explanation", "解析 explanation")):
            required_text(question.get(field), label + "的" + name)
        if qtype in {"single", "multiple", "indeterminate"}:
            options = question.get("options")
            if not isinstance(options, dict) or len(options) < 2:
                die(label + "的 options 必须是至少含两个选项的对象")
            keys = list(options.keys())
            if any(not isinstance(key, str) or not re.fullmatch(r"[A-Z]", key) for key in keys):
                die(label + "的选项键必须是大写字母 A/B/C/D…")
            if keys != sorted(keys) or keys != [chr(65 + offset) for offset in range(len(keys))]:
                die(label + "的选项键必须从 A 起连续并按字母顺序排列")
            for key, value in options.items():
                required_text(value, label + "的选项 " + key)
            answer = "".join(sorted(set(re.sub(r"[^A-Z]", "", str(question.get("answer") or "").upper()))))
            if answer != str(question.get("answer") or "").strip().upper():
                die(label + "的 answer 必须是已排序且不重复的大写选项字母")
            if not answer or any(key not in options for key in answer):
                die(label + "的 answer 引用了不存在的选项")
            if qtype == "single" and len(answer) != 1:
                die(label + "为单选题，answer 必须恰好包含一个选项")
            if qtype == "multiple" and len(answer) < 2:
                die(label + "为多选题，answer 必须至少包含两个选项")
            if qtype == "single":
                single_answers.append(answer)
            else:
                combined_answers.append(answer)
        elif qtype == "judge":
            if str(question.get("answer") or "").strip() not in {"对", "错"}:
                die(label + "为判断题，answer 只能写“对”或“错”")
        else:
            required_text(question.get("answer"), label + "的参考答案 answer")
    if len(single_answers) >= 4:
        counts = [single_answers.count(letter) for letter in "ABCD"]
        if min(counts) == 0 or max(counts) - min(counts) > 1:
            die("单选题答案位置不平衡：A/B/C/D 必须尽量均匀分布")
    elif len(single_answers) > 1 and len(set(single_answers)) == 1:
        die("单选题答案位置重复集中在同一选项，请先打乱并核对答案与解析")
    if len(combined_answers) >= 3 and len(set(combined_answers)) < 2:
        die("多选/不定项答案组合过于单一，请覆盖不同合法组合")

def validate_demo_source(source, path):
    if re.search(r"<\\/script\s*>", source, re.I):
        die("演示文件不得手工写 <\\/script>，请正常写 </script>：%s" % path)
    if re.search(r"\b(?:alert|confirm|prompt)\s*\(", source):
        die("演示不得调用 alert()/confirm()/prompt()：%s" % path)
    if re.search(r"document\.cookie|\blocalStorage\b|\bsessionStorage\b|\bparent\s*\.", source):
        die("演示不得访问 Cookie、本地存储或父页面变量：%s" % path)
    if re.search(r"<script\b[^>]*\btype\s*=\s*['\"]?module|\bimport\s*(?:\(|[^;\n]+\bfrom\b)|\bexport\s+(?:default|const|let|var|function|class|\{)", source, re.I):
        die("演示不得使用 ES module/import/export：%s" % path)
    if re.search(r"<script\b[^>]*\bsrc\s*=|<link\b[^>]*\bhref\s*=|\b(?:fetch|XMLHttpRequest|WebSocket|EventSource)\b", source, re.I):
        die("演示必须自包含且不得主动联网：%s" % path)
    if re.search(r"(?:href|src)\s*=\s*['\"]\s*javascript:", source, re.I):
        die("演示不得使用 javascript: 网址：%s" % path)
    interactive = re.search(r"<(?:input|button|select|textarea)\b", source, re.I) or re.search(
        r"(?:addEventListener\s*\(\s*['\"](?:click|input|change|pointer|mouse|touch|key|drag)|on(?:click|input|change|pointer|mouse|touch|key|drag)\s*=)",
        source, re.I)
    if not interactive:
        die("演示缺少可操作控件或交互事件：%s" % path)
    for style in re.findall(r"<style\b[^>]*>([\s\S]*?)</style\s*>", source, re.I):
        for selector, declarations in re.findall(r"([^{}]+)\{([^{}]*)\}", style):
            if re.search(r"(?:\.fill\b|\.bar-fill\b|\.meter-fill\b|progress|progressbar)", selector, re.I) \
                    and re.search(r"\b(?:transition|animation)(?:-[\w-]+)?\s*:", declarations, re.I):
                die("进度指示元素不得使用 transition/animation 补间：%s" % path)

def safe_chapter_name(index, item, source_path, used):
    raw = os.path.basename(str(item.get("file") or "")) or os.path.basename(source_path)
    stem, ext = os.path.splitext(raw)
    stem = re.sub(r"[^0-9A-Za-z\u3400-\u9fff._-]+", "_", stem).strip("._") or ("chapter-%02d" % (index + 1))
    ext = ".md"
    name = stem + ext
    if name in used:
        name = "%s-%02d%s" % (stem, index + 1, ext)
    while name in used:
        name = "%s-%d%s" % (stem, len(used) + 1, ext)
    used.add(name)
    return name

def _image_reference_path(value):
    raw = str(value or "").strip().strip("<>")
    if not raw or re.match(r"^(?:https?:|data:|blob:|javascript:|#)", raw, re.I):
        return ""
    if raw.lower().startswith("file://"):
        parsed = urllib.parse.urlsplit(raw)
        raw = urllib.parse.unquote(parsed.path or "")
        if re.match(r"^/[A-Za-z]:/", raw):
            raw = raw[1:]
    else:
        raw = urllib.parse.unquote(raw)
    raw = raw.split("#", 1)[0].split("?", 1)[0].strip()
    return raw

def _find_image(in_dir, source_path, reference):
    raw = _image_reference_path(reference)
    if not raw:
        return None
    candidates = []
    if os.path.isabs(raw):
        candidates.append(os.path.abspath(raw))
    else:
        candidates.append(os.path.abspath(os.path.join(os.path.dirname(source_path), raw)))
        candidates.append(os.path.abspath(os.path.join(in_dir, raw)))
    for candidate in candidates:
        if os.path.isfile(candidate) and os.path.splitext(candidate)[1].lower() in IMAGE_EXTENSIONS:
            return candidate
    return None

def materialize_chapter_images(text, in_dir, source_path, output_dir, link_prefix, registry, missing):
    """把教材正文中实际引用的本地图片复制到学习包，并返回可直接渲染的正文。"""
    image_dir = os.path.join(output_dir, "assets", "textbook-images")
    counter = [len(registry) + 1]

    def replacement(reference):
        direct = str(reference or "").strip().strip("<>")
        if re.match(r"^(?:https?:|blob:|javascript:)", direct, re.I):
            missing.add(direct)
            return reference
        source = _find_image(in_dir, source_path, reference)
        if not source:
            raw = _image_reference_path(reference)
            if raw and not re.match(r"^(?:https?:|data:|blob:)", str(reference or "").strip(), re.I):
                missing.add(str(reference).strip())
            return reference
        key = os.path.normcase(os.path.realpath(source))
        if key not in registry:
            ext = os.path.splitext(source)[1].lower()
            stem = os.path.splitext(os.path.basename(source))[0]
            stem = re.sub(r"[^0-9A-Za-z\u3400-\u9fff._-]+", "_", stem).strip("._") or "image"
            name = "%03d_%s%s" % (counter[0], stem, ext)
            counter[0] += 1
            target = os.path.join(image_dir, name)
            os.makedirs(image_dir, exist_ok=True)
            shutil.copyfile(source, target)
            registry[key] = "assets/textbook-images/" + name
        return link_prefix + registry[key]

    # Markdown 图片：保留 alt 文本和括号结构。
    md_pattern = re.compile(r"(!\[[^\]]*\]\(\s*)(<[^>\r\n]+>|[^)>\r\n]+?)(\s*\))", re.I)
    text = md_pattern.sub(lambda match: match.group(1) + replacement(match.group(2)) + match.group(3), text)
    # HTML 图片：教材原文中常见的 <img src="..."> 也必须走同一套打包路径。
    html_pattern = re.compile(r"(<img\b[^>]*\bsrc\s*=\s*)([\"'])([^\"']+)(\2)", re.I)
    return html_pattern.sub(lambda match: match.group(1) + match.group(2) + replacement(match.group(3)) + match.group(4), text)

def main():
    if len(sys.argv) < 3:
        die("用法：python scripts/inject.py <input_dir> <输出.html> [template.html]")
    in_dir, out_path = sys.argv[1], sys.argv[2]
    tpl_path = sys.argv[3] if len(sys.argv) > 3 else \
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "template.html")

    if not os.path.isdir(in_dir):
        die("输入路径不是目录：%s" % in_dir)

    in_dir = os.path.abspath(in_dir)
    demos_dir = os.path.join(in_dir, "demos")

    # ① 读取源文件
    meta = read_json(os.path.join(in_dir, "meta.json"))
    kpData = read_json(os.path.join(in_dir, "kp.json"))
    questions = read_json(os.path.join(in_dir, "questions.json"))

    # 基本字段校验
    if not isinstance(meta, dict):
        die("meta.json 必须是对象 {book, chapter, summary}")
    if not isinstance(kpData, list):
        die("kp.json 必须是数组 [{cat, items:[{name,desc}]}, ...]")
    if not isinstance(questions, list):
        die("questions.json 必须是数组 [{type, text, ...}, ...]")
    required_text(meta.get("book"), "meta.json 的教材名 book")
    if not kpData:
        die("kp.json 至少要包含一个知识点分类")
    validate_questions(questions)

    # L8.0：多章节教材逐章保存为 Markdown 文件，并把章节摘要和文件路径注入页面。
    chapter_sources = []
    declared_chapters = meta.get("chapters")
    if declared_chapters is not None:
        if not isinstance(declared_chapters, list) or not declared_chapters:
            die("meta.json 的 chapters 必须是非空数组")
        used_names, used_ids = set(), set()
        for index, item in enumerate(declared_chapters):
            if not isinstance(item, dict):
                die("meta.json chapters 第 %d 项必须是对象" % index)
            title = str(item.get("title") or item.get("chapter") or item.get("name") or "").strip()
            summary = str(item.get("summary") or meta.get("summary") or "").strip()
            if not title or not summary:
                die("meta.json chapters 第 %d 项必须包含 title/chapter 和 summary" % index)
            source_path = safe_source_path(in_dir, item.get("file") or item.get("path"))
            chapter_id = str(item.get("id") or "chapter-%02d" % (index + 1)).strip()
            if not chapter_id or chapter_id in used_ids:
                die("meta.json chapters 第 %d 项的 id 为空或重复：%s" % (index, chapter_id))
            used_ids.add(chapter_id)
            chapter_text = read_text(source_path)
            if not chapter_text.strip():
                die("章节 Markdown 不能为空：%s" % source_path)
            chapter_sources.append({
                "id": chapter_id,
                "aliases": item.get("aliases"),
                "version": item.get("version"),
                "title": title,
                "chapter": title,
                "summary": summary,
                "source_path": source_path,
                "output_rel": "chapters/" + safe_chapter_name(index, item, source_path, used_names),
                "fulltext": chapter_text,
            })
    else:
        source_path = os.path.join(in_dir, "fulltext.md")
        chapter_title = required_text(meta.get("chapter"), "meta.json 的章节名 chapter")
        chapter_text = read_text(source_path)
        if not chapter_text.strip():
            die("fulltext.md 不能为空")
        chapter_sources.append({
            "id": str(meta.get("chapterId") or "chapter-01"),
            "aliases": meta.get("chapterAliases"),
            "version": meta.get("chapterVersion"),
            "title": chapter_title,
            "chapter": chapter_title,
            "summary": str(meta.get("summary") or "").strip(),
            "source_path": source_path,
            "output_rel": "chapters/chapter-01.md",
            "fulltext": chapter_text,
        })
    if not chapter_sources[0]["summary"]:
        die("教材必须提供章节摘要：meta.json summary 或 chapters[*].summary")
    try:
        active_index = int(meta.get("activeChapterIndex", 0))
    except Exception:
        active_index = 0
    active_index = max(0, min(len(chapter_sources) - 1, active_index))
    active = chapter_sources[active_index]

    # L8.0 图片修复：页面由独立启动器通过 /page 提供，不能依赖浏览器把原输入目录当作当前目录。
    # 统一把章节正文实际引用的本地图片复制进学习包，并分别生成页面路径和章节文件路径。
    output_dir = os.path.dirname(os.path.abspath(out_path)) or os.getcwd()
    os.makedirs(output_dir, exist_ok=True)
    image_registry, missing_images = {}, set()
    for item in chapter_sources:
        item["page_fulltext"] = materialize_chapter_images(item["fulltext"], in_dir, item["source_path"], output_dir, "", image_registry, missing_images)
        item["file_fulltext"] = materialize_chapter_images(item["fulltext"], in_dir, item["source_path"], output_dir, "../", image_registry, missing_images)
    if missing_images:
        die("教材正文含不存在或无法离线打包的图片：" + "、".join(sorted(missing_images)))

    # ② 可选演示校验 + 组装 demo
    demo_count = 0
    for ci, cat in enumerate(kpData):
        if not isinstance(cat, dict) or not str(cat.get("cat") or "").strip():
            die("kp.json 第 %d 个分类缺少 cat 字段" % ci)
        items = cat.get("items") or []
        if not isinstance(items, list) or not items:
            die("kp.json 第 %d 个分类的 items 必须是非空数组" % ci)
        for ii, it in enumerate(items):
            if not isinstance(it, dict) or not str(it.get("name") or "").strip():
                die("kp.json 第 %d 个分类的第 %d 个知识点缺少 name 字段" % (ci, ii))
            required_text(it.get("desc"), "kp.json 第 %d 个分类的第 %d 个知识点 desc" % (ci, ii))
            demo_path = os.path.join(demos_dir, "%d_%d.html" % (ci, ii))
            if not os.path.isfile(demo_path):
                it.pop("demo", None)
                continue
            demo_html = read_text(demo_path)
            if not demo_html.strip():
                die("演示文件为空：%s（知识点「%s」必须有可运行的演示）" % (demo_path, it.get("name", "")))
            validate_demo_source(demo_html, demo_path)
            # ③ 自动转义 </script> —— AI 写演示时用正常 </script>，这里统一转义
            demo_html = re.sub(r"</script\s*>", "<\\/script>", demo_html, flags=re.I)
            it["demo"] = demo_html
            demo_count += 1

    try:
        model_v2 = upgrade_and_validate(meta, kpData, questions, chapters=chapter_sources, python_mode=False)
    except LearningModelError as exc:
        die("数据模型 v2 / 题目质量门禁未通过：%s" % exc)

    # ④ 组装完整 data
    data = {
        **model_v2,
        "book": meta.get("book", ""),
        "chapter": active["chapter"],
        "summary": active["summary"],
        "fulltext": active["page_fulltext"],
        "activeChapterIndex": active_index,
        "chapters": [
            {"id": item["id"], "aliases": item["aliases"], "version": item["version"], "title": item["title"], "chapter": item["chapter"],
             "summary": item["summary"], "file": item["output_rel"], "fulltext": item["page_fulltext"]}
            for item in chapter_sources
        ],
        "kpData": kpData,
        "questions": questions,
    }

    # ⑤ 拦截 fulltext / kp.desc / questions 中残留的字面量 </script>
    #    （demo 已经转义过，不会再被命中）
    pretty = json.dumps(data, ensure_ascii=False, indent=2)
    # 仅检查非 demo 部分是否有未转义 </script>：用正则找出所有未转义的 </script>
    bad = re.search(r'(?<!\\)</script', pretty, re.IGNORECASE)
    if bad:
        # 定位是哪个字段
        snippet = pretty[max(0, bad.start() - 80):bad.start() + 80]
        die(
            "源文件中含字面量 </script>（会提前关闭 learning-data 的 <script> 块）：\n"
            "  位置附近：%s\n"
            "请把对应源文件里的 </script> 改写为 <\\/script>，或删除该 script 标签。"
            % snippet.replace("\n", "\\n")
        )

    # ⑥ 注入 learning-data 块
    with open(tpl_path, "r", encoding="utf-8") as f:
        tpl = f.read()
    pat = re.compile(
        r'(<script[^>]*id="learning-data"[^>]*>)(.*?)(</script>)',
        re.DOTALL,
    )
    if not pat.search(tpl):
        die('模板里找不到 id="learning-data" 的 script 块')
    new_html = pat.sub(lambda m: m.group(1) + "\n" + pretty + "\n" + m.group(3), tpl, count=1)

    # ⑦ 写出学习页与章节文件；文件位于学习页工作区内，Codex 可按上下文读取。
    os.makedirs(os.path.join(output_dir, "chapters"), exist_ok=True)
    for item in chapter_sources:
        with open(os.path.join(output_dir, item["output_rel"].replace("/", os.sep)), "w", encoding="utf-8") as chapter_file:
            chapter_file.write(item["file_fulltext"])
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(new_html)

    # ⑧ 写出独立运行入口。浏览器不读取账号文件，只连接本机回环桥；桥再通过
    #    Codex App Server 复用 Codex 已保存的 ChatGPT 登录状态。
    runtime_dir = os.path.join(output_dir, ".l7-codex-runtime")
    os.makedirs(runtime_dir, exist_ok=True)
    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    for runtime_name in ("launch.js", "codex-client.js", "codex-bridge.js", "start.vbs", "status-url.js"):
        source = os.path.join(scripts_dir, runtime_name)
        if not os.path.isfile(source):
            die("技能运行时缺少文件：%s" % source)
        shutil.copy2(source, os.path.join(runtime_dir, runtime_name))
    vendor_source = os.path.join(os.path.dirname(scripts_dir), "assets", "vendor")
    vendor_target = os.path.join(runtime_dir, "vendor")
    if not os.path.isdir(vendor_source):
        die("技能运行时缺少本地渲染依赖：%s" % vendor_source)
    if os.path.isdir(vendor_target):
        shutil.rmtree(vendor_target)
    shutil.copytree(vendor_source, vendor_target)

    output_name = os.path.basename(os.path.abspath(out_path))
    command_name = "启动_%s.cmd" % os.path.splitext(output_name)[0]
    command_path = os.path.join(output_dir, command_name)
    command = (
        "@echo off\r\n"
        "chcp 65001 >nul\r\n"
        "setlocal EnableExtensions\r\n"
        "where node.exe >nul 2>nul\r\n"
        "if errorlevel 1 (\r\n"
        "  echo 启动失败：未找到 Node.js。请先在 Codex 中让助手安装或配置本地启动环境。\r\n"
        "  pause\r\n"
        "  exit /b 1\r\n"
        ")\r\n"
        "set \"L7_RUNTIME=%%~dp0.l7-codex-runtime\"\r\n"
        "del /q \"%%L7_RUNTIME%%\\launch.status.json\" \"%%L7_RUNTIME%%\\launch.status.json.error.log\" >nul 2>nul\r\n"
        "wscript.exe //B //NoLogo \"%%L7_RUNTIME%%\\start.vbs\" \"node.exe\" \"%%L7_RUNTIME%%\\launch.js\" \"%%~dp0%s\" \"--status-file=%%L7_RUNTIME%%\\launch.status.json\" \"--no-open\"\r\n"
        "if errorlevel 1 goto launch_failed\r\n"
        "for /L %%%%I in (1,1,20) do (\r\n"
        "  if exist \"%%L7_RUNTIME%%\\launch.status.json\" goto launch_ready\r\n"
        "  if exist \"%%L7_RUNTIME%%\\launch.status.json.error.log\" goto launch_failed\r\n"
        "  ping 127.0.0.1 -n 2 >nul\r\n"
        ")\r\n"
        "echo 启动失败：本地服务在 20 秒内没有就绪。\r\n"
        ":launch_failed\r\n"
        "if exist \"%%L7_RUNTIME%%\\launch.status.json.error.log\" type \"%%L7_RUNTIME%%\\launch.status.json.error.log\"\r\n"
        "pause\r\n"
        "exit /b 1\r\n"
        ":launch_ready\r\n"
        "set \"L7_PAGE_URL=\"\r\n"
        "for /f \"usebackq delims=\" %%%%U in (`node.exe \"%%L7_RUNTIME%%\\status-url.js\" \"%%L7_RUNTIME%%\\launch.status.json\"`) do set \"L7_PAGE_URL=%%%%U\"\r\n"
        "if not defined L7_PAGE_URL goto open_failed\r\n"
        "start \"\" \"%%L7_PAGE_URL%%\"\r\n"
        "if errorlevel 1 goto open_failed\r\n"
        "endlocal\r\n"
        "exit /b 0\r\n"
        ":open_failed\r\n"
        "echo 本地服务已启动，但未能自动打开默认浏览器。\r\n"
        "echo 请查看：%%L7_RUNTIME%%\\launch.status.json\r\n"
        "pause\r\n"
        "endlocal\r\n"
        "exit /b 1\r\n"
    ) % output_name
    # 首两行只有 ASCII：先关闭命令回显并切换到 UTF-8，再解析后续中文。
    # 不写 BOM，避免部分 cmd.exe 把 BOM 当成首条命令的一部分，导致 @echo off 失效。
    with open(command_path, "w", encoding="utf-8", newline="") as f:
        f.write(command)

    # 统计
    n_kp = sum(len(c.get("items") or []) for c in kpData)
    print("✅ 已生成：%s（章节 %d 个 / 知识点 %d 个 / 预置演示 %d 个 / 题目 %d 道）"
          % (out_path, len(chapter_sources), n_kp, demo_count, len(questions)))
    print("✅ AI 启动入口：%s" % command_path)

if __name__ == "__main__":
    main()
