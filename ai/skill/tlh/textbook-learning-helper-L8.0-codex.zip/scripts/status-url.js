'use strict';

const fs = require('fs');
const path = require('path');

function readPageUrl(statusFile) {
  const status = JSON.parse(fs.readFileSync(path.resolve(statusFile), 'utf8'));
  const pageUrl = String(status && status.pageUrl || '').trim();
  const parsed = new URL(pageUrl);
  if (parsed.protocol !== 'http:' || parsed.hostname !== '127.0.0.1' || !parsed.port) {
    throw new Error('状态文件中的页面链接不是本机 HTTP 地址');
  }
  return pageUrl;
}

if (require.main === module) {
  if (!process.argv[2]) throw new Error('缺少启动状态文件路径');
  process.stdout.write(readPageUrl(process.argv[2]));
}

module.exports = { readPageUrl };
