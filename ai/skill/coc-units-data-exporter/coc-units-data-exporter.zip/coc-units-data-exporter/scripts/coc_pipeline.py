#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CoC Units Data Exporter — 完整流水线 v2
输入: APK 文件路径 + (可选) 单位名称表 xlsx
输出: 单位完整数据.json

功能:
  1. 从 APK 提取 assets/logic/*.csv + assets/localization/*.csv
  2. 用 sc_compression 解密全部文件
  3. 解析宽表结构(实体→等级→{列:值})，含 NO_INHERIT 修复
  4. 构建 TID→中文 映射
  5. 读取单位名称表(用户提供或内置默认)
  6. 按名称查找匹配，输出结构化 JSON
  7. 添加中文介绍(description)
  8. 新增帮手角色(villager_apprentices)
  9. 计算所需大本营等级(requiredTownHallLevel)
 10. 展开装备技能(skills)

用法:
  python coc_pipeline.py <APK路径> [xlsx路径] [输出目录]
"""
import sys
import os
import json
import zipfile
import tempfile
import subprocess

# ============ 依赖检查与安装 ============
def ensure_deps():
    missing = []
    try: import sc_compression
    except ImportError: missing.append('sc_compression')
    try: import openpyxl
    except ImportError: missing.append('openpyxl')
    if missing:
        print(f"正在安装依赖: {', '.join(missing)}")
        import pip
        for pkg in missing:
            try:
                pip.main(['install', pkg, '-i', 'https://pypi.tuna.tsinghua.edu.cn/simple',
                         '--trusted-host', 'pypi.tuna.tsinghua.edu.cn'])
            except Exception:
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', pkg,
                    '-i', 'https://pypi.tuna.tsinghua.edu.cn/simple',
                    '--trusted-host', 'pypi.tuna.tsinghua.edu.cn'])

ensure_deps()
import sc_compression
from openpyxl import load_workbook

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)
BUILTIN_XLSX = os.path.join(SKILL_DIR, 'assets', 'default_unit_names.xlsx')

# ============ Step 1: 从 APK 提取 CSV ============
def extract_apk(apk_path, work_dir):
    print("\n[Step 1/7] 从 APK 提取文本数据...")
    raw_dir = os.path.join(work_dir, 'coc_raw')
    os.makedirs(raw_dir, exist_ok=True)
    extracted = []
    with zipfile.ZipFile(apk_path, 'r') as z:
        names = z.namelist()
        targets = [n for n in names if
                   (n.startswith('assets/logic/') and n.endswith('.csv')) or
                   (n.startswith('assets/csv/') and n.endswith('.csv')) or
                   (n.startswith('assets/localization/') and n.endswith('.csv'))]
        for n in targets:
            target = os.path.join(raw_dir, n.replace('/', os.sep))
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with open(target, 'wb') as f:
                f.write(z.read(n))
            extracted.append(n)
    print(f"  已提取 {len(extracted)} 个文件")
    return raw_dir

# ============ Step 2: 解密 ============
def decrypt_all(raw_dir, work_dir):
    print("\n[Step 2/7] 解密数据文件...")
    out_map = {
        'assets/logic':        os.path.join(work_dir, 'logic_unpacked'),
        'assets/csv':          os.path.join(work_dir, 'csv_unpacked'),
        'assets/localization': os.path.join(work_dir, 'loc_unpacked'),
    }
    for prefix, outdir in out_map.items():
        srcdir = os.path.join(raw_dir, prefix.replace('/', os.sep))
        if not os.path.isdir(srcdir): continue
        os.makedirs(outdir, exist_ok=True)
        for fn in sorted(os.listdir(srcdir)):
            if not fn.endswith('.csv'): continue
            data = open(os.path.join(srcdir, fn), 'rb').read()
            try:
                out, typ = sc_compression.decompress(data)
                if typ != sc_compression.Signatures.NONE and len(out) != len(data):
                    text = out.decode('utf-8', errors='replace')
                else:
                    text = data.decode('utf-8', errors='replace')
            except Exception:
                text = data.decode('utf-8', errors='replace')
            with open(os.path.join(outdir, fn), 'w', encoding='utf-8') as f:
                f.write(text)
    return out_map

# ============ Step 3: 解析宽表 ============
def parse_csv(text):
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    rows = []; row = []; field = ''; inq = False
    i = 0; n = len(text)
    while i < n:
        c = text[i]
        if inq:
            if c == '"':
                if i + 1 < n and text[i + 1] == '"': field += '"'; i += 2; continue
                inq = False; i += 1; continue
            field += c; i += 1; continue
        if c == '"': inq = True; i += 1; continue
        if c == ',': row.append(field); field = ''; i += 1; continue
        if c == '\n': row.append(field); rows.append(row); row = []; field = ''; i += 1; continue
        field += c; i += 1
    if field != '' or row: row.append(field); rows.append(row)
    return rows

NO_INHERIT = {
    'UpgradeCost', 'UpgradeTimeH', 'UpgradeTimeM', 'UpgradeTimeS',
    'BuildCost', 'BuildTimeD', 'BuildTimeH', 'BuildTimeM', 'BuildTimeS',
    'TrainingCost', 'TrainingTime', 'GearUpCost', 'GearUpTime', 'BoostCost',
    'UpgradeCosts', 'UpgradeResources',
}

def merge_levels(base, override, header):
    d = {}
    if base:
        for i, h in enumerate(header):
            v = base[i] if i < len(base) else ''
            if v != '': d[h] = v
    if override:
        for i, h in enumerate(header):
            v = override[i] if i < len(override) else ''
            if v != '': d[h] = v
            elif h in NO_INHERIT and h in d: d[h] = ''
    return d

def parse_table(rows):
    if len(rows) < 2: return rows[0] if rows else [], []
    header = rows[0]
    name_idx = header.index('Name') if 'Name' in header else None
    vl_idx = header.index('VisualLevel') if 'VisualLevel' in header else None
    entities = []; current = None; base_row = None
    for r in rows[2:]:
        if not r: continue
        r = r + [''] * (len(header) - len(r))
        name = r[name_idx] if (name_idx is not None and name_idx < len(r)) else ''
        if name:
            current = {'_name': name, 'levels': {}}
            base_row = r
            entities.append(current)
            try: lvl = int(r[vl_idx]) if vl_idx is not None else 1
            except: lvl = 1
            current['levels'][lvl] = merge_levels(base_row, None, header)
        else:
            if current is None: continue
            try: lvl = int(r[vl_idx]) if vl_idx is not None else (max(current['levels']) + 1 if current['levels'] else 1)
            except: lvl = (max(current['levels']) + 1) if current['levels'] else 1
            current['levels'][lvl] = merge_levels(base_row, r, header)
    return header, entities

def parse_localization(text):
    rows = parse_csv(text)
    mapping = {}
    for r in rows:
        if not r or len(r) < 2: continue
        tid = r[0].strip()
        val = r[1].strip() if len(r) > 1 else ''
        if tid and not tid.startswith('//') and tid != 'TID':
            mapping[tid] = val
    return mapping

def parse_all_data(out_map, work_dir):
    print("\n[Step 3/7] 解析宽表结构...")
    all_data = {'logic': {}, 'client': {}}
    for prefix, outdir in out_map.items():
        if not os.path.isdir(outdir): continue
        key = 'logic' if 'logic' in prefix else 'client'
        for fn in sorted(os.listdir(outdir)):
            if not fn.endswith('.csv'): continue
            text = open(os.path.join(outdir, fn), encoding='utf-8').read()
            rows = parse_csv(text)
            header, entities = parse_table(rows)
            all_data[key][fn[:-4]] = {'header': header, 'entities': entities,
                'entity_count': len(entities),
                'total_levels': sum(len(e['levels']) for e in entities)}
    loc_dir = out_map.get('assets/localization', '')
    tid_to_cn = {}
    if loc_dir and os.path.isdir(loc_dir):
        for fn in ['texts.csv', 'cn.csv']:
            path = os.path.join(loc_dir, fn)
            if os.path.exists(path):
                tid_to_cn.update({k: v for k, v in parse_localization(open(path, encoding='utf-8').read()).items() if v})
    print(f"  逻辑表: {len(all_data['logic'])}  中文映射: {len(tid_to_cn)}")
    return all_data, tid_to_cn

# ============ Step 4: 构建建筑→大本营等级映射 ============
def build_th_map(all_data):
    """构建 {building_name: {level: town_hall_level}}"""
    th_map = {}
    for e in all_data['logic'].get('buildings', {}).get('entities', []):
        nm = e['_name']
        if nm.startswith('BB') or nm.startswith('UNUSED'): continue
        level_map = {}
        for lk, lv in e['levels'].items():
            th = lv.get('TownHallLevel', '')
            if th:
                level_map[int(lk) if str(lk).isdigit() else lk] = int(th) if str(th).isdigit() else th
        if level_map: th_map[nm] = level_map
    return th_map

def calc_required_th(table_name, entity, level_data, th_map):
    """计算某个等级所需的大本营等级"""
    if table_name == 'heroes':
        return level_data.get('RequiredTownHallLevel', '')
    if table_name in ('buildings', 'traps'):
        return level_data.get('TownHallLevel', '')
    if table_name == 'villager_apprentices':
        return level_data.get('RequiredTownHallLevel', '')
    if table_name == 'characters':
        th_list = []
        lab_lvl = level_data.get('LaboratoryLevel', '')
        if lab_lvl:
            th = th_map.get('Laboratory', {}).get(int(lab_lvl) if str(lab_lvl).isdigit() else lab_lvl)
            if th: th_list.append(th)
        prod = ''
        for lv in entity.get('levels', {}).values():
            prod = lv.get('ProductionBuilding', '')
            if prod: break
        bar_name = 'Dark Barracks' if 'Dark' in prod else 'Barracks'
        bar_lvl = level_data.get('BarrackLevel', '')
        if bar_lvl:
            th = th_map.get(bar_name, {}).get(int(bar_lvl) if str(bar_lvl).isdigit() else bar_lvl)
            if th: th_list.append(th)
        super_th = level_data.get('RequiredSuperTownHallLevel', '')
        if super_th: th_list.append(int(super_th) if str(super_th).isdigit() else super_th)
        return max(th_list) if th_list else ''
    if table_name == 'spells':
        lab_lvl = level_data.get('LaboratoryLevel', '')
        if lab_lvl:
            th = th_map.get('Laboratory', {}).get(int(lab_lvl) if str(lab_lvl).isdigit() else lab_lvl)
            return th or ''
        return ''
    if table_name == 'pets':
        lab_lvl = level_data.get('LaboratoryLevel', '')
        if lab_lvl:
            th = th_map.get('Pet House', {}).get(int(lab_lvl) if str(lab_lvl).isdigit() else lab_lvl)
            return th or ''
        return ''
    if table_name == 'character_items':
        bs_lvl = level_data.get('RequiredBlacksmithLevel', '')
        if bs_lvl:
            th = th_map.get('Blacksmith', {}).get(int(bs_lvl) if str(bs_lvl).isdigit() else bs_lvl)
            return th or ''
        return ''
    return ''

# ============ Step 5-7: 读取名称表 + 查找 + 输出 ============
TABLE_PRIORITY = {
    'characters': 1, 'spells': 1, 'heroes': 1, 'pets': 1,
    'buildings': 1, 'traps': 1, 'townhall_levels': 1,
    'character_items': 1, 'decos': 1, 'obstacles': 1,
    'villager_apprentices': 1,
    'capital_characters': 3, 'capital_buildings': 3,
    'capital_spells': 3, 'capital_traps': 3,
}

SKIP_FIELDS = {'Name', 'IconSWF', 'IconExportName', 'BigPicture', 'BigPictureSWF',
               'OverrideSWF', 'OverrideExportName', 'Animation', 'ExportName',
               'PreviewScenario', 'StatBars', 'StrengthWeight', 'TID',
               'LoadingFrame', 'LoadingEffect', 'AnimationActivationLength',
               'OverrideConstructionExportName', 'OverrideUpgradeExportName',
               'OverrideLockedExportName', 'OverrideDamagedExportName',
               'OverrideInfoTID', 'OverrideAOEIndicator',
               'HideOnActivationClipName', 'HideOnDepletionClipName',
               'OverrideStatBars', 'OverridePreviewScenario',
               'IconExportNameWorking', 'IconExportNameReady',
               'IconExportNameLevelUp', 'IconExportNameCooldown',
               'IconExportNameSelect', 'Skin', 'MenuSkin', 'Gender'}

HERO_ID_MAP = {
    'Barbarian King': '28000000', 'Archer Queen': '28000001',
    'Grand Warden': '28000002', 'Royal Champion': '28000004',
    'Minion Prince': '28000006',
    'Battle Machine': '28000003', 'Battle Copter': '28000005',
}

def build_unit_entry(table_name, entity, sheet_name, tid_to_cn, all_data, th_map, ability_map, output_list):
    ent_name = entity['_name']
    all_levels_dict = entity.get('levels', {})
    if not all_levels_dict: return
    first_lvl_key = min(all_levels_dict.keys(), key=lambda k: int(k) if isinstance(k, int) or (isinstance(k, str) and k.isdigit()) else 99999)
    base_data = all_levels_dict[first_lvl_key]

    tid = base_data.get('TID', '')
    chinese_name = tid_to_cn.get(tid, '')
    if not chinese_name:
        for lv in all_levels_dict.values():
            t = lv.get('TID', '')
            c = tid_to_cn.get(t, '')
            if c: chinese_name = c; break

    # 中文介绍
    info_tid = base_data.get('InfoTID', '')
    description = tid_to_cn.get(info_tid, '')
    if not description:
        for lv in all_levels_dict.values():
            it = lv.get('InfoTID', '')
            d = tid_to_cn.get(it, '')
            if d: description = d; break

    global_id = base_data.get('GlobalID', '')
    if not global_id:
        if ent_name in HERO_ID_MAP:
            global_id = HERO_ID_MAP[ent_name]
        elif ent_name.startswith('BB '):
            global_id = HERO_ID_MAP.get(ent_name[3:], '')

    header = all_data['logic'][table_name]['header']
    static_fields = {}
    for field in header:
        if field in SKIP_FIELDS: continue
        val = base_data.get(field, '')
        if val == '': continue
        all_same = True
        for lk, lv in all_levels_dict.items():
            if lk == first_lvl_key: continue
            if lv.get(field, '') != val: all_same = False; break
        if all_same:
            if 'TID' in field and val:
                cn_val = tid_to_cn.get(val, '')
                static_fields[field] = cn_val if cn_val else val
            else:
                static_fields[field] = val

    levels = []
    for lk in sorted(all_levels_dict.keys(), key=lambda k: int(k) if isinstance(k, int) or (isinstance(k, str) and k.isdigit()) else 99999):
        lv = all_levels_dict[lk]
        level_entry = {"level": int(lk) if (isinstance(lk, int) or (isinstance(lk, str) and lk.isdigit())) else lk}
        # 所需大本营等级
        th = calc_required_th(table_name, entity, lv, th_map)
        if th: level_entry['requiredTownHallLevel'] = th
        for field in header:
            val = lv.get(field, '')
            if val == '' or field in static_fields or field in SKIP_FIELDS: continue
            level_entry[field] = val
        # 装备技能
        if table_name == 'character_items':
            main_ab = lv.get('MainAbilities', '')
            extra_ab = lv.get('ExtraAbilities', '')
            if main_ab or extra_ab:
                skills = []
                for ab_name in main_ab.split(';'):
                    ab_name = ab_name.strip()
                    if ab_name and ab_name in ability_map:
                        ab_e = ability_map[ab_name]
                        ab_lv0 = list(ab_e['levels'].values())[0] if ab_e['levels'] else {}
                        ab_tid = ab_lv0.get('TID', '')
                        skills.append({"name": ab_name, "chineseName": tid_to_cn.get(ab_tid, ''),
                                       "type": "main", "abilityLevel": lv.get('MainAbilityLevels', '')})
                for ab_name in extra_ab.split(';'):
                    ab_name = ab_name.strip()
                    if ab_name and ab_name in ability_map:
                        ab_e = ability_map[ab_name]
                        ab_lv0 = list(ab_e['levels'].values())[0] if ab_e['levels'] else {}
                        ab_tid = ab_lv0.get('TID', '')
                        skills.append({"name": ab_name, "chineseName": tid_to_cn.get(ab_tid, ''),
                                       "type": "extra", "abilityLevel": lv.get('ExtraAbilityLevels', '')})
                if skills: level_entry['skills'] = skills
        levels.append(level_entry)

    entry = {
        "englishName": ent_name,
        "chineseName": chinese_name,
        "globalID": global_id,
        "category": sheet_name,
        "table": table_name,
        "staticAttributes": static_fields,
        "levels": levels
    }
    if description:
        entry['description'] = description
    output_list.append(entry)

def export_units_json(all_data, tid_to_cn, xlsx_path, output_path):
    print(f"\n[Step 4/7] 构建建筑→大本营等级映射...")
    th_map = build_th_map(all_data)
    print(f"  已映射 {len(th_map)} 栋建筑")

    print(f"\n[Step 5/7] 构建技能映射...")
    ability_map = {}
    for e in all_data['logic'].get('special_abilities', {}).get('entities', []):
        if not e['_name'].startswith('UNUSED'):
            ability_map[e['_name']] = e
    print(f"  已映射 {len(ability_map)} 个技能")

    print(f"\n[Step 6/7] 读取单位名称表: {xlsx_path}")
    wb = load_workbook(xlsx_path)
    all_names = []
    for sheet_name in wb.sheetnames:
        if sheet_name == 'README': continue
        ws = wb[sheet_name]
        for row in ws.iter_rows(min_row=1, values_only=True):
            if not row or not row[0]: continue
            main_name = str(row[0]).strip()
            if not main_name: continue
            extras = [str(row[i]).strip() for i in range(1, len(row)) if row[i]]
            all_names.append((sheet_name, main_name, extras))
    print(f"  名称条目: {len(all_names)}")

    print(f"\n[Step 7/7] 查找匹配并输出 JSON...")
    name_index = {}
    for table_name in all_data['logic']:
        tbl = all_data['logic'][table_name]
        priority = TABLE_PRIORITY.get(table_name, 9)
        for e in tbl['entities']:
            nm = e['_name']
            if nm.startswith('UNUSED') or nm.startswith('unused'): continue
            if nm in name_index and priority >= name_index[nm][0]: continue
            name_index[nm] = (priority, table_name, e)
            lower = nm.lower()
            if lower not in name_index or priority < name_index[lower][0]:
                name_index[lower] = (priority, table_name, e)
    lookup = {k: (v[1], v[2]) for k, v in name_index.items()}

    found_units = []; not_found = []; found_names = set()

    for sheet_name, main_name, extras in all_names:
        found = False
        if main_name in lookup and main_name not in found_names:
            tn, e = lookup[main_name]
            found_names.add(main_name)
            build_unit_entry(tn, e, sheet_name, tid_to_cn, all_data, th_map, ability_map, found_units)
            found = True
        if not found:
            for nm, (tn, e) in lookup.items():
                if nm.lower() == main_name.lower() and nm not in found_names:
                    found_names.add(nm)
                    build_unit_entry(tn, e, sheet_name, tid_to_cn, all_data, th_map, ability_map, found_units)
                    found = True; break
        if not found:
            not_found.append((sheet_name, main_name, extras))
        for extra in extras:
            if extra in found_names: continue
            if extra in lookup:
                tn, e = lookup[extra]
                found_names.add(extra)
                build_unit_entry(tn, e, sheet_name, tid_to_cn, all_data, th_map, ability_map, found_units)

    # 新增帮手角色
    va_tbl = all_data['logic'].get('villager_apprentices', {})
    for e in va_tbl.get('entities', []):
        if e['_name'] in found_names: continue
        build_unit_entry('villager_apprentices', e, '帮手角色', tid_to_cn, all_data, th_map, ability_map, found_units)
        found_names.add(e['_name'])

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump({
            "meta": {
                "totalUnits": len(found_units),
                "unitsNotFound": len(not_found),
                "notFoundList": [{"category": s, "name": n, "extras": e} for s, n, e in not_found],
                "features": ["中文介绍(description)", "所需大本营等级(requiredTownHallLevel)",
                             "装备技能(skills)", "帮手角色(villager_apprentices)"],
                "stats": {
                    "totalUnits": len(found_units),
                    "unitsWithDescription": sum(1 for u in found_units if u.get('description')),
                    "totalLevelRows": sum(len(u.get('levels', [])) for u in found_units),
                    "rowsWithTownHallLevel": sum(1 for u in found_units for lv in u.get('levels', []) if lv.get('requiredTownHallLevel')),
                    "rowsWithSkills": sum(1 for u in found_units for lv in u.get('levels', []) if lv.get('skills')),
                },
                "description": "完整游戏数据，每个单位包含所有等级的战斗数据、升级花费和时间、中文介绍、所需大本营等级、装备技能"
            },
            "units": found_units
        }, f, ensure_ascii=False, indent=2)

    total_levels = sum(len(u['levels']) for u in found_units)
    file_mb = os.path.getsize(output_path) / (1024 * 1024)
    print(f"\n{'='*50}")
    print(f"OK 输出: {output_path}")
    print(f"   单位数: {len(found_units)}  等级行: {total_levels}  大小: {file_mb:.1f}MB")
    if not_found:
        print(f"   未找到 {len(not_found)} 个")
    print(f"{'='*50}")

# ============ 主入口 ============
def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    apk_path = os.path.abspath(sys.argv[1])
    xlsx_path = os.path.abspath(sys.argv[2]) if len(sys.argv) > 2 else BUILTIN_XLSX
    output_dir = os.path.abspath(sys.argv[3]) if len(sys.argv) > 3 else os.getcwd()
    if not os.path.exists(apk_path):
        print(f"APK 文件不存在: {apk_path}"); sys.exit(1)
    if not os.path.exists(xlsx_path):
        print(f"名称表不存在: {xlsx_path}\n内置默认: {BUILTIN_XLSX}"); sys.exit(1)
    os.makedirs(output_dir, exist_ok=True)
    work_dir = tempfile.mkdtemp(prefix='coc_pipeline_')
    print(f"APK: {apk_path}\n名称表: {xlsx_path}\n输出: {output_dir}")
    raw_dir = extract_apk(apk_path, work_dir)
    out_map = decrypt_all(raw_dir, work_dir)
    all_data, tid_to_cn = parse_all_data(out_map, work_dir)
    output_path = os.path.join(output_dir, '单位完整数据.json')
    export_units_json(all_data, tid_to_cn, xlsx_path, output_path)
    import shutil
    shutil.rmtree(work_dir, ignore_errors=True)
    print("\n完成！")

if __name__ == '__main__':
    main()
