# COC 18.400.22 本地数据导出器

本包以本地 Android 安装包为输入，校验 APK v2/v3 签名后生成结构化 JSON。18.400.22 基准为 273 个精选单位、3491 行等级数据、42 件装备、16 组有效超级充能和 35 个超级充能阶段；包含英文名 `Revenge Deck`（中文名“反击卡组”）。

## 使用

安装唯一的密码学依赖：

```powershell
python -m pip install --requirement requirements.txt
```

只读解析与校验：

```powershell
python .\apk_data_pipeline.py --apk "C:\你的路径\Clash.apk"
```

生成 JSON：

```powershell
python .\apk_data_pipeline.py `
  --apk "C:\你的路径\Clash.apk" `
  --output ".\单位完整数据.json"
```

使用自己的精选名称表：

```powershell
python .\apk_data_pipeline.py --apk ".\Clash.apk" --roster-xlsx ".\你的名称表.xlsx" --output ".\单位完整数据.json"
```

`village_parser.py` 可结合生成的 JSON 解析游戏内账号数据；实时玩家和部落查询不在这个静态包中。

## 权利说明

本包是非官方玩家工具，未经 Supercell 认可或赞助。《部落冲突》的名称、客户端、数值与素材权利归相应权利人所有。请遵守 Supercell 的服务条款和玩家内容政策，不要用本工具分发客户端或获取未授权内容。
