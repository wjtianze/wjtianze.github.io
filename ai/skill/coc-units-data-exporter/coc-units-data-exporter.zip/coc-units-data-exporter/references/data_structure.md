# CoC 数据提取参考文档

## APK 内部结构

```
assets/
├── logic/          ← 91张核心数值表 (Sig:签名头 + LZMA加密)
│   ├── characters.csv      兵种(含超级兵、BB兵种、守卫等)
│   ├── spells.csv          法术
│   ├── heroes.csv          英雄(含BB英雄)
│   ├── pets.csv            战宠
│   ├── buildings.csv       建筑(含BB建筑、都城建筑)
│   ├── traps.csv           陷阱(含BB陷阱)
│   ├── townhall_levels.csv 大本营等级
│   ├── character_items.csv 英雄装备
│   ├── special_abilities.csv 技能数值
│   └── ... (共91张)
├── csv/            ← 25张客户端表(UI/配置类)
└── localization/   ← 23个语言文件 (LZMA加密，无Sig:头)
    ├── texts.csv           英文主表
    ├── cn.csv              简体中文
    └── ... (各语言)
```

## 解密方式

- **逻辑表 (logic/)**: 以 `Sig:` 签名头开头 + LZMA 压缩。用 `sc_compression.decompress()` 解密。
- **本地化 (localization/)**: 直接是 LZMA 魔数开头(无 `Sig:` 头)。同样用 `decompress()` 但需无条件尝试。
- **客户端表 (csv/)**: 部分加密部分纯文本。统一尝试 `decompress()`，失败则当纯文本。

## 宽表结构 (关键！)

CoC 的 CSV 是"宽表"：每个实体(如野蛮人)的所有等级数据在连续行中。

```
第0行: Name,VisualLevel,Hitpoints,DPS,UpgradeCost,UpgradeTimeH,UpgradeTimeM,...
第1行: String,int,int,int,int,int,int,...    ← 数据类型行(跳过)
第2行: Barbarian,1,45,9,10000,0,30,...       ← 基础行(L1，含全部属性)
第3行: ,2,54,12,50000,1,,...                 ← L2(只写变化的值，空=继承基础行)
第4行: ,3,65,15,130000,2,,...                ← L3
...
第14行: ,13,310,51,,,,...                    ← L13(满级，升级花费/时间为空)
```

### NO_INHERIT 规则 (核心修复)

**描述类字段**（TID、HousingSpace、Speed 等）全等级相同，空值=继承基础行。

**每级独立字段**（升级花费、升级时间、建造花费等）每级独立填写：
- 空值 = 0 或无值（如满级无升级花费），**不从基础行继承**
- 必须显式置空

NO_INHERIT 字段集合:
```
UpgradeCost, UpgradeTimeH, UpgradeTimeM, UpgradeTimeS,
BuildCost, BuildTimeD, BuildTimeH, BuildTimeM, BuildTimeS,
TrainingCost, TrainingTime, GearUpCost, GearUpTime, BoostCost,
UpgradeCosts, UpgradeResources  ← 装备表用的复数字段名
```

### 校验基准

野蛮人 L1:
- Hitpoints=45, DPS=9(Damage字段), UpgradeCost=10000, UpgradeTimeH=0, UpgradeTimeM=30
- UpgradeResource=Elixir, TID=TID_BARBARIAN → 中文名=野蛮人

野蛮人 L2: UpgradeTimeM 应为空(=0)，不应继承 L1 的 30。
野蛮人 L13(满级): UpgradeCost/UpgradeTimeH/UpgradeTimeM 应为空。

## GlobalID 编号段

| 类型 | ID段 | 说明 |
|------|------|------|
| 建筑 | 1000000+ | 家乡建筑 |
| 兵种 | 4000000+ | 家乡兵种(BB兵种在4000031+) |
| 英雄 | 28000000+ | 无GlobalID字段，需硬编码 |
| 陷阱 | 12000000+ | 家乡陷阱 |
| 装饰 | 18000000+ | 家乡装饰 |
| 法术 | 26000000+ | 家乡法术 |
| 装备 | 90000000+ | 无GlobalID字段，需硬编码 |
| 皮肤 | 52000000+ | 无GlobalID字段 |
| 场景 | 60000000+ | 无GlobalID字段 |

## 名称匹配优先级

同名实体可能出现在多个表中(如 "Cannon" 在 buildings 和 capital_buildings 都有)。
按表优先级匹配：家乡逻辑表(1) > 都城表(3) > 其他(9)。

## 已知坑

1. **本地化文件不以 `Sig:` 开头** → 必须无条件尝试 `decompress()`。
2. **逻辑表头后第2行是数据类型行**（String/int…），数据从第3行起。
3. **满级无升级花费/时间** → NO_INHERIT 字段必须置空，不能继承基础行。
4. **装备表用复数字段名** `UpgradeCosts`/`UpgradeResources`（带s），也要加入 NO_INHERIT。
5. **VillageType=1** 是区分家乡/夜世界(BB)的关键字段。
6. **BB兵种实体名以 "BB " 开头**（如 "BB Boxer Giant"），不是 "Boxer Giant"。
7. **英雄/装备无 GlobalID 字段** → 需用硬编码映射表。
8. **sc_compression 安装** → pypi.org 可能 SSL 失败，用清华镜像源。
9. **openpyxl 安装** → 同上，用清华镜像源。
