---
name: coc-units-data-exporter
description: "从部落冲突(Clash of Clans) APK 中提取全部单位(兵种、法术、英雄、战宠、装备、建筑、陷阱等)的完整游戏数据，输出结构化 JSON。输入 APK 文件路径和可选的单位名称表 xlsx，即可获得含所有等级数值(生命值、DPS、升级花费和时间等)的 JSON。内置默认单位名称表，用户也可上传自定义表覆盖。当用户提供 CoC APK 并要求提取、导出或查询游戏数据时触发此技能。"
agent_created: true
---

# CoC Units Data Exporter

## Overview

从《部落冲突》APK 中提取全部单位的完整游戏数据，输出结构化 JSON。涵盖兵种、法术、
英雄、战宠、英雄装备、建筑、陷阱等所有单位类型，包含每个等级的生命值、攻击力、
升级花费、升级时间等全部数值字段。

## 触发条件

当用户执行以下操作时触发：
- 提供部落冲突 APK 文件，要求提取/导出/查询游戏数据
- 要求获取兵种/建筑/法术等单位的数值数据
- 要求生成单位数据的 JSON / CSV

## 使用方法

### 前置条件

- Python 3.10+（受管 venv: `C:\Users\admin\.workbuddy\binaries\python\envs\default\Scripts\python.exe`）
- 依赖包 `sc_compression`、`openpyxl`（脚本自动安装，使用清华镜像源）

### 运行脚本

```bash
# 基本用法（使用内置默认单位名称表）
python scripts/coc_pipeline.py "<APK文件路径>"

# 指定自定义单位名称表
python scripts/coc_pipeline.py "<APK文件路径>" "<名称表.xlsx>"

# 指定输出目录
python scripts/coc_pipeline.py "<APK文件路径>" "<名称表.xlsx>" "<输出目录>"
```

脚本自动完成以下 7 步：
1. **提取**: 从 APK(zip) 中提取 `assets/logic/*.csv`(91张数值表) 和 `assets/localization/*.csv`(语言文件)
2. **解密**: 用 `sc_compression.decompress()` 解密 LZMA 加密的文件
3. **解析**: 解析宽表结构(实体→等级→字段)，含 NO_INHERIT 修复(满级不继承升级花费)
4. **映射**: 构建建筑等级→大本营等级映射 + 技能名→技能数据映射
5. **读取**: 读取单位名称表(用户提供或内置默认)
6. **查找**: 按名称查找匹配所有单位(含子单位)，新增帮手角色(villager_apprentices)
7. **导出**: 输出 `单位完整数据.json`，含中文介绍、所需大本营等级、装备技能

### 输出 JSON 结构

```json
{
  "meta": {
    "totalUnits": 272,
    "features": ["中文介绍", "所需大本营等级", "装备技能", "帮手角色"],
    "stats": { "unitsWithDescription": 272, "rowsWithTownHallLevel": 3380, ... }
  },
  "units": [
    {
      "englishName": "Barbarian",
      "chineseName": "野蛮人",
      "globalID": "4000000",
      "category": "圣水兵",
      "table": "characters",
      "description": "这些无畏的勇士长着引人注目的胡子...",
      "staticAttributes": { "Speed": "220", "HousingSpace": "1", ... },
      "levels": [
        {
          "level": 1,
          "requiredTownHallLevel": 3,
          "Hitpoints": "45",
          "DPS": "9",
          "UpgradeCost": "10000",
          ...
        },
        ...
      ]
    },
    // 装备还会有 skills 字段:
    {
      "englishName": "Rage Vial",
      "levels": [
        {
          "level": 1,
          "requiredTownHallLevel": 8,
          "skills": [
            { "name": "BarbarianKingRage", "chineseName": "狂暴药水瓶", "type": "main", "abilityLevel": "1" }
          ]
        }
      ]
    }
  ]
}
```

- `description`: 中文介绍(从 InfoTID 提取)
- `requiredTownHallLevel`: 该等级所需的最低大本营等级(从建筑等级推算)
- `skills`: 装备技能(从 special_abilities 表展开)
- `staticAttributes`: 全等级相同的属性(速度、人口、射程等)
- `levels`: 每级变化的属性(生命值、DPS、升级花费、升级时间等)

### 内置资源

- `assets/default_unit_names.xlsx`: 默认单位名称表(28个sheet，覆盖家乡/BB/都城全部单位)
- `references/data_structure.md`: APK 内部结构、解密方式、宽表解析规则、已知坑等详细参考

## 关键注意事项

1. **NO_INHERIT 修复**: 升级花费/时间等"每级独立"字段，空值=0或无值(如满级)，不从基础行继承。详见 `references/data_structure.md`。
2. **表优先级**: 同名实体可能出现在多个表(如 "Cannon" 在 buildings 和 capital_buildings)，按家乡表 > 都城表 优先匹配。
3. **BB兵种实体名**: 以 "BB " 开头(如 "BB Boxer Giant")，中文名从 TID 映射获取(如 TID_IRONFIST_GIANT → 巨人拳击手)。
4. **英雄/装备无 GlobalID**: 需用硬编码映射表(脚本内置 HERO_ID_MAP)。
5. **依赖安装**: pypi.org 可能 SSL 失败，脚本自动使用清华镜像源 `https://pypi.tuna.tsinghua.edu.cn/simple`。
6. **仅提取文本数据**: 不提取 .sc/.sctx/.scdb 等图片/精灵/二进制资源。

## 校验基准

运行后检查野蛮人数据是否正确：
- L1: 生命45, DPS9, 花费10000圣水, 升级时间30分钟
- L2: 升级时间1小时(不是1小时30分钟)
- L13(满级): 升级花费/时间为空(不是继承L1的值)

如果以上校验不通过，说明 NO_INHERIT 逻辑有问题，检查 `references/data_structure.md` 中的修复规则。
