#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从本地 Clash of Clans APK 生成天择网精选游戏数据。

本脚本只读取本地文件，不下载依赖、不访问网络。实现沿用 vendored coc.py
4.0.0 的三项可靠思路：Supercell 签名 CSV 解码、character_items 顺序 ID、
装备技能展开；同时修正其宽表等级列推断和超级充能全表误收录问题。

示例：
    python coc/apk_data_pipeline.py --apk C:\\path\\Clash.apk \
        --output dev/coc/data/all_game_data_zh.json \
        --mirror dev/open/单位完整数据.json
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import lzma
import math
import re
import struct
import sys
import zipfile
from pathlib import Path
from typing import Any, Iterable
from xml.etree import ElementTree as ET


PIPELINE_VERSION = "3.0.0"
LZMA_MARKER = b"\x5d\x00\x00\x04\x00"
APK_SIG_MAGIC = b"APK Sig Block 42"
EOCD_MAGIC = b"PK\x05\x06"

SCHEME_NAMES = {
    0x7109871A: "v2",
    0xF05368C0: "v3",
    0x1B93AD61: "v3.1",
}
SOURCE_STAMP_ID = 0x6DFF800D

REQUIRED_LOGIC_TABLES = {
    "buildings",
    "character_items",
    "characters",
    "heroes",
    "mini_levels",
    "pets",
    "special_abilities",
    "spells",
    "townhall_levels",
    "traps",
    "villager_apprentices",
}

# 等级列必须按表显式声明，绝不能像旧 coc.py 那样根据“第二列是 int”猜测。
LEVEL_COLUMN_BY_TABLE: dict[str, str | None] = {
    "buildings": "BuildingLevel",
    "character_items": "Level",
    "characters": "VisualLevel",
    "heroes": "VisualLevel",
    "mini_levels": "Level",
    "pets": "TroopLevel",
    "special_abilities": "Level",
    "spells": "Level",
    "townhall_levels": "Name",
    "traps": "Level",
    # 此表没有等级列，等级由同一实体内的物理行顺序明确给出。
    "villager_apprentices": None,
}

NO_INHERIT = {
    "BuildCost",
    "BuildTimeD",
    "BuildTimeH",
    "BuildTimeM",
    "BuildTimeS",
    "BoostCost",
    "GearUpCost",
    "GearUpTime",
    "TrainingCost",
    "TrainingTime",
    "UpgradeCost",
    "UpgradeCosts",
    "UpgradeResources",
    "UpgradeTimeH",
    "UpgradeTimeM",
    "UpgradeTimeS",
}

# mini_levels 的数值是“本阶段增量”，空白表示本阶段不增加，不能继承首行。
MINI_LEVEL_NO_INHERIT = {
    "MaxStoredGold",
    "MaxStoredElixir",
    "MaxStoredDarkElixir",
    "ResourcePer100Hours",
    "ResourceMax",
    "Hitpoints",
    "DPS",
    "DPSLv2",
    "DPSLv3",
    "AltDPS",
    "ProjectileSpellDamageBoost",
    "SpecialAbilityLevelBuff",
    "StrengthWeight",
    "HintPriority",
    "PriceDiscountPercentage",
    "TimeDiscountPercentage",
}

TABLE_PRIORITY = {
    "characters": 1,
    "spells": 1,
    "heroes": 1,
    "pets": 1,
    "buildings": 1,
    # Tornado Trap / ShrinkTrap 同时存在于 spells（战斗效果）和 traps
    # （可升级实体）中；精选单位必须稳定选择带 TID、造价和大本营限制的实体。
    "traps": 0,
    "townhall_levels": 1,
    "character_items": 1,
    "villager_apprentices": 1,
}

HERO_ID_MAP = {
    "Barbarian King": "28000000",
    "Archer Queen": "28000001",
    "Grand Warden": "28000002",
    "Battle Machine": "28000003",
    "Royal Champion": "28000004",
    "Battle Copter": "28000005",
    "Minion Prince": "28000006",
}

DISPLAY_ENGLISH_OVERRIDES = {"Draconic Counter": "Revenge Deck"}
ABILITY_CN_OVERRIDES = {"DragonScaleReflect": "反击卡组"}

ABILITY_FIELDS = (
    ("伤害", "Damage", None),
    ("伤害半径", "DamageRadius", None),
    ("激活治疗量", "HealOnActivation", None),
    ("速度提升", "SpeedBoost", None),
    ("伤害加成(%)", "BoostDamagePercentage", None),
    ("攻速加成(%)", "BoostAttackSpeedPercentage", None),
    ("护盾保护(%)", "ShieldProtectionPercent", None),
    ("陷阱护盾保护(%)", "TrapShieldProtectionPercent", None),
    ("持续时间", "DeactivateAfterTime", "ms"),
    ("冰冻时间", "FrostOnHitTime", "ms"),
    ("减速(%)", "FrostOnHitPercent", None),
    ("眩晕时间", "StunTargetOnActivateTime", "ms"),
    ("生命恢复/次", "Regeneration", None),
    ("生命恢复间隔", "RegenerationTimeBetweenHitsMS", "ms"),
    ("生命值覆盖", "HealthOverride", None),
    ("生命百分比提升(%)", "PercentHealthIncrease", None),
    ("对防御建筑额外伤害(%)", "ExtraDamagePercentageAgainstTarget", None),
    ("冷却时间", "CoolDownOverride", "ms"),
    ("最大激活次数", "MaxActivations", None),
    ("召唤兵种", "SpawnedTroop", None),
    ("召唤数量", "TroopCount", None),
    ("召唤等级", "TroopLevel", None),
    ("死亡伤害", "DieDamage", None),
    ("死亡伤害半径", "DieDamageRadius", None),
    ("穿透伤害", "ActAsPenetratingDamage", None),
    ("反射伤害", "ReflectedDamage", None),
    ("反射治疗", "HealOnReflect", None),
    ("反射冷却", "ReflectCooldownMS", "ms"),
    ("中毒持续时间", "PoisonOnHitDuration", "ms"),
    ("狂暴施法等级", "RageOnHitSpellLevel", None),
    ("护盾时间", "ActiveAfterTime", "ms"),
    ("成长缩放", "GrowthScale", None),
    ("摧毁建筑后激活", "ActiveAfterNumBuildingsDestroyed", None),
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def decode_csv_container(data: bytes) -> tuple[bytes, str, int]:
    """解码 Supercell 的 Sig:+LZMA CSV 容器；逻辑与 coc.py 解码器一致。"""
    offset = data.find(LZMA_MARKER)
    if offset < 0:
        data.decode("utf-8")
        return data, "plain", 0
    stream = data[offset:]
    # Supercell 流省略 LZMA-alone 的高四字节未压缩长度。
    patched = stream[:8] + b"\x00\x00\x00\x00" + stream[8:]
    decoded = lzma.decompress(patched, format=lzma.FORMAT_AUTO)
    decoded.decode("utf-8")
    return decoded, "lzma", offset


def extract_decoded_csv(apk_path: Path) -> tuple[dict[str, dict[str, str]], dict[str, dict[str, Any]]]:
    decoded_text: dict[str, dict[str, str]] = {"logic": {}, "csv": {}, "localization": {}}
    aggregate_state: dict[str, dict[str, Any]] = {}
    with zipfile.ZipFile(apk_path) as apk:
        names = sorted(
            name for name in apk.namelist()
            if name.endswith(".csv")
            and any(name.startswith(f"assets/{section}/") for section in decoded_text)
        )
        for name in names:
            section = name.split("/", 2)[1]
            decoded, _, _ = decode_csv_container(apk.read(name))
            decoded_text[section][Path(name).name] = decoded.decode("utf-8")
            state = aggregate_state.setdefault(
                section, {"count": 0, "bytes": 0, "hasher": hashlib.sha256()}
            )
            state["count"] += 1
            state["bytes"] += len(decoded)
            state["hasher"].update(name.encode("utf-8"))
            state["hasher"].update(b"\x00")
            state["hasher"].update(decoded)
            state["hasher"].update(b"\x00")

    aggregates: dict[str, dict[str, Any]] = {}
    for section, state in aggregate_state.items():
        aggregates[section] = {
            "count": state["count"],
            "decodedBytes": state["bytes"],
            "sha256": state["hasher"].hexdigest().upper(),
        }
    return decoded_text, aggregates


# ===== Android 二进制 Manifest =====
RES_STRING_POOL_TYPE = 0x0001
RES_XML_START_ELEMENT_TYPE = 0x0102
UTF8_FLAG = 0x00000100
TYPE_STRING = 0x03
TYPE_INT_DEC = 0x10
TYPE_INT_HEX = 0x11
TYPE_INT_BOOLEAN = 0x12
NO_INDEX = 0xFFFFFFFF


def _u16(data: bytes, offset: int) -> int:
    return struct.unpack_from("<H", data, offset)[0]


def _u32_at(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def _length8(data: bytes, offset: int) -> tuple[int, int]:
    first = data[offset]
    if first & 0x80:
        return ((first & 0x7F) << 8) | data[offset + 1], offset + 2
    return first, offset + 1


def _length16(data: bytes, offset: int) -> tuple[int, int]:
    first = _u16(data, offset)
    if first & 0x8000:
        return ((first & 0x7FFF) << 16) | _u16(data, offset + 2), offset + 4
    return first, offset + 2


def _parse_string_pool(data: bytes, chunk_offset: int) -> list[str]:
    header_size = _u16(data, chunk_offset + 2)
    string_count = _u32_at(data, chunk_offset + 8)
    flags = _u32_at(data, chunk_offset + 16)
    strings_start = _u32_at(data, chunk_offset + 20)
    offsets_start = chunk_offset + header_size
    strings_base = chunk_offset + strings_start
    result: list[str] = []
    for index in range(string_count):
        cursor = strings_base + _u32_at(data, offsets_start + index * 4)
        if flags & UTF8_FLAG:
            _, cursor = _length8(data, cursor)
            byte_length, cursor = _length8(data, cursor)
            result.append(data[cursor:cursor + byte_length].decode("utf-8"))
        else:
            char_length, cursor = _length16(data, cursor)
            result.append(data[cursor:cursor + char_length * 2].decode("utf-16le"))
    return result


def _string_at(strings: list[str], index: int) -> str | None:
    if index == NO_INDEX:
        return None
    if not 0 <= index < len(strings):
        raise ValueError(f"无效字符串索引：{index}")
    return strings[index]


def _typed_value(strings: list[str], raw_index: int, data_type: int, value: int) -> Any:
    raw = _string_at(strings, raw_index)
    if raw is not None:
        return raw
    if data_type == TYPE_STRING:
        return _string_at(strings, value)
    if data_type == TYPE_INT_DEC:
        return value
    if data_type == TYPE_INT_HEX:
        return f"0x{value:08x}"
    if data_type == TYPE_INT_BOOLEAN:
        return bool(value)
    return value


def parse_manifest_bytes(data: bytes) -> dict[str, Any]:
    if _u16(data, 0) != 0x0003:
        raise ValueError("AndroidManifest.xml 不是二进制 XML")
    xml_size = _u32_at(data, 4)
    cursor = _u16(data, 2)
    strings: list[str] | None = None
    manifest: dict[str, Any] | None = None
    uses_sdk: dict[str, Any] | None = None
    while cursor < xml_size:
        chunk_type = _u16(data, cursor)
        header_size = _u16(data, cursor + 2)
        chunk_size = _u32_at(data, cursor + 4)
        if not chunk_size or chunk_size < header_size:
            raise ValueError(f"Manifest 块损坏，偏移 {cursor}")
        if chunk_type == RES_STRING_POOL_TYPE:
            strings = _parse_string_pool(data, cursor)
        elif chunk_type == RES_XML_START_ELEMENT_TYPE:
            if strings is None:
                raise ValueError("Manifest 元素出现在字符串池之前")
            extension = cursor + 16
            element_name = _string_at(strings, _u32_at(data, extension + 4))
            attribute_start = _u16(data, extension + 8)
            attribute_size = _u16(data, extension + 10)
            attribute_count = _u16(data, extension + 12)
            attributes: dict[str, Any] = {}
            attributes_offset = extension + attribute_start
            for index in range(attribute_count):
                attr = attributes_offset + index * attribute_size
                name = _string_at(strings, _u32_at(data, attr + 4))
                raw_index = _u32_at(data, attr + 8)
                data_type = data[attr + 15]
                value = _u32_at(data, attr + 16)
                attributes[str(name)] = _typed_value(strings, raw_index, data_type, value)
            if element_name == "manifest":
                manifest = attributes
            elif element_name == "uses-sdk":
                uses_sdk = attributes
        cursor += chunk_size
    if manifest is None:
        raise ValueError("Manifest 缺少根元素")
    return {
        "packageName": manifest.get("package"),
        "versionName": manifest.get("versionName"),
        "versionCode": manifest.get("versionCode"),
        "compileSdkVersion": manifest.get("compileSdkVersion"),
        "minSdkVersion": (uses_sdk or {}).get("minSdkVersion"),
        "targetSdkVersion": (uses_sdk or {}).get("targetSdkVersion"),
    }


# ===== APK v2/v3 签名元数据和密码学验证 =====
def _lp32(data: bytes, offset: int) -> tuple[bytes, int]:
    length = _u32_at(data, offset)
    start = offset + 4
    end = start + length
    if end > len(data):
        raise ValueError("签名长度字段越界")
    return data[start:end], end


def _parse_signer(value: bytes, scheme_id: int) -> dict[str, Any]:
    signer_container, _ = _lp32(value, 0)
    signer, _ = _lp32(signer_container, 0)
    signed_data, signer_offset = _lp32(signer, 0)
    if scheme_id in (0xF05368C0, 0x1B93AD61):
        min_sdk = _u32_at(signer, signer_offset)
        max_sdk = _u32_at(signer, signer_offset + 4)
        signer_offset += 8
    else:
        min_sdk = max_sdk = None
    signatures, signer_offset = _lp32(signer, signer_offset)
    public_key, signer_offset = _lp32(signer, signer_offset)

    digests, signed_offset = _lp32(signed_data, 0)
    certificates, signed_offset = _lp32(signed_data, signed_offset)
    if scheme_id in (0xF05368C0, 0x1B93AD61):
        signed_offset += 8
    _, signed_offset = _lp32(signed_data, signed_offset)

    digest_record, _ = _lp32(digests, 0)
    algorithm = _u32_at(digest_record, 0)
    expected_digest, _ = _lp32(digest_record, 4)
    signature_record, _ = _lp32(signatures, 0)
    signature_algorithm = _u32_at(signature_record, 0)
    signature, _ = _lp32(signature_record, 4)
    certificate, _ = _lp32(certificates, 0)
    if algorithm != signature_algorithm:
        raise ValueError("签名和摘要算法不一致")
    return {
        "signedData": signed_data,
        "algorithm": algorithm,
        "expectedDigest": expected_digest,
        "signature": signature,
        "certificate": certificate,
        "publicKey": public_key,
        "minSdk": min_sdk,
        "maxSdk": max_sdk,
    }


def _find_eocd(path: Path) -> tuple[int, bytes]:
    size = path.stat().st_size
    tail_size = min(size, 22 + 65535)
    with path.open("rb") as handle:
        handle.seek(size - tail_size)
        tail = handle.read(tail_size)
    relative = tail.rfind(EOCD_MAGIC)
    if relative < 0:
        raise ValueError("APK 缺少 ZIP EOCD")
    return size - tail_size + relative, tail[relative:]


def _apk_content_digest_file(
    path: Path,
    signing_offset: int,
    central_offset: int,
    eocd_offset: int,
    hash_name: str,
) -> bytes:
    with path.open("rb") as handle:
        handle.seek(eocd_offset)
        eocd = bytearray(handle.read())
    struct.pack_into("<I", eocd, 16, signing_offset)
    ranges: tuple[tuple[int, int] | bytes, ...] = (
        (0, signing_offset),
        (central_offset, eocd_offset),
        bytes(eocd),
    )
    chunk_size = 1024 * 1024
    chunk_count = 0
    for region in ranges:
        length = len(region) if isinstance(region, bytes) else region[1] - region[0]
        chunk_count += math.ceil(length / chunk_size)
    top = hashlib.new(hash_name)
    top.update(b"\x5a")
    top.update(struct.pack("<I", chunk_count))
    with path.open("rb") as handle:
        for region in ranges:
            if isinstance(region, bytes):
                chunks: Iterable[bytes] = (
                    region[offset:offset + chunk_size]
                    for offset in range(0, len(region), chunk_size)
                )
            else:
                start, end = region
                handle.seek(start)

                def file_chunks() -> Iterable[bytes]:
                    remaining = end - start
                    while remaining:
                        chunk = handle.read(min(chunk_size, remaining))
                        if not chunk:
                            raise ValueError("计算 APK 摘要时提前到达文件尾")
                        remaining -= len(chunk)
                        yield chunk

                chunks = file_chunks()
            for chunk in chunks:
                inner = hashlib.new(hash_name)
                inner.update(b"\xa5")
                inner.update(struct.pack("<I", len(chunk)))
                inner.update(chunk)
                top.update(inner.digest())
    return top.digest()


def _verify_signer_crypto(signer: dict[str, Any], actual_digest: bytes) -> tuple[bool, str]:
    try:
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding
    except ImportError as exc:
        raise RuntimeError(
            "缺少 cryptography，无法完成 APK 签名验证；请显式安装 coc/requirements-apk-pipeline.txt，"
            "脚本不会自动联网安装。"
        ) from exc
    certificate = x509.load_der_x509_certificate(signer["certificate"])
    public_key = certificate.public_key()
    public_key_der = public_key.public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    if public_key_der != signer["publicKey"]:
        return False, certificate.subject.rfc4514_string()
    algorithm = signer["algorithm"]
    if algorithm == 0x0103:
        hash_algorithm = hashes.SHA256()
    elif algorithm == 0x0104:
        hash_algorithm = hashes.SHA512()
    else:
        raise ValueError(f"暂不支持 APK 签名算法 0x{algorithm:04x}")
    public_key.verify(
        signer["signature"],
        signer["signedData"],
        padding.PKCS1v15(),
        hash_algorithm,
    )
    return actual_digest == signer["expectedDigest"], certificate.subject.rfc4514_string()


def apk_signature_metadata(path: Path, verify: bool = True) -> dict[str, Any]:
    eocd_offset, eocd = _find_eocd(path)
    central_offset = _u32_at(eocd, 16)
    with path.open("rb") as handle:
        handle.seek(central_offset - 24)
        trailer = handle.read(24)
        if trailer[8:] != APK_SIG_MAGIC:
            raise ValueError("中央目录前没有 APK Signing Block")
        block_size = struct.unpack_from("<Q", trailer, 0)[0]
        block_start = central_offset - (block_size + 8)
        handle.seek(block_start)
        block = handle.read(block_size + 8)
    if struct.unpack_from("<Q", block, 0)[0] != block_size:
        raise ValueError("APK Signing Block 首尾长度不一致")

    pairs: dict[int, bytes] = {}
    cursor = 8
    pairs_end = len(block) - 24
    while cursor < pairs_end:
        pair_length = struct.unpack_from("<Q", block, cursor)[0]
        cursor += 8
        pair_end = cursor + pair_length
        if pair_length < 4 or pair_end > pairs_end:
            raise ValueError("APK Signing Block 条目损坏")
        pair_id = _u32_at(block, cursor)
        pairs[pair_id] = block[cursor + 4:pair_end]
        cursor = pair_end

    schemes: list[dict[str, Any]] = []
    certificates: dict[str, dict[str, Any]] = {}
    for scheme_id, scheme_name in SCHEME_NAMES.items():
        if scheme_id not in pairs:
            continue
        signer = _parse_signer(pairs[scheme_id], scheme_id)
        cert = signer["certificate"]
        cert_sha256 = hashlib.sha256(cert).hexdigest().upper()
        algorithm = signer["algorithm"]
        hash_name = "sha256" if algorithm == 0x0103 else "sha512"
        actual_digest = _apk_content_digest_file(
            path, block_start, central_offset, eocd_offset, hash_name
        )
        verified = None
        subject = None
        if verify:
            verified, subject = _verify_signer_crypto(signer, actual_digest)
        certificates.setdefault(
            cert_sha256,
            {
                "sha256": cert_sha256,
                "sha1": hashlib.sha1(cert).hexdigest().upper(),
                "subject": subject,
            },
        )
        schemes.append({
            "scheme": scheme_name,
            "algorithmId": f"0x{algorithm:04X}",
            "contentDigest": actual_digest.hex().upper(),
            "contentDigestMatches": actual_digest == signer["expectedDigest"],
            "signatureVerified": verified,
            "certificateSha256": cert_sha256,
        })

    stamp: dict[str, Any] | None = None
    if SOURCE_STAMP_ID in pairs:
        stamp_container, _ = _lp32(pairs[SOURCE_STAMP_ID], 0)
        stamp_cert, _ = _lp32(stamp_container, 0)
        stamp_hash = hashlib.sha256(stamp_cert).hexdigest().upper()
        with zipfile.ZipFile(path) as apk:
            expected_stamp = apk.read("stamp-cert-sha256").hex().upper()
        stamp = {
            "certificateSha256": stamp_hash,
            "zipDigestEntry": expected_stamp,
            "digestEntryMatches": stamp_hash == expected_stamp,
        }
    if not schemes:
        raise ValueError("APK 没有 v2/v3 签名")
    return {
        "signingBlockOffset": block_start,
        "signingBlockSize": block_size + 8,
        "schemes": schemes,
        "certificates": list(certificates.values()),
        "sourceStamp": stamp,
    }


# ===== XLSX 精选名单（纯标准库，不依赖 openpyxl） =====
_NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_NS_PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"


def _xlsx_cell_value(cell: ET.Element, shared: list[str]) -> str:
    cell_type = cell.get("t")
    value = cell.find(f"{{{_NS_MAIN}}}v")
    if cell_type == "inlineStr":
        return "".join(cell.itertext()).strip()
    if value is None or value.text is None:
        return ""
    if cell_type == "s":
        return shared[int(value.text)]
    return value.text.strip()


def _read_roster_workbook(workbook_bytes: bytes) -> list[tuple[str, str, list[str]]]:
    with zipfile.ZipFile(io.BytesIO(workbook_bytes)) as workbook:
        shared: list[str] = []
        if "xl/sharedStrings.xml" in workbook.namelist():
            root = ET.fromstring(workbook.read("xl/sharedStrings.xml"))
            for item in root.findall(f"{{{_NS_MAIN}}}si"):
                shared.append("".join(item.itertext()))

        rels_root = ET.fromstring(workbook.read("xl/_rels/workbook.xml.rels"))
        targets = {
            rel.get("Id"): rel.get("Target")
            for rel in rels_root.findall(f"{{{_NS_PKG_REL}}}Relationship")
        }
        workbook_root = ET.fromstring(workbook.read("xl/workbook.xml"))
        roster: list[tuple[str, str, list[str]]] = []
        sheets = workbook_root.find(f"{{{_NS_MAIN}}}sheets")
        if sheets is None:
            raise ValueError("XLSX 缺少 sheets")
        for sheet in sheets:
            category = sheet.get("name", "")
            if category == "README":
                continue
            rel_id = sheet.get(f"{{{_NS_REL}}}id")
            target = targets.get(rel_id)
            if not target:
                continue
            member = target.lstrip("/")
            if not member.startswith("xl/"):
                member = "xl/" + member
            root = ET.fromstring(workbook.read(member))
            for row in root.findall(f".//{{{_NS_MAIN}}}row"):
                values_by_col: dict[int, str] = {}
                for cell in row.findall(f"{{{_NS_MAIN}}}c"):
                    ref = cell.get("r", "A1")
                    letters = re.match(r"[A-Z]+", ref)
                    if not letters:
                        continue
                    col = 0
                    for letter in letters.group(0):
                        col = col * 26 + ord(letter) - 64
                    values_by_col[col - 1] = _xlsx_cell_value(cell, shared)
                if not values_by_col:
                    continue
                main_name = values_by_col.get(0, "").strip()
                if not main_name:
                    continue
                extras = [
                    values_by_col[index].strip()
                    for index in sorted(values_by_col)
                    if index > 0 and values_by_col[index].strip()
                ]
                roster.append((category, main_name, extras))
    if not any(name == "Draconic Counter" for _, name, _ in roster):
        roster.append(("龙王装备", "Draconic Counter", []))
    return roster


def read_roster_from_xlsx(workbook_path: Path) -> list[tuple[str, str, list[str]]]:
    return _read_roster_workbook(workbook_path.read_bytes())


def read_roster_from_skill_zip(skill_zip: Path) -> list[tuple[str, str, list[str]]]:
    with zipfile.ZipFile(skill_zip) as outer:
        members = [name for name in outer.namelist() if name.endswith("assets/default_unit_names.xlsx")]
        if len(members) != 1:
            raise ValueError("技能包内找不到唯一的 default_unit_names.xlsx")
        return _read_roster_workbook(outer.read(members[0]))


def read_roster(source: Path) -> list[tuple[str, str, list[str]]]:
    if source.suffix.lower() == ".xlsx":
        return read_roster_from_xlsx(source)
    if source.suffix.lower() == ".zip":
        return read_roster_from_skill_zip(source)
    raise ValueError("精选名单必须是 .xlsx 或包含该文件的技能 ZIP")


# ===== Supercell 宽表 =====
def parse_csv_rows(text: str) -> list[list[str]]:
    return list(csv.reader(io.StringIO(text.replace("\r\n", "\n").replace("\r", "\n"))))


def merge_level_rows(
    base: list[str] | None,
    override: list[str] | None,
    header: list[str],
    no_inherit: set[str] = NO_INHERIT,
) -> dict[str, str]:
    merged: dict[str, str] = {}
    if base:
        for index, field in enumerate(header):
            value = base[index] if index < len(base) else ""
            if value != "":
                merged[field] = value
    if override:
        for index, field in enumerate(header):
            value = override[index] if index < len(override) else ""
            if value != "":
                merged[field] = value
            elif field in no_inherit:
                merged.pop(field, None)
    return merged


def _level_value(row: list[str], level_index: int, fallback: int) -> int | str:
    value = row[level_index].strip() if level_index < len(row) else ""
    if not value:
        return fallback
    try:
        return int(value)
    except ValueError:
        return value


def parse_table(text: str, table_name: str) -> dict[str, Any]:
    rows = parse_csv_rows(text)
    if len(rows) < 2:
        raise ValueError(f"{table_name}.csv 行数不足")
    header = rows[0]
    level_column = LEVEL_COLUMN_BY_TABLE[table_name]
    if "Name" not in header or (level_column is not None and level_column not in header):
        raise ValueError(f"{table_name}.csv 缺少显式列 Name/{level_column}")
    name_index = header.index("Name")
    level_index = header.index(level_column) if level_column is not None else -1
    entities: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    base_row: list[str] | None = None
    no_inherit = NO_INHERIT | MINI_LEVEL_NO_INHERIT if table_name == "mini_levels" else NO_INHERIT
    for raw in rows[2:]:
        if not raw or not any(raw):
            continue
        row = raw + [""] * max(0, len(header) - len(raw))
        name = row[name_index].strip()
        if name:
            current = {"_name": name, "levels": {}}
            base_row = row
            entities.append(current)
            level = _level_value(row, level_index, 1) if level_index >= 0 else 1
            current["levels"][level] = merge_level_rows(base_row, None, header, no_inherit)
        elif current is not None and base_row is not None:
            numeric_levels = [level for level in current["levels"] if isinstance(level, int)]
            fallback = max(numeric_levels, default=0) + 1
            level = _level_value(row, level_index, fallback) if level_index >= 0 else fallback
            current["levels"][level] = merge_level_rows(base_row, row, header, no_inherit)
    return {"header": header, "entities": entities}


def parse_localization(text: str) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for row in parse_csv_rows(text):
        if len(row) < 2:
            continue
        tid = row[0].strip()
        value = row[1].strip()
        if tid and tid != "TID" and not tid.startswith("//") and value:
            mapping[tid] = value
    return mapping


def parse_required_data(decoded: dict[str, dict[str, str]]) -> tuple[dict[str, dict[str, Any]], dict[str, str], dict[str, str]]:
    logic: dict[str, dict[str, Any]] = {}
    for table_name in sorted(REQUIRED_LOGIC_TABLES):
        filename = table_name + ".csv"
        if filename not in decoded["logic"]:
            raise ValueError(f"APK 缺少 assets/logic/{filename}")
        logic[table_name] = parse_table(decoded["logic"][filename], table_name)
    english = parse_localization(decoded["localization"].get("texts.csv", ""))
    chinese = dict(english)
    chinese.update(parse_localization(decoded["localization"].get("cn.csv", "")))
    return logic, chinese, english


def _sort_level(value: Any) -> tuple[int, Any]:
    try:
        return 0, int(value)
    except (TypeError, ValueError):
        return 1, str(value)


def _first_level(entity: dict[str, Any]) -> tuple[Any, dict[str, str]]:
    key = min(entity["levels"], key=_sort_level)
    return key, entity["levels"][key]


def build_townhall_map(logic: dict[str, dict[str, Any]]) -> dict[str, dict[int, int]]:
    result: dict[str, dict[int, int]] = {}
    for entity in logic["buildings"]["entities"]:
        levels: dict[int, int] = {}
        for level, row in entity["levels"].items():
            if str(level).isdigit() and str(row.get("TownHallLevel", "")).isdigit():
                levels[int(level)] = int(row["TownHallLevel"])
        if levels:
            result[entity["_name"]] = levels
    return result


def calculate_required_townhall(
    table_name: str,
    entity: dict[str, Any],
    row: dict[str, str],
    townhall_map: dict[str, dict[int, int]],
) -> int | str:
    if table_name == "heroes":
        return row.get("RequiredTownHallLevel", "")
    if table_name in ("buildings", "traps"):
        return row.get("TownHallLevel", "")
    if table_name == "villager_apprentices":
        return row.get("RequiredTownHallLevel", "")
    if table_name == "characters":
        requirements: list[int] = []
        lab = row.get("LaboratoryLevel", "")
        if str(lab).isdigit():
            value = townhall_map.get("Laboratory", {}).get(int(lab))
            if value:
                requirements.append(value)
        _, base = _first_level(entity)
        production = base.get("ProductionBuilding", "")
        barracks = "Dark Barracks" if "Dark" in production else "Barracks"
        barracks_level = row.get("BarrackLevel", "")
        if str(barracks_level).isdigit():
            value = townhall_map.get(barracks, {}).get(int(barracks_level))
            if value:
                requirements.append(value)
        super_th = row.get("RequiredSuperTownHallLevel", "")
        if str(super_th).isdigit():
            requirements.append(int(super_th))
        return max(requirements) if requirements else ""
    if table_name == "spells":
        lab = row.get("LaboratoryLevel", "")
        return townhall_map.get("Laboratory", {}).get(int(lab), "") if str(lab).isdigit() else ""
    if table_name == "pets":
        lab = row.get("LaboratoryLevel", "")
        return townhall_map.get("Pet House", {}).get(int(lab), "") if str(lab).isdigit() else ""
    if table_name == "character_items":
        smithy = row.get("RequiredBlacksmithLevel", "")
        return townhall_map.get("Blacksmith", {}).get(int(smithy), "") if str(smithy).isdigit() else ""
    return ""


def equipment_id_map(logic: dict[str, dict[str, Any]]) -> dict[str, str]:
    # 与 coc.py 一致：包括废弃项在内按原表顺序枚举，过滤不能改变后续 ID。
    return {
        entity["_name"]: str(90000000 + index)
        for index, entity in enumerate(logic["character_items"]["entities"])
    }


def _ability_cn(name: str, entity: dict[str, Any], chinese: dict[str, str]) -> str:
    if name in ABILITY_CN_OVERRIDES:
        return ABILITY_CN_OVERRIDES[name]
    _, base = _first_level(entity)
    return chinese.get(base.get("TID", ""), "") or name


def _format_ability_value(value: str, formatter: str | None) -> str:
    if formatter != "ms":
        return value
    try:
        milliseconds = int(value)
    except (TypeError, ValueError):
        return value
    return f"{milliseconds / 1000:g}秒"


def build_ability_data(
    equipment: dict[str, Any],
    ability_map: dict[str, dict[str, Any]],
    spell_map: dict[str, dict[str, Any]],
    chinese: dict[str, str],
) -> list[dict[str, Any]]:
    _, base = _first_level(equipment)
    result: list[dict[str, Any]] = []
    for field, kind in (("MainAbilities", "主技能"), ("ExtraAbilities", "副技能")):
        for name in filter(None, (part.strip() for part in base.get(field, "").split(";"))):
            ability = ability_map.get(name)
            if not ability:
                continue
            levels: list[dict[str, str]] = []
            for level in sorted(ability["levels"], key=_sort_level):
                row = ability["levels"][level]
                output_row: dict[str, str] = {"等级": str(level)}
                for label, raw_field, formatter in ABILITY_FIELDS:
                    value = row.get(raw_field, "")
                    if value != "":
                        output_row[label] = _format_ability_value(value, formatter)
                self_spell = row.get("SelfSpell", "")
                self_spell_level = row.get("SelfSpellLevel", "")
                if self_spell:
                    output_row["触发法术"] = self_spell
                if self_spell_level:
                    output_row["触发法术等级"] = self_spell_level
                    spell = spell_map.get(self_spell)
                    if spell:
                        spell_key: Any = int(self_spell_level) if self_spell_level.isdigit() else self_spell_level
                        spell_row = spell["levels"].get(spell_key)
                        if spell_row and spell_row.get("Damage", "") != "":
                            output_row["触发法术伤害"] = spell_row["Damage"]
                levels.append(output_row)
            result.append({
                "name": name,
                "chineseName": _ability_cn(name, ability, chinese),
                "type": kind,
                "levels": levels,
            })
    return result


def _direct_skill_damage(
    equipment_row: dict[str, str],
    equipment_base: dict[str, str],
    ability_map: dict[str, dict[str, Any]],
    spell_map: dict[str, dict[str, Any]],
) -> str | None:
    total = 0
    found = False
    for names_field, levels_field in (
        ("MainAbilities", "MainAbilityLevels"),
        ("ExtraAbilities", "ExtraAbilityLevels"),
    ):
        names = [part.strip() for part in equipment_base.get(names_field, "").split(";") if part.strip()]
        levels = [part.strip() for part in equipment_row.get(levels_field, "").split(";") if part.strip()]
        for name, level in zip(names, levels):
            ability = ability_map.get(name)
            if not ability:
                continue
            ability_row = ability["levels"].get(int(level) if level.isdigit() else level)
            if not ability_row:
                continue
            # 反射伤害不是一次主动技能伤害，不能灌入伤害计算器的 SkillDamage。
            ability_damage_found = False
            for field in ("Damage", "DieDamage", "ActAsPenetratingDamage"):
                value = ability_row.get(field, "")
                try:
                    number = int(value)
                except (TypeError, ValueError):
                    continue
                if number:
                    total += number
                    found = True
                    ability_damage_found = True
                    break
            if ability_damage_found:
                continue
            self_spell = ability_row.get("SelfSpell", "")
            self_spell_level = ability_row.get("SelfSpellLevel", "")
            spell = spell_map.get(self_spell)
            if spell and str(self_spell_level).isdigit():
                spell_row = spell["levels"].get(int(self_spell_level))
                try:
                    number = int((spell_row or {}).get("Damage", ""))
                except (TypeError, ValueError):
                    number = 0
                if number:
                    total += number
                    found = True
    return str(total) if found else None


def build_unit_entry(
    table_name: str,
    entity: dict[str, Any],
    category: str,
    logic: dict[str, dict[str, Any]],
    chinese: dict[str, str],
    townhall_map: dict[str, dict[int, int]],
    ability_map: dict[str, dict[str, Any]],
    spell_map: dict[str, dict[str, Any]],
    equipment_ids: dict[str, str],
) -> dict[str, Any]:
    first_level, base = _first_level(entity)
    internal_name = entity["_name"]
    tid = base.get("TID", "")
    chinese_name = chinese.get(tid, "")
    if not chinese_name:
        for row in entity["levels"].values():
            chinese_name = chinese.get(row.get("TID", ""), "")
            if chinese_name:
                break
    info_tid = base.get("InfoTID", "")
    description = chinese.get(info_tid, "")

    global_id = base.get("GlobalID", "")
    if table_name == "character_items":
        global_id = equipment_ids[internal_name]
    elif not global_id:
        hero_name = internal_name[3:] if internal_name.startswith("BB ") else internal_name
        global_id = HERO_ID_MAP.get(hero_name, "")

    header = logic[table_name]["header"]
    static_attributes: dict[str, str] = {}
    for field in header:
        value = base.get(field, "")
        if value == "":
            continue
        if all(row.get(field, "") == value for row in entity["levels"].values()):
            static_attributes[field] = value

    levels: list[dict[str, Any]] = []
    for level in sorted(entity["levels"], key=_sort_level):
        row = entity["levels"][level]
        level_output: dict[str, Any] = {
            "level": int(level) if str(level).isdigit() else level
        }
        for field in header:
            value = row.get(field, "")
            if value != "" and field not in static_attributes:
                level_output[field] = value
        townhall = calculate_required_townhall(table_name, entity, row, townhall_map)
        if townhall != "":
            level_output["requiredTownHallLevel"] = int(townhall) if str(townhall).isdigit() else townhall
        if table_name == "character_items":
            skills: list[dict[str, str]] = []
            for names_field, levels_field, kind in (
                ("MainAbilities", "MainAbilityLevels", "main"),
                ("ExtraAbilities", "ExtraAbilityLevels", "extra"),
            ):
                names = [part.strip() for part in base.get(names_field, "").split(";") if part.strip()]
                ability_levels = [part.strip() for part in row.get(levels_field, "").split(";") if part.strip()]
                for name, ability_level in zip(names, ability_levels):
                    ability = ability_map.get(name)
                    if ability:
                        skills.append({
                            "name": name,
                            "chineseName": _ability_cn(name, ability, chinese),
                            "type": kind,
                            "abilityLevel": ability_level,
                        })
            if skills:
                level_output["skills"] = skills
            skill_damage = _direct_skill_damage(row, base, ability_map, spell_map)
            if skill_damage is not None:
                level_output["SkillDamage"] = skill_damage
        levels.append(level_output)

    output: dict[str, Any] = {
        "englishName": DISPLAY_ENGLISH_OVERRIDES.get(internal_name, internal_name),
        "chineseName": chinese_name,
        "globalID": str(global_id),
        "category": category,
        "table": table_name,
        "staticAttributes": static_attributes,
        "levels": levels,
    }
    if internal_name != output["englishName"]:
        output["internalName"] = internal_name
    if description:
        output["description"] = description
    if table_name == "character_items":
        output["abilityData"] = build_ability_data(entity, ability_map, spell_map, chinese)
    return output


def _entity_index(logic: dict[str, dict[str, Any]]) -> dict[str, tuple[int, str, dict[str, Any]]]:
    result: dict[str, tuple[int, str, dict[str, Any]]] = {}
    for table_name, table in logic.items():
        priority = TABLE_PRIORITY.get(table_name, 9)
        for entity in table["entities"]:
            name = entity["_name"]
            if name.startswith(("UNUSED", "unused")):
                continue
            existing = result.get(name)
            if existing is None or priority < existing[0]:
                result[name] = (priority, table_name, entity)
            lower = name.lower()
            existing = result.get(lower)
            if existing is None or priority < existing[0]:
                result[lower] = (priority, table_name, entity)
    return result


def _inject_builder_repair(units: list[dict[str, Any]], logic: dict[str, dict[str, Any]]) -> None:
    builders = next(
        (entity for entity in logic["characters"]["entities"] if entity["_name"] == "Defending Builder"),
        None,
    )
    hut = next((unit for unit in units if unit.get("englishName") == "Builders Hut"), None)
    if not builders or not hut:
        return
    repair_by_level: dict[int, str] = {}
    for level, row in builders["levels"].items():
        try:
            repair_by_level[int(level)] = str(abs(int(row.get("DPS", "0"))))
        except (TypeError, ValueError):
            continue
    for row in hut["levels"]:
        defender_level = row.get("DefenceTroopLevel")
        if str(defender_level).isdigit() and int(defender_level) in repair_by_level:
            row["BuilderRepairPerSecond"] = repair_by_level[int(defender_level)]


def attach_active_supercharges(units: list[dict[str, Any]], logic: dict[str, dict[str, Any]]) -> tuple[int, int]:
    groups = {entity["_name"]: entity for entity in logic["mini_levels"]["entities"]}
    buildings = {entity["_name"]: entity for entity in logic["buildings"]["entities"]}
    active_groups: set[str] = set()
    level_rows = 0
    for unit in units:
        internal_name = unit.get("internalName", unit["englishName"])
        building = buildings.get(internal_name)
        if not building:
            continue
        _, building_base = _first_level(building)
        group_name = building_base.get("MiniLevels", "")
        if not group_name:
            continue
        group = groups.get(group_name)
        if not group:
            raise ValueError(f"建筑 {internal_name} 引用了不存在的超级充能组 {group_name}")
        _, group_base = _first_level(group)
        levels: list[dict[str, Any]] = []
        for level in sorted(group["levels"], key=_sort_level):
            row = group["levels"][level]
            output_row: dict[str, Any] = {"level": int(level) if str(level).isdigit() else level}
            for field in logic["mini_levels"]["header"]:
                value = row.get(field, "")
                if value != "" and field not in ("Name", "Level", "TargetBuilding"):
                    output_row[field] = value
            levels.append(output_row)
        unit["supercharge"] = {
            "group": group_name,
            "targetBuilding": group_base.get("TargetBuilding", internal_name),
            "requiredTownHallLevel": int(group_base["RequiredTownHallLevel"]),
            "levels": levels,
        }
        active_groups.add(group_name)
        level_rows += len(levels)
    return len(active_groups), level_rows


def export_units(
    logic: dict[str, dict[str, Any]],
    chinese: dict[str, str],
    roster: list[tuple[str, str, list[str]]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    townhall_map = build_townhall_map(logic)
    ability_map = {
        entity["_name"]: entity
        for entity in logic["special_abilities"]["entities"]
        if not entity["_name"].startswith(("UNUSED", "unused"))
    }
    spell_map = {entity["_name"]: entity for entity in logic["spells"]["entities"]}
    equipment_ids = equipment_id_map(logic)
    index = _entity_index(logic)
    found: set[str] = set()
    units: list[dict[str, Any]] = []
    not_found: list[dict[str, Any]] = []

    def add(category: str, requested_name: str) -> bool:
        match = index.get(requested_name) or index.get(requested_name.lower())
        if not match:
            return False
        _, table_name, entity = match
        identity = f"{table_name}:{entity['_name']}"
        if identity in found:
            return True
        found.add(identity)
        units.append(build_unit_entry(
            table_name,
            entity,
            category,
            logic,
            chinese,
            townhall_map,
            ability_map,
            spell_map,
            equipment_ids,
        ))
        return True

    for category, main_name, extras in roster:
        if not add(category, main_name):
            not_found.append({"category": category, "name": main_name, "extras": extras})
        for extra in extras:
            add(category, extra)

    for entity in logic["villager_apprentices"]["entities"]:
        add("帮手角色", entity["_name"])

    _inject_builder_repair(units, logic)
    return units, not_found


def _unit_by_internal(units: list[dict[str, Any]], name: str) -> dict[str, Any]:
    for unit in units:
        if unit.get("internalName", unit["englishName"]) == name:
            return unit
    raise AssertionError(f"输出缺少单位 {name}")


def validate_document_integrity(document: dict[str, Any]) -> None:
    """校验所有名单都必须满足的结构不变量，不强制默认精选名单数量。"""
    units = document.get("units")
    meta = document.get("meta")
    if not isinstance(units, list) or not isinstance(meta, dict):
        raise AssertionError("输出必须包含 meta 对象和 units 数组")
    if meta.get("apk", {}).get("packageName") != "com.supercell.clashofclans":
        raise AssertionError("APK 包名不是国际服 com.supercell.clashofclans")
    stats = meta.get("stats", {})
    total_rows = sum(len(unit.get("levels", [])) for unit in units)
    expected = {
        "totalUnits": len(units),
        "totalLevelRows": total_rows,
        "equipmentUnits": sum(1 for unit in units if unit.get("table") == "character_items"),
        "activeSuperchargeGroups": sum(1 for unit in units if unit.get("supercharge")),
        "superchargeLevelRows": sum(
            len(unit.get("supercharge", {}).get("levels", [])) for unit in units
        ),
    }
    for field, value in expected.items():
        if stats.get(field) != value:
            raise AssertionError(f"统计字段 {field} 应为 {value}，实际 {stats.get(field)}")
    if meta.get("totalUnits") != len(units):
        raise AssertionError("meta.totalUnits 与 units 数量不一致")
    if meta.get("unitsNotFound") != len(meta.get("notFoundList", [])):
        raise AssertionError("未找到名单数量与明细不一致")

    identities: set[tuple[str, str]] = set()
    for unit in units:
        name = unit.get("internalName", unit.get("englishName"))
        identity = (str(unit.get("table", "")), str(name or ""))
        if not all(identity):
            raise AssertionError("单位缺少 table 或英文/内部名称")
        if identity in identities:
            raise AssertionError(f"输出含重复单位 {identity[0]}:{identity[1]}")
        identities.add(identity)
        levels = unit.get("levels")
        if not isinstance(levels, list) or not levels:
            raise AssertionError(f"单位 {identity[1]} 缺少等级数组")
        seen_levels: set[int | str] = set()
        for row in levels:
            if "level" not in row:
                raise AssertionError(f"单位 {identity[1]} 存在缺少显式 level 的等级行")
            level = row["level"]
            if level in seen_levels:
                raise AssertionError(f"单位 {identity[1]} 存在重复等级 {level}")
            seen_levels.add(level)


def validate_output(document: dict[str, Any]) -> None:
    """校验随包默认名单的 18.400.22 精确基准。"""
    validate_document_integrity(document)
    units = document["units"]
    meta = document["meta"]
    if meta["apk"]["versionName"] != "18.400.22":
        raise AssertionError(f"预期 18.400.22，实际 {meta['apk']['versionName']}")
    if len(units) != 273:
        raise AssertionError(f"精选单位数应为 273，实际 {len(units)}")
    if sum(len(unit.get("levels", [])) for unit in units) != 3491:
        raise AssertionError("精选等级行数不是 3491")

    revenge = _unit_by_internal(units, "Draconic Counter")
    if (revenge["englishName"], revenge["chineseName"], revenge["globalID"]) != (
        "Revenge Deck", "反击卡组", "90000060"
    ):
        raise AssertionError("反击卡组身份字段错误")
    if any("DPS" in row for row in revenge["levels"]):
        raise AssertionError("18.400.22 反击卡组不应保留旧 DPS")
    reflect = next(item for item in revenge["abilityData"] if item["name"] == "DragonScaleReflect")
    reflected = [row.get("反射伤害") for row in reflect["levels"]]
    healed = [row.get("反射治疗") for row in reflect["levels"]]
    if reflected != ["150", "155", "160", "165", "175", "185", "195", "205", "215", "225"]:
        raise AssertionError("反击卡组反射伤害数组错误")
    if healed != ["30", "32", "35", "39", "43", "46", "49", "52", "55", "60"]:
        raise AssertionError("反击卡组反射治疗数组错误")

    active = [unit for unit in units if unit.get("supercharge")]
    if len(active) != 16:
        raise AssertionError(f"活动超级充能建筑应为 16，实际 {len(active)}")
    inactive = {"Builders Hut", "Wizard Tower", "Monolith"}
    if any(unit.get("internalName", unit["englishName"]) in inactive for unit in active):
        raise AssertionError("输出误收录了未激活超级充能残留")

    expected_rows = {
        ("Electro Dragon", 8): {"Hitpoints": "6400", "DPS": "475"},
        ("Electro Dragon", 9): {"Hitpoints": "6900", "DPS": "510"},
        ("Dragon Rider", 6): {"Hitpoints": "5900", "DPS": "490"},
        ("Meteor Golem", 1): {"Hitpoints": "14500", "DPS": "480"},
        ("Meteor Golem", 2): {"Hitpoints": "16000", "DPS": "530"},
        ("Meteor Golem", 3): {"Hitpoints": "17500", "DPS": "580"},
        ("Meteormite", 1): {"Hitpoints": "7250", "DPS": "190"},
        ("Meteormite", 2): {"Hitpoints": "8000", "DPS": "210"},
        ("Meteormite", 3): {"Hitpoints": "8750", "DPS": "230"},
        ("Druid", 5): {"DPS": "-105"},
        ("Druid", 6): {"DPS": "-115"},
        ("Guardian Logger", 1): {"PenetratingExtraRange": "500"},
        ("Guardian Logger", 2): {"PenetratingExtraRange": "500"},
        ("Guardian Logger", 3): {"PenetratingExtraRange": "500"},
        ("Guardian Logger", 4): {"PenetratingExtraRange": "600"},
        ("Guardian Logger", 5): {"PenetratingExtraRange": "600"},
    }
    for (name, level), expected in expected_rows.items():
        unit = _unit_by_internal(units, name)
        row = next(item for item in unit["levels"] if item["level"] == level)
        for field, value in expected.items():
            if row.get(field) != value:
                raise AssertionError(f"{name} Lv{level} {field} 应为 {value}，实际 {row.get(field)}")
    guardian_logger = _unit_by_internal(units, "Guardian Logger")
    if guardian_logger["staticAttributes"].get("Pushback") != "150":
        raise AssertionError("Guardian Logger Pushback 应为 150")
    earthquake = _unit_by_internal(units, "Earthquake")
    if [row.get("BuildingDamagePermil") for row in earthquake["levels"]] != [
        "29", "34", "42", "50", "58", "58", "58", "58"
    ]:
        raise AssertionError("地震法术原始伤害数据错误")


def build_document(apk_path: Path, roster_source: Path, verify_signature: bool = True) -> dict[str, Any]:
    apk_sha256 = sha256_file(apk_path)
    with zipfile.ZipFile(apk_path) as apk:
        manifest = parse_manifest_bytes(apk.read("AndroidManifest.xml"))
        zip_entries = len(apk.infolist())
    signing = apk_signature_metadata(apk_path, verify=verify_signature)
    decoded, aggregates = extract_decoded_csv(apk_path)
    logic, chinese, _ = parse_required_data(decoded)
    roster = read_roster(roster_source)
    default_roster_path = Path(__file__).resolve().parent / "assets" / "default_unit_names.xlsx"
    is_default_roster = roster_source.suffix.lower() == ".zip"
    if default_roster_path.is_file():
        is_default_roster = roster == read_roster_from_xlsx(default_roster_path)
    units, not_found = export_units(logic, chinese, roster)
    active_supercharges, supercharge_rows = attach_active_supercharges(units, logic)

    total_rows = sum(len(unit.get("levels", [])) for unit in units)
    document = {
        "meta": {
            "version": f"v{manifest['versionName']}",
            "totalUnits": len(units),
            "unitsNotFound": len(not_found),
            "notFoundList": not_found,
            "description": "由本地 APK 可复现生成的完整精选游戏数据，含装备技能、超级充能和来源校验信息",
            "features": [
                "中文介绍(description)",
                "所需大本营等级(requiredTownHallLevel)",
                "装备技能与能力数据(skills/abilityData)",
                "帮手角色(villager_apprentices)",
                "活动超级充能(supercharge)",
            ],
            "pipeline": {
                "name": "Tianze COC APK authoritative data pipeline",
                "version": PIPELINE_VERSION,
                "upstreamModel": "mathsman5133/coc.py 4.0.0 (MIT)",
                "networkAccess": False,
                "levelColumns": LEVEL_COLUMN_BY_TABLE,
                "superchargeJoin": "buildings.MiniLevels -> mini_levels.Name",
                "csvAggregateAlgorithm": "SHA-256(path + NUL + decoded bytes + NUL, sorted by APK path)",
            },
            "apk": {
                **manifest,
                "fileName": apk_path.name,
                "fileSize": apk_path.stat().st_size,
                "sha256": apk_sha256,
                "zipEntries": zip_entries,
                "signing": signing,
            },
            "csvAggregates": aggregates,
            "stats": {
                "totalUnits": len(units),
                "unitsWithDescription": sum(1 for unit in units if unit.get("description")),
                "totalLevelRows": total_rows,
                "rowsWithTownHallLevel": sum(
                    1 for unit in units for row in unit.get("levels", [])
                    if row.get("requiredTownHallLevel") not in (None, "")
                ),
                "rowsWithSkills": sum(
                    1 for unit in units for row in unit.get("levels", []) if row.get("skills")
                ),
                "helperCharacters": sum(1 for unit in units if unit.get("table") == "villager_apprentices"),
                "equipmentUnits": sum(1 for unit in units if unit.get("table") == "character_items"),
                "activeSuperchargeGroups": active_supercharges,
                "superchargeLevelRows": supercharge_rows,
            },
        },
        "units": units,
    }
    if is_default_roster:
        validate_output(document)
    else:
        validate_document_integrity(document)
    return document


def write_json(path: Path, document: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(document, ensure_ascii=False, indent=2) + "\n"
    path.write_text(text, encoding="utf-8", newline="\n")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apk", required=True, type=Path, help="本地 APK 路径")
    parser.add_argument("--output", type=Path, help="主 JSON 输出路径；不传则只验证")
    parser.add_argument("--mirror", action="append", default=[], type=Path, help="额外镜像输出，可重复")
    roster_group = parser.add_mutually_exclusive_group()
    roster_group.add_argument("--roster-xlsx", type=Path, help="精选单位名称表；默认读取技能包 assets/default_unit_names.xlsx")
    roster_group.add_argument("--skill-zip", type=Path, help="兼容旧版：含 default_unit_names.xlsx 的本地技能包")
    parser.add_argument(
        "--skip-crypto-verification",
        action="store_true",
        help="只读取签名证书和内容摘要，不验证 RSA；正式生成不建议使用",
    )
    args = parser.parse_args(argv)
    apk_path = args.apk.resolve()
    default_roster = Path(__file__).resolve().parent / "assets" / "default_unit_names.xlsx"
    legacy_zip = Path(__file__).with_name("coc-units-data-exporter.zip")
    roster_source = (args.roster_xlsx or args.skill_zip or (default_roster if default_roster.is_file() else legacy_zip)).resolve()
    if not apk_path.is_file():
        parser.error(f"APK 不存在：{apk_path}")
    if not roster_source.is_file():
        parser.error(f"精选名单不存在：{roster_source}")

    document = build_document(apk_path, roster_source, verify_signature=not args.skip_crypto_verification)
    targets = ([args.output] if args.output else []) + list(args.mirror)
    if args.mirror and not args.output:
        parser.error("使用 --mirror 时必须同时指定 --output")
    for target in targets:
        write_json(target.resolve(), document)
    stats = document["meta"]["stats"]
    print(json.dumps({
        "version": document["meta"]["version"],
        "apkSha256": document["meta"]["apk"]["sha256"],
        "units": stats["totalUnits"],
        "levelRows": stats["totalLevelRows"],
        "equipment": stats["equipmentUnits"],
        "activeSupercharges": stats["activeSuperchargeGroups"],
        "superchargeRows": stats["superchargeLevelRows"],
        "outputs": [str(target.resolve()) for target in targets],
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
