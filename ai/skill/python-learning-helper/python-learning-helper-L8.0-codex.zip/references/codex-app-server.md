# Codex App Server 适配规范

本文件只在维护 L8.0-codex 页面适配器、独立本地启动器或 App Server 客户端时读取。

## 边界

- 普通网页不能启动 `codex.exe`、读取账号文件、保存登录凭据或直接访问网络 AI 接口。
- 配套 `launch.js` 只监听 `127.0.0.1`，为每次启动生成随机会话路径，使用标准 `stdio` JSONL 连接 App Server；不要改用不受支持的实验性 WebSocket 作为默认方案。
- Windows 启动入口通过系统自带的 `wscript.exe` 与 `start.vbs` 隐藏启动本地服务。启动 CMD 必须等待状态文件出现、读取并校验其中的本机页面地址、调用默认浏览器打开该地址后才能自动退出；此后服务不得依赖 CMD 窗口存活。启动状态与错误写入运行时文件，服务长期闲置后自动退出。
- 启动器只提供当前学习页所需的账号、登录、退出、模型、额度、运行和停止接口；网页不得获得 App Server 原始连接或登录凭据，也不提供账号累计词元用量界面。上下文管理可以显示当前线程的已用词元与模型上下文窗口。
- 深度理解先从教材正文中分离图片编码：正文与全部交互式演示 HTML/CSS/JavaScript 作为文本输入，全部教材图作为多模态图片输入。页面发送前须用 UTF-8 JSON 实际序列化结果估算请求体；不超过 7MB 时保留原图，超过时把全部图片逐级压成 JPEG，压到最低仍超限时才从本次文本上下文移除带边界标记的交互演示代码，正文和全部图片必须保留。7MB 是主动上限，用于给当前提问和后续对话预留约 1MB；本地 HTTP 仍以 8MB 为硬门槛，超限时返回可读的 JSON 413 错误，不得直接断开连接并让网页只显示 `Failed to fetch`。
- App Server 的 `turn/start.input` 原生支持 `text`、`image` 与 `localImage`，没有通用文件输入类型。用户上传/粘贴的图片保存到当前学习包目录后用 `localImage.path` 发送；其它文件保存后在文本输入中提供工作区内的绝对路径，并明确要求 Codex 使用文件系统或命令行工具读取。
- 附件接口接收原始二进制，不使用 Base64 JSON；单文件最多 32MB。文件名必须去除目录与 Windows 非法字符，服务器自行生成随机前缀并落到 `.l7-codex-attachments`。任何图片读取路由都必须同时校验词法路径与真实路径位于当前学习包根目录内，只允许已知图片扩展名，防止 `..`、符号链接或接合点越界。
- 直接双击 HTML 时立即提示运行配套启动脚本，不等待悬空请求，也不回退到普通版接口。
- 工作目录默认取学习页所在目录。页面与 `.l7-codex-runtime/` 可整体移动，但必须保留相对位置。

## 能力发现

- 模型来自 `model/list`，不要写死模型名称。
- 思考档位只使用所选模型 `supportedReasoningEfforts` 中的值，默认值取 `defaultReasoningEffort`。
- 仅当 `serviceTiers` 或兼容字段 `additionalSpeedTiers` 声明 `fast` 时显示快速回答；快速模式需提示会额外消耗额度。
- 账号使用 `account/read`，绑定入口使用 `account/login/start` 的 ChatGPT 登录方式；额度只读取 `account/rateLimits/read` 并显示剩余百分比，不读取或展示累计词元统计。
- 每个页面对话使用独立的官方持久线程：首次请求调用 `thread/start`（`ephemeral: false`），后续请求调用 `thread/resume`，再由 `turn/start` 只追加最新系统状态和本轮输入。自动与手动上下文压缩都调用官方 `thread/compact/start` 并等待 `contextCompaction` 与回合完成事件；自动压缩的开始、完成和失败必须同步显示在当前 Codex 过程区。页面不再用模型生成隐藏摘要冒充压缩。编辑既有消息会废弃旧线程映射，并在下次请求用完整本地历史、当前实验台代码和本地运行记录建立新线程。
- 生成中的方向调整调用官方 `turn/steer`，请求必须携带当前 `threadId`、`expectedTurnId` 和非空 `input`；普通聊天、出题、批阅、重写、详解、演示生成、命名与思考摘要校译等所有智能调用都必须通过 App Server 的 `thread/start` / `thread/resume` / `turn/start` 路径完成。
- ChatGPT 登录地址只由 App Server 返回并在浏览器中打开；禁止读取 `auth.json`、系统凭据库或 ChatGPT 网页 Cookie。

## 权限与兼容

- 不按版本号猜权限字段。稳定协议使用 `thread/start.sandbox` 与 `turn/start.sandboxPolicy`；只有客户端在 `initialize.params.capabilities.experimentalApi` 明确选择实验接口后，才可通过 `permissionProfile/list` 发现命名配置并用 `permissions` 代替 `sandbox`。同一请求绝不能同时发送 `permissions` 与 `sandbox` / `sandboxPolicy`。
- 启动回合前读取 `configRequirements/read`；若组织策略列出 `allowedApprovalPolicies` 或 `allowedSandboxModes`，必须从返回的实际候选值中选择。没有要求时采用当前稳定协议的 `on-request` 与 `workspaceWrite`；只有服务端明确返回旧枚举时才使用旧值。
- 实验权限配置必须使用 `permissionProfile/list` 返回且 `allowed !== false` 的明确配置编号；不得凭名称猜测配置，也不得在工作区配置失败后自动扩大成 `dangerFullAccess`。组织策略不允许工作区写入时应返回可读错误，不能静默降级为残缺只读模式。
- `workspaceWrite.readOnlyAccess` 是当前 `turn/start.sandboxPolicy` 仍支持的可选读取范围字段；默认完整读取时可省略，需要受限读取时再按服务端当前结构发送。
- 审批请求以 App Server 实际下发的 `item/commandExecution/requestApproval`、`item/fileChange/requestApproval` 和 `item/permissions/requestApproval` 为准；客户端只回复服务端声明可选的决定或所请求权限的子集。自动审核属于有效配置时由 App Server 执行，不向线程/回合请求硬塞未由当前协议声明的审核字段。
- 兼容旧服务时，只在方法不存在时退回稳定字段；收到“未知枚举”后只重试错误中明确列出的候选值，不做无依据的多轮猜测。

## 对话事件

- 正文增量、思考摘要、计划、工具开始、工具完成、工具失败、运行警告、模型改路由、图片和上下文压缩事件是不同事件，页面按 Codex 桌面版同类过程分别呈现，不得混成一段普通回复；每次 `thread/tokenUsage/updated` 到达时立即把最近输入用量与 `modelContextWindow` 刷新到上下文入口和管理面板，不等待回合完成。该用量不进入消息正文，也不得据此显示价格或账号累计用量。
- `imageGeneration` 完成事件优先读取 `savedPath`，作为独立图片结果随流返回；无本地路径时只接受 `data:image/...` 或 `https://` 结果。页面把路径映射到同源只读图片路由，禁止直接开放任意本地文件。
- 工具卡显示命令、文件修改、网页搜索、扩展工具等真实工具名及运行状态；结果默认折叠，避免大段输出压过教材内容。
- 页面停止按钮必须调用当前回合的中断接口，并把已生成内容保留下来供续写或重试。
- 不注册 `tzcli` 或任何天择OS动态工具。学习助手只使用当前 Codex 配置可用的内置工具、技能与扩展。

## 回归

- 所有自动化使用假 App Server 或协议夹具，不得调用用户账号产生额度消耗。
- 至少断言：账号入口存在；模型、思考档位、快速模式来自能力发现；无旧 AI 接口、密钥、天择OS桥、温度或采样概率；稳定沙箱与显式实验权限配置两条路径互不混发；组织策略候选值生效且不会自动扩大为完全访问；回环随机会话路径生效；流式正文、思考、工具卡、停止可达；上下文自动/手动压缩可用且不删除本地原文；页面不存在词元用量和价格界面。
