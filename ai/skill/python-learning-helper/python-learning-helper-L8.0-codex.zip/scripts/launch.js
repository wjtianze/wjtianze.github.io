#!/usr/bin/env node
'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const { spawn, execFileSync } = require('node:child_process');
const { StandaloneCodexBridge, normalizeError } = require('./codex-bridge');

function parseArgs(argv) {
  const result = { file: '', codex: '', port: 0, open: true, fakeServer: '', statusFile: '' };
  for (const arg of argv) {
    if (arg === '--no-open') result.open = false;
    else if (arg.startsWith('--codex=')) result.codex = arg.slice(8);
    else if (arg.startsWith('--port=')) result.port = Number(arg.slice(7)) || 0;
    else if (arg.startsWith('--fake-server=')) result.fakeServer = arg.slice(14);
    else if (arg.startsWith('--status-file=')) result.statusFile = arg.slice(14);
    else if (!arg.startsWith('--') && !result.file) result.file = arg;
  }
  return result;
}

function isFile(file) {
  try { return !!file && fs.statSync(file).isFile(); } catch (_) { return false; }
}

function isProtectedWindowsApps(file) {
  return typeof file === 'string' && /[\\/]Program Files[\\/]WindowsApps[\\/]/i.test(file);
}

function managedDesktopCandidates(localAppData) {
  const root = localAppData && path.join(localAppData, 'OpenAI', 'Codex', 'bin');
  if (!root) return [];
  try {
    return fs.readdirSync(root, { withFileTypes: true })
      .filter(entry => entry.isDirectory() && /^[a-f0-9]{16,64}$/i.test(entry.name))
      .map(entry => path.join(root, entry.name, 'codex.exe'))
      .filter(isFile)
      .sort((left, right) => fs.statSync(right).mtimeMs - fs.statSync(left).mtimeMs);
  } catch (_) { return []; }
}

function pathCandidates() {
  if (process.platform !== 'win32') return ['codex'];
  try {
    return String(execFileSync('where.exe', ['codex'], {
      encoding: 'utf8',
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'ignore']
    }))
      .split(/\r?\n/).map(item => item.trim()).filter(Boolean);
  } catch (_) { return []; }
}

function resolveCodex(explicit) {
  const home = process.env.USERPROFILE || process.env.HOME || '';
  const candidates = [
    explicit,
    process.env.L7_CODEX_PATH,
    ...managedDesktopCandidates(process.env.LOCALAPPDATA || ''),
    home && path.join(home, '.local', 'bin', process.platform === 'win32' ? 'codex.exe' : 'codex'),
    process.env.APPDATA && path.join(process.env.APPDATA, 'npm', 'codex.cmd'),
    ...pathCandidates()
  ].filter(Boolean).filter(candidate => !isProtectedWindowsApps(candidate));
  return [...new Set(candidates)].find(candidate => candidate === 'codex' || isFile(candidate)) || '';
}

function spawnProcess(command, args, options) {
  if (process.platform === 'win32' && /\.(cmd|bat)$/i.test(command)) {
    const quote = value => '"' + String(value).replaceAll('"', '""') + '"';
    const line = [quote(command), ...args.map(quote)].join(' ');
    return spawn(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', line], options);
  }
  return spawn(command, args, options);
}

function openBrowser(url) {
  try {
    if (process.platform === 'win32') {
      const child = spawn(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', 'start "" "' + url.replaceAll('"', '') + '"'], {
        detached: true, stdio: 'ignore', windowsHide: true
      });
      child.unref();
    } else {
      const command = process.platform === 'darwin' ? 'open' : 'xdg-open';
      const child = spawn(command, [url], { detached: true, stdio: 'ignore' });
      child.unref();
    }
  } catch (_) {}
}

const MAX_JSON_BODY_BYTES = 8 * 1024 * 1024;
const MAX_ATTACHMENT_BYTES = 32 * 1024 * 1024;
const MAX_ARCHIVE_BYTES = 32 * 1024 * 1024;
const MAX_PYTHON_CODE_BYTES = 512 * 1024;
const MAX_PYTHON_OUTPUT_BYTES = 256 * 1024;
const MAX_PYTHON_INPUT_BYTES = 64 * 1024;
const MAX_PYTHON_EXERCISE_BYTES = 16 * 1024 * 1024;
const MAX_PYTHON_EXERCISE_FILES = 10;
const MAX_PYTHON_TRACE_EVENTS = 2000;
const MAX_PYTHON_TRACE_BYTES = 512 * 1024;
const DEFAULT_PYTHON_TIMEOUT_MS = 8000;
const IMAGE_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.avif', '.svg']);
const VISUAL_EXTENSIONS = new Set(['.html', '.htm', '.svg']);
const PYTHON_EXERCISE_EXTENSIONS = new Set(['.txt', '.csv', '.json', '.md', '.dat', '.py', '.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.svg']);

function requestError(message, statusCode) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

function resolvePythonCommand() {
  const explicit = process.env.L7_PYTHON_PATH || process.env.PYTHON || '';
  const candidates = explicit
    ? [{ command: explicit, args: [] }]
    : process.platform === 'win32'
      ? [{ command: 'python', args: [] }, { command: 'py', args: ['-3'] }, { command: 'python3', args: [] }]
      : [{ command: 'python3', args: [] }, { command: 'python', args: [] }];
  for (const candidate of candidates) {
    try {
      execFileSync(candidate.command, [...candidate.args, '--version'], {
        stdio: 'ignore',
        windowsHide: true
      });
      return candidate;
    } catch (_) {}
  }
  return null;
}

function appendLimited(current, chunk, limit) {
  const text = String(chunk || '');
  const currentBytes = Buffer.byteLength(current, 'utf8');
  const remaining = Math.max(0, limit - currentBytes);
  if (!remaining) return { value: current, truncated: true };
  const bytes = Buffer.from(text, 'utf8');
  if (bytes.length <= remaining) return { value: current + text, truncated: false };
  return { value: current + bytes.subarray(0, remaining).toString('utf8') + '\n…（输出过长，后续内容已截断）…', truncated: true };
}

function pythonRunId() {
  return 'py-' + Date.now().toString(36) + '-' + crypto.randomBytes(6).toString('hex');
}

function cleanPythonEnvironment(tempRoot) {
  const environment = {};
  for (const name of ['SystemRoot', 'SYSTEMROOT', 'WINDIR', 'ComSpec', 'COMSPEC', 'PATH', 'Path', 'PATHEXT']) {
    if (process.env[name]) environment[name] = process.env[name];
  }
  return Object.assign(environment, {
    PYTHONIOENCODING: 'utf-8',
    PYTHONUTF8: '1',
    PYTHONDONTWRITEBYTECODE: '1',
    PYTHONNOUSERSITE: '1',
    TEMP: tempRoot,
    TMP: tempRoot,
    TLH_PYTHON_EXERCISE_DIR: tempRoot
  });
}

function preparePythonExerciseFiles(runtime, tempRoot, payload) {
  const requested = Array.isArray(payload && payload.files) ? payload.files : [];
  if (requested.length > MAX_PYTHON_EXERCISE_FILES) throw requestError('单次最多提供 10 个教材附件', 413);
  if (!requested.length) return [];
  const workspace = fs.realpathSync(runtime.workspaceRoot);
  const allowedRoots = [
    path.join(workspace, 'assets', 'python-exercises'),
    path.join(workspace, 'assets', 'textbook-images')
  ];
  const inputRoot = path.join(tempRoot, 'inputs');
  fs.mkdirSync(inputRoot, { recursive: true });
  let total = 0;
  const copied = [];
  for (let index = 0; index < requested.length; index += 1) {
    const entry = requested[index];
    const relative = String(entry && typeof entry === 'object' ? entry.path || '' : entry || '').replaceAll('/', path.sep);
    if (!relative || path.isAbsolute(relative)) throw requestError('Python 教材附件必须使用学习包内的相对路径', 400);
    const candidate = path.resolve(workspace, relative);
    let realFile = '';
    try { realFile = fs.realpathSync(candidate); } catch (_) {}
    const allowed = allowedRoots.some(root => {
      let realRoot = '';
      try { realRoot = fs.realpathSync(root); } catch (_) { return false; }
      return isInside(realRoot, realFile);
    });
    const extension = path.extname(realFile).toLowerCase();
    if (!allowed || !isFile(realFile) || !PYTHON_EXERCISE_EXTENSIONS.has(extension)) throw requestError('Python 教材附件不存在、越界或类型不受支持：' + relative, 400);
    const stat = fs.statSync(realFile);
    total += stat.size;
    if (total > MAX_PYTHON_EXERCISE_BYTES) throw requestError('Python 教材附件合计不能超过 16MB', 413);
    const requestedName = entry && typeof entry === 'object' ? entry.name : '';
    const name = safeAttachmentName(requestedName || path.basename(realFile));
    const target = path.join(inputRoot, String(index + 1).padStart(2, '0') + '-' + name);
    fs.copyFileSync(realFile, target);
    copied.push({ name, relativePath: path.relative(tempRoot, target).replaceAll(path.sep, '/'), bytes: stat.size });
  }
  return copied;
}

function pythonTraceWrapper(scriptPath, tracePath) {
  return [
    'import json, runpy, sys',
    'TARGET = ' + JSON.stringify(scriptPath),
    'TRACE = ' + JSON.stringify(tracePath),
    'LIMIT = ' + String(MAX_PYTHON_TRACE_EVENTS),
    '_previous = {}',
    '_count = 0',
    'def _safe(value):',
    '    try:',
    '        text = repr(value)',
    '    except Exception as exc:',
    '        text = "<无法读取: %s>" % exc',
    '    return text if len(text) <= 500 else text[:500] + "…"',
    'def _trace(frame, event, arg):',
    '    global _count',
    '    if frame.f_code.co_filename != TARGET or event not in ("line", "return", "exception"):',
    '        return _trace',
    '    if _count >= LIMIT:',
    '        return None',
    '    current = {name: _safe(value) for name, value in frame.f_locals.items() if name != "__builtins__"}',
    '    key = id(frame)',
    '    before = _previous.get(key, {})',
    '    changes = {name: value for name, value in current.items() if before.get(name) != value}',
    '    removed = [name for name in before if name not in current]',
    '    _previous[key] = current',
    '    record = {"event": event, "line": frame.f_lineno, "function": frame.f_code.co_name, "changes": changes, "removed": removed}',
    '    if event == "exception":',
    '        record["exception"] = {"type": getattr(arg[0], "__name__", str(arg[0])), "message": _safe(arg[1])}',
    '    with open(TRACE, "a", encoding="utf-8") as stream:',
    '        stream.write(json.dumps(record, ensure_ascii=False) + "\\n")',
    '    _count += 1',
    '    return _trace',
    'sys.settrace(_trace)',
    'try:',
    '    runpy.run_path(TARGET, run_name="__main__")',
    'finally:',
    '    sys.settrace(None)',
    ''
  ].join('\n');
}

function readPythonTrace(tracePath) {
  if (!isFile(tracePath)) return [];
  const body = fs.readFileSync(tracePath);
  const limited = body.length > MAX_PYTHON_TRACE_BYTES ? body.subarray(0, MAX_PYTHON_TRACE_BYTES) : body;
  const rows = limited.toString('utf8').split(/\r?\n/).filter(Boolean).slice(0, MAX_PYTHON_TRACE_EVENTS);
  const out = [];
  for (const row of rows) {
    try { out.push(JSON.parse(row)); } catch (_) {}
  }
  return out;
}

function runPythonCode(runtime, payload, onEvent) {
  const code = String(payload && payload.code || '');
  const codeBytes = Buffer.byteLength(code, 'utf8');
  if (!code.trim()) throw requestError('请输入要运行的 Python 代码', 400);
  if (codeBytes > MAX_PYTHON_CODE_BYTES) throw requestError('代码超过 512KB，无法运行', 413);
  const timeoutMs = Math.max(1000, Math.min(30000, Number(payload && payload.timeoutMs) || DEFAULT_PYTHON_TIMEOUT_MS));
  const python = resolvePythonCommand();
  if (!python) throw requestError('未找到本机 Python 解释器。请安装 Python，或设置 L7_PYTHON_PATH 指向解释器。', 503);

  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'tlh-python-run-'));
  const scriptPath = path.join(tempRoot, 'main.py');
  fs.writeFileSync(scriptPath, code, 'utf8');
  const exerciseFiles = preparePythonExerciseFiles(runtime, tempRoot, payload);
  const traceEnabled = !!(payload && payload.trace);
  const tracePath = path.join(tempRoot, 'trace.jsonl');
  const traceRunnerPath = path.join(tempRoot, 'trace-runner.py');
  if (traceEnabled) fs.writeFileSync(traceRunnerPath, pythonTraceWrapper(scriptPath, tracePath), 'utf8');
  const startedAt = Date.now();
  if (!runtime.pythonRuns) runtime.pythonRuns = new Map();

  const runId = pythonRunId();
  return new Promise(resolve => {
    let child;
    let stdout = '';
    let stderr = '';
    let stdoutTruncated = false;
    let stderrTruncated = false;
    let timedOut = false;
    let outputLimitExceeded = false;
    let outputLimitStream = '';
    let settled = false;
    let timer = null;
    const emit = event => {
      if (typeof onEvent === 'function') {
        try { onEvent(Object.assign({ runId }, event)); } catch (_) {}
      }
    };
    const clean = () => {
      try { fs.rmSync(tempRoot, { recursive: true, force: true }); } catch (_) {}
      if (runtime.pythonRuns) runtime.pythonRuns.delete(runId);
    };
    const finish = (exitCode, signal, error) => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      if (error) stderr = appendLimited(stderr, '\n' + String(error.message || error), MAX_PYTHON_OUTPUT_BYTES).value;
      const status = outputLimitExceeded ? 'output-limit' : timedOut ? 'timeout' : error || exitCode !== 0 ? 'error' : 'success';
      const result = {
        runId,
        status,
        exitCode: Number.isInteger(exitCode) ? exitCode : null,
        signal: signal || '',
        stdout,
        stderr,
        stdoutTruncated,
        stderrTruncated,
        outputLimitStream,
        durationMs: Date.now() - startedAt,
        timeoutMs,
        python: python.command,
        stdinAvailable: true,
        isolated: true,
        exerciseFiles,
        traceEnabled,
        trace: traceEnabled ? readPythonTrace(tracePath) : [],
        hint: outputLimitExceeded ? '输出超过 256KB 上限，运行已终止；浏览器只接收截断后的内容。' : timedOut ? '运行超过设定时间，进程已终止。' : status === 'success' ? '代码已在本机 Python 中运行完成。' : '请查看错误输出并修改代码后重新提交。'
      };
      emit({ type: 'python-finished', result });
      clean();
      resolve(result);
    };
    try {
      child = spawnProcess(python.command, [...python.args, '-I', '-X', 'utf8', '-u', traceEnabled ? traceRunnerPath : scriptPath], {
        cwd: tempRoot,
        stdio: ['pipe', 'pipe', 'pipe'],
        env: cleanPythonEnvironment(tempRoot),
        windowsHide: true
      });
      if (child.stdout && typeof child.stdout.setEncoding === 'function') child.stdout.setEncoding('utf8');
      if (child.stderr && typeof child.stderr.setEncoding === 'function') child.stderr.setEncoding('utf8');
      runtime.pythonRuns.set(runId, {
        runId,
        child,
        input(input, eof) {
          if (settled || !child.stdin || child.stdin.destroyed) throw requestError('Python 运行已结束，不能再发送输入', 409);
          const value = String(input == null ? '' : input);
          if (Buffer.byteLength(value, 'utf8') > MAX_PYTHON_INPUT_BYTES) throw requestError('单次输入不能超过 64KB', 413);
          if (value) child.stdin.write(value + (value.endsWith('\n') ? '' : '\n'), 'utf8');
          if (eof) child.stdin.end();
          return { runId, sent: true, eof: !!eof };
        },
        stop() {
          if (settled) return { runId, stopped: false };
          try { child.kill(); } catch (_) {}
          return { runId, stopped: true };
        }
      });
      emit({ type: 'python-started', stdinAvailable: true, isolated: true, exerciseFiles, traceEnabled });
      function outputChunk(streamName, chunk, readable) {
        if (outputLimitExceeded || (streamName === 'stdout' ? stdoutTruncated : stderrTruncated)) return;
        const before = streamName === 'stdout' ? stdout : stderr;
        const next = appendLimited(before, chunk, MAX_PYTHON_OUTPUT_BYTES);
        const delta = next.value.slice(before.length);
        if (streamName === 'stdout') { stdout = next.value; stdoutTruncated = next.truncated; }
        else { stderr = next.value; stderrTruncated = next.truncated; }
        if (delta) emit({ type: 'python-output', stream: streamName, delta });
        if (next.truncated) {
          outputLimitExceeded = true;
          outputLimitStream = streamName;
          emit({ type: 'python-output-truncated', stream: streamName, limitBytes: MAX_PYTHON_OUTPUT_BYTES });
          try { if (readable && typeof readable.pause === 'function') readable.pause(); } catch (_) {}
          try { child.kill(); } catch (_) {}
        }
      }
      child.stdout.on('data', chunk => outputChunk('stdout', chunk, child.stdout));
      child.stderr.on('data', chunk => outputChunk('stderr', chunk, child.stderr));
      child.once('error', error => finish(null, '', error));
      child.once('close', (exitCode, signal) => finish(exitCode, signal, null));
      timer = setTimeout(() => {
        timedOut = true;
        try { child.kill(); } catch (_) {}
      }, timeoutMs);
    } catch (error) {
      finish(null, '', error);
    }
  });
}

function sendPythonInput(runtime, payload) {
  const runId = String(payload && payload.runId || '');
  const session = runtime.pythonRuns && runtime.pythonRuns.get(runId);
  if (!session) throw requestError('找不到正在运行的 Python 任务，可能已经结束', 404);
  return session.input(payload && payload.input, !!(payload && payload.eof));
}

function stopPythonRun(runtime, payload) {
  const runId = String(payload && payload.runId || '');
  const session = runtime.pythonRuns && runtime.pythonRuns.get(runId);
  if (!session) return { runId, stopped: false };
  return session.stop();
}

function readJson(request, limit = MAX_JSON_BODY_BYTES) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let tooLarge = false;
    const chunks = [];
    request.on('data', chunk => {
      size += chunk.length;
      if (size > limit) {
        tooLarge = true;
        chunks.length = 0;
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => {
      if (tooLarge) {
        reject(requestError('请求内容过大，请缩短教材上下文后重试', 413));
        return;
      }
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
      catch (_) { reject(requestError('请求内容不是合法 JSON', 400)); }
    });
    request.on('error', reject);
  });
}

function readBuffer(request, limit = MAX_ATTACHMENT_BYTES) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let tooLarge = false;
    const chunks = [];
    request.on('data', chunk => {
      size += chunk.length;
      if (size > limit) {
        tooLarge = true;
        chunks.length = 0;
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => {
      if (tooLarge) {
        reject(requestError('单个附件不能超过 32MB', 413));
        return;
      }
      resolve(Buffer.concat(chunks));
    });
    request.on('error', reject);
  });
}

function sendJson(response, status, value) {
  const body = Buffer.from(JSON.stringify(value), 'utf8');
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  response.end(body);
}

function contentType(file) {
  const extension = path.extname(file).toLowerCase();
  if (extension === '.js') return 'text/javascript; charset=utf-8';
  if (extension === '.css') return 'text/css; charset=utf-8';
  if (extension === '.woff2') return 'font/woff2';
  if (extension === '.woff') return 'font/woff';
  if (extension === '.ttf') return 'font/ttf';
  if (extension === '.png') return 'image/png';
  if (extension === '.jpg' || extension === '.jpeg') return 'image/jpeg';
  if (extension === '.gif') return 'image/gif';
  if (extension === '.webp') return 'image/webp';
  if (extension === '.bmp') return 'image/bmp';
  if (extension === '.avif') return 'image/avif';
  if (extension === '.svg') return 'image/svg+xml';
  return 'application/octet-stream';
}

function decodeUrlPath(value) {
  try { return decodeURIComponent(String(value || '')); }
  catch (_) { return null; }
}

function passiveImageHeaders(file) {
  if (path.extname(file).toLowerCase() !== '.svg') return {};
  return {
    'Content-Security-Policy': "sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src data: blob:; object-src 'none'; form-action 'none'; frame-ancestors 'none'"
  };
}

function visualDocument(file) {
  const extension = path.extname(file).toLowerCase();
  const kind = extension === '.svg' ? 'svg' : 'html';
  const source = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
  const style = '<style data-l7-file-visual>html,body{margin:0!important;padding:0!important;overflow:hidden!important;background:#fff}body{transform-origin:top left}svg,img,video,canvas{max-width:100%;height:auto}</style>';
  const script = '<script data-l7-file-visual>(function(){var kind=' + JSON.stringify(kind) + ',locked=null,queued=false;function root(){if(kind==="svg")return document.querySelector("svg");return document.querySelector("[data-l7-visual-root],main,.app,[role=application]")||document.body}function number(value){var match=String(value||"").match(/^\\s*(\\d+(?:\\.\\d+)?)(?:px)?\\s*$/i);return match?Number(match[1]):0}function size(){if(locked)return locked;var target=root();if(!target)return{width:320,height:180,ready:false};var width=0,height=0;if(kind==="svg"){var box=target.viewBox&&target.viewBox.baseVal;width=number(target.getAttribute("width"))||(box&&box.width)||target.scrollWidth||target.clientWidth;height=number(target.getAttribute("height"))||(box&&box.height)||target.scrollHeight||target.clientHeight||Math.max(1,width*.5625)}else{var rect=target.getBoundingClientRect();width=Math.max(target.scrollWidth,target.offsetWidth,rect.width,document.body.scrollWidth,document.documentElement.scrollWidth);height=Math.max(target.scrollHeight,target.offsetHeight,rect.height,document.body.scrollHeight,document.documentElement.scrollHeight)}if(width<32||height<24)return{width:Math.max(320,width),height:Math.max(180,height),ready:false};locked={width:Math.ceil(width),height:Math.ceil(height),ready:true};return locked}function report(){if(queued)return;queued=true;requestAnimationFrame(function(){queued=false;var value=size();parent.postMessage({type:"l7-ai-visual-size",naturalWidth:value.width,naturalHeight:value.height,kind:kind,ready:value.ready},"*")})}addEventListener("message",function(event){var data=event&&event.data;if(!data)return;if(data.type==="l7-ai-visual-request-size"){report();return}if(data.type!=="l7-ai-visual-fit")return;var target=root(),scale=Math.max(.01,Math.min(1,Number(data.scale)||1));if(!target)return;target.style.transformOrigin="top left";target.style.transform=scale<.999?"scale("+scale+")":"none";document.documentElement.style.width=Math.ceil((Number(data.naturalWidth)||320)*scale)+"px";document.documentElement.style.height=Math.ceil((Number(data.naturalHeight)||180)*scale)+"px"});if(typeof ResizeObserver==="function")new ResizeObserver(report).observe(document.documentElement);addEventListener("load",report,{once:true});requestAnimationFrame(function(){setTimeout(report,80)});setTimeout(report,300)})();</script>';
  if (kind === 'svg') return Buffer.from('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' + style + '</head><body>' + source + script + '</body></html>', 'utf8');
  let html = source;
  if (!/<html[\s>]/i.test(html)) html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body>' + html + '</body></html>';
  if (/<\/head\s*>/i.test(html)) html = html.replace(/<\/head\s*>/i, style + '</head>');
  else html = style + html;
  if (/<\/body\s*>/i.test(html)) html = html.replace(/<\/body\s*>/i, script + '</body>');
  else html += script;
  return Buffer.from(html, 'utf8');
}

function isInside(root, candidate) {
  const base = path.resolve(root);
  const target = path.resolve(candidate);
  return target === base || target.startsWith(base + path.sep);
}

function safeAttachmentName(value) {
  const original = path.basename(String(value || '附件'));
  const cleaned = original.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/[. ]+$/g, '').slice(0, 100);
  return cleaned || '附件';
}

function isImageBuffer(extension, body) {
  if (!Buffer.isBuffer(body) || body.length < 8) return false;
  if (extension === '.png') return body.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  if (extension === '.jpg' || extension === '.jpeg') return body[0] === 0xff && body[1] === 0xd8 && body[body.length - 2] === 0xff && body[body.length - 1] === 0xd9;
  if (extension === '.gif') return body.subarray(0, 6).toString('ascii') === 'GIF87a' || body.subarray(0, 6).toString('ascii') === 'GIF89a';
  if (extension === '.webp') return body.subarray(0, 4).toString('ascii') === 'RIFF' && body.subarray(8, 12).toString('ascii') === 'WEBP';
  if (extension === '.bmp') return body.subarray(0, 2).toString('ascii') === 'BM';
  if (extension === '.avif') return body.subarray(4, 12).toString('ascii').includes('ftyp');
  return false;
}

function createRuntime(options) {
  const htmlPath = path.resolve(options.file);
  if (!isFile(htmlPath)) throw new Error('找不到学习页：' + htmlPath);
  if (path.extname(htmlPath).toLowerCase() !== '.html') throw new Error('学习页必须是 HTML 文件');
  const fake = options.fakeServer && path.resolve(options.fakeServer);
  if (fake && !isFile(fake)) throw new Error('找不到假 App Server：' + fake);
  const fakeNode = options.fakeNode ? path.resolve(options.fakeNode) : '';
  if (fakeNode && !isFile(fakeNode)) throw new Error('找不到假 App Server 的 Node 运行时：' + fakeNode);
  const codex = fake ? (fakeNode || process.execPath) : resolveCodex(options.codex);
  if (!codex) throw new Error('未找到可用的 Codex 命令行。请安装或登录 Codex，或使用 --codex=完整路径。');
  const bridge = new StandaloneCodexBridge({
    spawn: spawnProcess,
    command: codex,
    args: fake ? [fake] : ['app-server'],
    cwd: path.dirname(htmlPath),
    env: fake ? { L7_CODEX_FAKE_SERVER: '1' } : {}
  });
  const workspaceRoot = path.dirname(htmlPath);
  const attachmentRoot = path.join(workspaceRoot, '.l7-codex-attachments');
  const archiveRoot = path.join(workspaceRoot, '.l7-codex-data');
  const archiveBaseName = path.basename(htmlPath, path.extname(htmlPath)).replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').slice(0, 120) || 'learning-page';
  const archiveFile = path.join(archiveRoot, archiveBaseName + '.json');
  return { htmlPath, codex, bridge, workspaceRoot, attachmentRoot, archiveRoot, archiveFile, pythonRuns: new Map() };
}

function readArchive(runtime) {
  if (!isFile(runtime.archiveFile)) return null;
  const realWorkspaceRoot = fs.realpathSync(runtime.workspaceRoot);
  const realArchiveFile = fs.realpathSync(runtime.archiveFile);
  if (!isInside(realWorkspaceRoot, realArchiveFile)) throw requestError('存档文件位置不安全', 400);
  const stat = fs.statSync(realArchiveFile);
  if (stat.size > MAX_ARCHIVE_BYTES) throw requestError('存档文件超过 32MB，无法读取', 413);
  let envelope;
  try { envelope = JSON.parse(fs.readFileSync(realArchiveFile, 'utf8')); }
  catch (_) { throw requestError('存档文件已损坏，无法读取', 500); }
  return envelope && envelope.state && typeof envelope.state === 'object' ? envelope.state : null;
}

function writeArchive(runtime, state) {
  if (!state || typeof state !== 'object' || Array.isArray(state)) throw requestError('存档内容无效', 400);
  const savedAt = new Date().toISOString();
  const envelope = { format: 'l7-codex-state', version: 1, page: path.basename(runtime.htmlPath), savedAt, state };
  const body = Buffer.from(JSON.stringify(envelope), 'utf8');
  if (body.length > MAX_ARCHIVE_BYTES) throw requestError('存档内容超过 32MB，无法保存', 413);
  fs.mkdirSync(runtime.archiveRoot, { recursive: true });
  const realWorkspaceRoot = fs.realpathSync(runtime.workspaceRoot);
  const realArchiveRoot = fs.realpathSync(runtime.archiveRoot);
  if (!isInside(realWorkspaceRoot, realArchiveRoot)) throw requestError('存档目录不安全', 400);
  const target = path.join(realArchiveRoot, path.basename(runtime.archiveFile));
  const temporary = target + '.' + process.pid + '.' + crypto.randomBytes(6).toString('hex') + '.tmp';
  if (!isInside(realArchiveRoot, target) || !isInside(realArchiveRoot, temporary)) throw requestError('存档文件位置不安全', 400);
  try {
    fs.writeFileSync(temporary, body);
    fs.renameSync(temporary, target);
  } finally {
    try { if (isFile(temporary)) fs.unlinkSync(temporary); } catch (_) {}
  }
  return { saved: true, savedAt, bytes: body.length, fileName: path.relative(runtime.workspaceRoot, target) };
}

function clearArchive(runtime) {
  if (isFile(runtime.archiveFile)) {
    const realWorkspaceRoot = fs.realpathSync(runtime.workspaceRoot);
    const realArchiveFile = fs.realpathSync(runtime.archiveFile);
    if (!isInside(realWorkspaceRoot, realArchiveFile)) throw requestError('存档文件位置不安全', 400);
    fs.unlinkSync(realArchiveFile);
  }
  return { cleared: true, fileName: path.relative(runtime.workspaceRoot, runtime.archiveFile) };
}

async function startRuntime(options) {
  const runtime = createRuntime(options);
  const secret = crypto.randomBytes(24).toString('hex');
  const prefix = '/' + secret;
  let lastActivity = Date.now();
  runtime.bridge.on('stderr', text => { if (process.env.L7_CODEX_DEBUG === '1') process.stderr.write(text); });
  await runtime.bridge.ensureClient();

  const server = http.createServer(async (request, response) => {
    lastActivity = Date.now();
    const host = String(request.headers.host || '');
    if (!/^(127\.0\.0\.1|localhost)(:\d+)?$/i.test(host)) { sendJson(response, 403, { error: { message: '拒绝非本机请求' } }); return; }
    const url = new URL(request.url || '/', 'http://' + host);
    response.setHeader('Referrer-Policy', 'no-referrer');
    response.setHeader('X-Frame-Options', 'DENY');
    // L8.0 图片兼容路由：页面图片位于学习包 assets/textbook-images，不能和运行时 vendor 混用。
    if (request.method === 'GET' && url.pathname.startsWith(prefix + '/assets/textbook-images/')) {
      const root = path.resolve(path.dirname(runtime.htmlPath), 'assets', 'textbook-images');
      const decoded = decodeUrlPath(url.pathname.slice((prefix + '/assets/textbook-images/').length));
      if (decoded === null) { sendJson(response, 400, { error: { message: '教材图片路径编码无效' } }); return; }
      const relative = decoded.replaceAll('/', path.sep);
      const file = path.resolve(root, relative);
      let realRoot = '', realFile = '';
      try { realRoot = fs.realpathSync(root); realFile = fs.realpathSync(file); } catch (_) {}
      if (!relative || !isInside(root, file) || !realRoot || !realFile || !isInside(realRoot, realFile) || !isFile(realFile) || !IMAGE_EXTENSIONS.has(path.extname(realFile).toLowerCase())) {
        sendJson(response, 404, { error: { message: '教材图片不存在或路径不安全' } }); return;
      }
      const body = fs.readFileSync(realFile);
      response.writeHead(200, { 'Content-Type': contentType(realFile), 'Content-Length': body.length, 'Content-Disposition': 'inline', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...passiveImageHeaders(realFile) });
      response.end(body);
      return;
    }
    if (request.method === 'GET' && url.pathname.startsWith(prefix + '/assets/')) {
      const root = path.resolve(path.dirname(runtime.htmlPath), '.l7-codex-runtime', 'vendor');
      const decoded = decodeUrlPath(url.pathname.slice((prefix + '/assets/').length));
      if (decoded === null) { sendJson(response, 400, { error: { message: '资源路径编码无效' } }); return; }
      const relative = decoded.replaceAll('/', path.sep);
      const file = path.resolve(root, relative);
      if (file !== root && !file.startsWith(root + path.sep) || !isFile(file)) { sendJson(response, 404, { error: { message: '资源不存在' } }); return; }
      const body = fs.readFileSync(file);
      response.writeHead(200, { 'Content-Type': contentType(file), 'Content-Length': body.length, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Access-Control-Allow-Origin': '*', 'Cross-Origin-Resource-Policy': 'cross-origin' });
      response.end(body);
      return;
    }
    if (request.method === 'GET' && url.pathname === prefix + '/page') {
      const config = '<script>window.__L7_CODEX_BRIDGE__=Object.freeze({base:' + JSON.stringify(prefix + '/api') + '});</script>';
      const source = fs.readFileSync(runtime.htmlPath, 'utf8');
      const localized = source.replaceAll('.l7-codex-runtime/vendor/', prefix + '/assets/');
      const html = localized.includes('<head>') ? localized.replace('<head>', '<head>\n' + config) : config + localized;
      const body = Buffer.from(html, 'utf8');
      response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': body.length, 'Cache-Control': 'no-store' });
      response.end(body);
      return;
    }
    if (!url.pathname.startsWith(prefix + '/api/')) { sendJson(response, 404, { error: { message: '页面不存在' } }); return; }
    const operation = url.pathname.slice((prefix + '/api/').length);
    try {
      if (request.method === 'GET' && operation === 'archive') {
        sendJson(response, 200, { result: { state: readArchive(runtime), fileName: path.relative(runtime.workspaceRoot, runtime.archiveFile) } });
        return;
      }
      if (request.method === 'DELETE' && operation === 'archive') {
        sendJson(response, 200, { result: clearArchive(runtime) });
        return;
      }
      if (request.method === 'GET' && operation === 'media') {
        const requested = String(url.searchParams.get('path') || '');
        const file = path.resolve(runtime.workspaceRoot, requested);
        const realRoot = fs.realpathSync(runtime.workspaceRoot);
        let realFile = '';
        try { realFile = fs.realpathSync(file); } catch (_) {}
        if (!requested || !isInside(runtime.workspaceRoot, file) || !realFile || !isInside(realRoot, realFile) || !isFile(realFile) || !IMAGE_EXTENSIONS.has(path.extname(realFile).toLowerCase())) {
          throw requestError('图片不存在或不在当前学习包目录内', 404);
        }
        const body = fs.readFileSync(realFile);
        response.writeHead(200, {
          'Content-Type': contentType(realFile),
          'Content-Length': body.length,
          'Content-Disposition': 'inline',
          'Cache-Control': 'no-store',
          'X-Content-Type-Options': 'nosniff',
          ...passiveImageHeaders(realFile)
        });
        response.end(body);
        return;
      }
      if (request.method === 'GET' && operation === 'visual') {
        const requested = String(url.searchParams.get('path') || '');
        const file = path.resolve(runtime.workspaceRoot, requested);
        const realRoot = fs.realpathSync(runtime.workspaceRoot);
        let realFile = '';
        try { realFile = fs.realpathSync(file); } catch (_) {}
        if (!requested || !isInside(runtime.workspaceRoot, file) || !realFile || !isInside(realRoot, realFile) || !isFile(realFile) || !VISUAL_EXTENSIONS.has(path.extname(realFile).toLowerCase())) {
          throw requestError('可视化文件不存在或不在当前学习包目录内', 404);
        }
        const body = visualDocument(realFile);
        response.setHeader('X-Frame-Options', 'SAMEORIGIN');
        response.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Content-Length': body.length,
          'Content-Disposition': 'inline',
          'Content-Security-Policy': "default-src 'none'; img-src data: blob:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; font-src data:; media-src data: blob:; frame-ancestors 'self'",
          'Cache-Control': 'no-store',
          'X-Content-Type-Options': 'nosniff'
        });
        response.end(body);
        return;
      }
      if (request.method !== 'POST') throw requestError('只允许 POST 请求', 405);
      if (operation === 'archive') {
        const archivePayload = await readJson(request, MAX_ARCHIVE_BYTES);
        sendJson(response, 200, { result: writeArchive(runtime, archivePayload.state) });
        return;
      }
      if (operation === 'attachments') {
        const body = await readBuffer(request);
        if (!body.length) throw requestError('附件内容为空', 400);
        const name = safeAttachmentName(url.searchParams.get('name'));
        const extension = path.extname(name).toLowerCase();
        const id = Date.now().toString(36) + '-' + crypto.randomBytes(8).toString('hex') + '-' + name;
        fs.mkdirSync(runtime.attachmentRoot, { recursive: true });
        const realWorkspaceRoot = fs.realpathSync(runtime.workspaceRoot);
        const realAttachmentRoot = fs.realpathSync(runtime.attachmentRoot);
        if (!isInside(realWorkspaceRoot, realAttachmentRoot)) throw requestError('附件目录不安全', 400);
        const file = path.join(realAttachmentRoot, id);
        if (!isInside(realAttachmentRoot, file)) throw requestError('附件名称无效', 400);
        fs.writeFileSync(file, body);
        sendJson(response, 200, { result: {
          id,
          name,
          path: file,
          size: body.length,
          mime: String(request.headers['content-type'] || 'application/octet-stream').split(';')[0],
          isImage: IMAGE_EXTENSIONS.has(extension) && isImageBuffer(extension, body)
        } });
        return;
      }
      const payload = await readJson(request);
      if (operation === 'run') {
        response.writeHead(200, {
          'Content-Type': 'application/x-ndjson; charset=utf-8',
          'Cache-Control': 'no-store',
          'X-Content-Type-Options': 'nosniff',
          'Transfer-Encoding': 'chunked'
        });
        const write = value => { if (!response.destroyed && !response.writableEnded) response.write(JSON.stringify(value) + '\n'); };
        try {
          const result = await runtime.bridge.run(payload, event => write({ kind: 'event', event }));
          write({ kind: 'result', result });
        } catch (error) {
          write({ kind: 'error', error: normalizeError(error) });
        }
        if (!response.writableEnded) response.end();
        return;
      }
      if (operation === 'compact') {
        const write = value => { if (!response.destroyed && !response.writableEnded) response.write(JSON.stringify(value) + '\n'); };
        response.writeHead(200, { 'Content-Type': 'application/x-ndjson; charset=utf-8', 'Cache-Control': 'no-store' });
        try {
          const result = await runtime.bridge.compact(payload, event => write({ kind: 'event', event }));
          write({ kind: 'result', result });
        } catch (error) {
          write({ kind: 'error', error: normalizeError(error) });
        }
        response.end();
        return;
      }
      let result;
      if (operation === 'python-run') {
        response.writeHead(200, {
          'Content-Type': 'application/x-ndjson; charset=utf-8',
          'Cache-Control': 'no-store',
          'X-Content-Type-Options': 'nosniff',
          'Transfer-Encoding': 'chunked'
        });
        const write = value => { if (!response.destroyed && !response.writableEnded) response.write(JSON.stringify(value) + '\n'); };
        try {
          result = await runPythonCode(runtime, payload, event => write({ kind: 'event', event }));
          write({ kind: 'result', result });
        } catch (error) {
          write({ kind: 'error', error: normalizeError(error) });
        }
        if (!response.writableEnded) response.end();
        return;
      }
      if (operation === 'python-input') result = sendPythonInput(runtime, payload);
      else if (operation === 'python-stop') result = stopPythonRun(runtime, payload);
      else if (operation === 'account') result = await runtime.bridge.readAccount();
      else if (operation === 'login') result = await runtime.bridge.login();
      else if (operation === 'logout') result = await runtime.bridge.logout();
      else if (operation === 'models') result = await runtime.bridge.listModels();
      else if (operation === 'rateLimits') result = await runtime.bridge.rateLimits();
      else if (operation === 'usage') result = await runtime.bridge.usage();
      else if (operation === 'interrupt') result = await runtime.bridge.interrupt(payload.runId);
      else if (operation === 'steer') result = await runtime.bridge.steer(payload.runId, payload.text);
      else if (operation === 'settings') result = { model: '', effort: 'medium', speed: 'standard', workspaceRoot: path.dirname(runtime.htmlPath) };
      else if (operation === 'shutdown') {
        sendJson(response, 200, { result: { stopped: true } });
        setImmediate(close);
        return;
      }
      else throw new Error('不支持的操作：' + operation);
      sendJson(response, 200, { result });
    } catch (error) {
      sendJson(response, Number(error && error.statusCode) || 500, { error: normalizeError(error) });
    }
  });

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(options.port || 0, '127.0.0.1', resolve);
  });
  const address = server.address();
  const pageUrl = 'http://127.0.0.1:' + address.port + prefix + '/page';
  const close = () => {
    if (runtime.pythonRuns) {
      for (const session of runtime.pythonRuns.values()) {
        try { session.stop(); } catch (_) {}
      }
      runtime.pythonRuns.clear();
    }
    server.close();
    runtime.bridge.stop();
    if (options.statusFile) {
      try { fs.unlinkSync(path.resolve(options.statusFile)); } catch (_) {}
    }
  };
  process.once('SIGINT', close);
  process.once('SIGTERM', close);
  const idle = setInterval(() => {
    if (Date.now() - lastActivity > 4 * 60 * 60 * 1000 && runtime.bridge.runs.size === 0 && runtime.pythonRuns.size === 0) {
      clearInterval(idle);
      close();
    }
  }, 60000);
  if (typeof idle.unref === 'function') idle.unref();
  process.stdout.write('L7_CODEX_READY ' + pageUrl + '\n');
  if (options.statusFile) {
    const statusPath = path.resolve(options.statusFile);
    fs.mkdirSync(path.dirname(statusPath), { recursive: true });
    fs.writeFileSync(statusPath, JSON.stringify({ pid: process.pid, pageUrl, startedAt: new Date().toISOString() }), 'utf8');
  }
  if (options.open) openBrowser(pageUrl);
  return { ...runtime, server, pageUrl, close };
}

async function main(options = parseArgs(process.argv.slice(2))) {
  if (!options.file) throw new Error('用法：node launch.js <L8.0-codex_学习页.html> [--codex=路径] [--no-open]');
  await startRuntime(options);
}

if (require.main === module) {
  const options = parseArgs(process.argv.slice(2));
  main(options).catch(error => {
    if (options.statusFile) {
      try { fs.writeFileSync(path.resolve(options.statusFile) + '.error.log', String(error && error.stack || error), 'utf8'); } catch (_) {}
    }
    process.stderr.write('启动失败：' + String(error && error.message || error) + '\n');
    process.exitCode = 1;
  });
}

module.exports = { MAX_JSON_BODY_BYTES, MAX_ATTACHMENT_BYTES, MAX_ARCHIVE_BYTES, MAX_PYTHON_CODE_BYTES, MAX_PYTHON_OUTPUT_BYTES, MAX_PYTHON_INPUT_BYTES, MAX_PYTHON_EXERCISE_BYTES, MAX_PYTHON_EXERCISE_FILES, MAX_PYTHON_TRACE_EVENTS, parseArgs, resolveCodex, resolvePythonCommand, cleanPythonEnvironment, preparePythonExerciseFiles, runPythonCode, sendPythonInput, stopPythonRun, createRuntime, startRuntime, readJson, readBuffer, isInside, safeAttachmentName, isImageBuffer, decodeUrlPath, passiveImageHeaders, readArchive, writeArchive, clearArchive };
