#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
L8.0-codex 注入脚本（独立 Codex App Server 版，无 API Key 参数）。

把 AI 分开写好的源文件整合后注入 template.html，产出最终学习页。

用法：
    python scripts/inject.py <input_dir> <output.html> [template.html]

输入目录结构（沿用分文件生成与演示强制规范）：
    input_dir/
      meta.json          # 单章节含 book/chapter/summary；多章节含 chapters 数组
      chapters/*.md      # 多章节时每章一个 Markdown 文件；单章节兼容 fulltext.md
      kp.json            # [{"cat": "...", "items": [{"name": "...", "desc": "..."}]}, ...]  （不含 demo 字段）
      questions.json     # [{"type": "single", "text": "...", ...}, ...]
      demos/
        0_0.html         # kpData[0].items[0] 的交互式演示（完整 HTML 文档）
        0_1.html         # kpData[0].items[1] 的交互式演示
        1_0.html         # kpData[1].items[0] 的交互式演示
        ...              # 每个知识点都必须有对应的演示文件（L6.3 强制要求）

脚本流程：
  ① 读取并校验所有源文件（meta / fulltext / kp / questions / demos）；
  ② 【强制演示校验】每个知识点 kpData[ci].items[ii] 必须有对应的 demos/{ci}_{ii}.html，
     缺任何一个都报错退出（L6.3 演示不再是可选）；
  ③ 自动把 demo HTML 中的 </script> 转义为 <\\/script>（JSON 字符串层面），
     这样 AI 写演示时可以用正常的 </script>，无需手动转义；
  ④ 组装成完整 data 对象 {book, chapter, summary, fulltext, chapters, kpData, questions}；
  ⑤ 把完整学习数据编码为 Base64，再写入 learning-data，避免教材原文或演示中的任何 HTML 标签触发外层脚本解析；
  ⑥ 把模板中 id="learning-data" 的 <script> 块整体替换为真实数据；
  ⑦ 写出学习页；
  ⑧ 复制独立本地运行时，并生成配套 Windows 启动脚本。

校验失败会非零退出并打印原因——据此回到对应源文件修数据即可。
"""
import sys, os, json, re, shutil, base64, urllib.parse, ast, operator

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from learning_model import LearningModelError, upgrade_and_validate

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".avif", ".svg"}
PYTHON_EXERCISE_EXTENSIONS = {".txt", ".csv", ".json", ".md", ".dat", ".py", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg"}
MAX_PYTHON_EXERCISE_BYTES = 16 * 1024 * 1024
QUESTION_TYPES = {"single", "multiple", "indeterminate", "judge", "code"}
_UNKNOWN = object()
_BINARY_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_UNARY_OPERATORS = {ast.UAdd: operator.pos, ast.USub: operator.neg}

def die(msg):
    print("注入失败：" + msg, file=sys.stderr)
    sys.exit(1)

def read_text(path):
    if not os.path.isfile(path):
        die("缺少文件：%s" % path)
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def read_json(path):
    raw = read_text(path)
    try:
        return json.loads(raw)
    except Exception as e:
        die("%s 不是合法 JSON（检查引号/逗号/括号配对）：%s" % (path, e))

def required_text(value, label):
    text = str(value or "").strip()
    if not text:
        die(label + " 不能为空")
    return text

def _safe_expression(node, values):
    if isinstance(node, ast.Constant) and isinstance(node.value, (str, int, float, bool, type(None))):
        return node.value
    if isinstance(node, ast.Name):
        return values.get(node.id, _UNKNOWN)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPERATORS:
        operand = _safe_expression(node.operand, values)
        if operand is _UNKNOWN:
            return _UNKNOWN
        try:
            return _UNARY_OPERATORS[type(node.op)](operand)
        except Exception:
            return _UNKNOWN
    if isinstance(node, ast.BinOp) and type(node.op) in _BINARY_OPERATORS:
        left = _safe_expression(node.left, values)
        right = _safe_expression(node.right, values)
        if left is _UNKNOWN or right is _UNKNOWN:
            return _UNKNOWN
        try:
            result = _BINARY_OPERATORS[type(node.op)](left, right)
            return result if len(str(result)) <= 10000 else _UNKNOWN
        except Exception:
            return _UNKNOWN
    if isinstance(node, ast.JoinedStr):
        parts = []
        for item in node.values:
            if isinstance(item, ast.Constant) and isinstance(item.value, str):
                parts.append(item.value)
                continue
            if not isinstance(item, ast.FormattedValue):
                return _UNKNOWN
            value = _safe_expression(item.value, values)
            if value is _UNKNOWN:
                return _UNKNOWN
            if item.conversion == 114:
                value = repr(value)
            elif item.conversion == 115:
                value = str(value)
            elif item.conversion == 97:
                value = ascii(value)
            spec = ""
            if item.format_spec is not None:
                spec = _safe_expression(item.format_spec, values)
                if spec is _UNKNOWN or not isinstance(spec, str):
                    return _UNKNOWN
            try:
                parts.append(format(value, spec))
            except Exception:
                return _UNKNOWN
        return "".join(parts)
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in {"round", "str", "int", "float"}:
        args = [_safe_expression(arg, values) for arg in node.args]
        if any(value is _UNKNOWN for value in args):
            return _UNKNOWN
        try:
            return {"round": round, "str": str, "int": int, "float": float}[node.func.id](*args)
        except Exception:
            return _UNKNOWN
    return _UNKNOWN

def _simulated_starter_output(code):
    try:
        tree = ast.parse(str(code or ""))
    except Exception:
        return None
    values, stream = {}, ""
    for statement in tree.body:
        if isinstance(statement, (ast.Assign, ast.AnnAssign)):
            expression = statement.value
            value = _safe_expression(expression, values)
            targets = statement.targets if isinstance(statement, ast.Assign) else [statement.target]
            for target in targets:
                if isinstance(target, ast.Name):
                    if value is _UNKNOWN:
                        values.pop(target.id, None)
                    else:
                        values[target.id] = value
            continue
        if isinstance(statement, ast.AugAssign) and isinstance(statement.target, ast.Name):
            left = values.get(statement.target.id, _UNKNOWN)
            right = _safe_expression(statement.value, values)
            operation = _BINARY_OPERATORS.get(type(statement.op))
            if left is _UNKNOWN or right is _UNKNOWN or operation is None:
                values.pop(statement.target.id, None)
            else:
                try:
                    values[statement.target.id] = operation(left, right)
                except Exception:
                    values.pop(statement.target.id, None)
            continue
        if not isinstance(statement, ast.Expr) or not isinstance(statement.value, ast.Call):
            continue
        call = statement.value
        if not isinstance(call.func, ast.Name) or call.func.id != "print":
            continue
        args = [_safe_expression(arg, values) for arg in call.args]
        if any(value is _UNKNOWN for value in args):
            continue
        separator, ending = " ", "\n"
        for keyword in call.keywords:
            value = _safe_expression(keyword.value, values)
            if value is _UNKNOWN:
                continue
            if keyword.arg == "sep":
                separator = str(value)
            elif keyword.arg == "end":
                ending = str(value)
        stream += separator.join(str(value) for value in args) + ending
    if not stream:
        return []
    lines = stream.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return lines

def _normalize_output_line(value):
    text = re.sub(r"[ \t\u00a0\u3000]+", "", str(value or "").replace("\r", ""))
    return text.translate(str.maketrans({
        "，": ",", "、": ",", "；": ";", "：": ":", "！": "!", "？": "?", "。": ".",
        "（": "(", "）": ")", "【": "[", "】": "]", "［": "[", "］": "]",
        "｛": "{", "｝": "}", "“": '"', "”": '"', "‘": "'", "’": "'", "／": "/", "＼": "\\",
    }))

def starter_reaches_target(starter_code, target_output):
    if not str(starter_code or "").strip():
        return False
    actual = _simulated_starter_output(starter_code)
    if actual is None or len(actual) != len(target_output):
        return False
    return all(_normalize_output_line(actual[index]) == _normalize_output_line(target_output[index])
               for index in range(len(target_output)))

def validate_questions(questions):
    if not 6 <= len(questions) <= 12:
        die("questions.json 必须包含 6–12 道题，当前为 %d 道" % len(questions))
    single_answers, combined_answers = [], []
    for index, question in enumerate(questions):
        label = "questions.json 第 %d 题" % (index + 1)
        if not isinstance(question, dict):
            die(label + "必须是对象")
        qtype = str(question.get("type") or "").strip()
        if qtype not in QUESTION_TYPES:
            die(label + "的 type 必须是 single/multiple/indeterminate/judge/code 之一；Python 版禁止填空题和解答题")
        required_text(question.get("text"), label + "的题干 text")
        required_text(question.get("kp"), label + "的知识点 kp")
        required_text(question.get("difficulty"), label + "的难度 difficulty")
        if qtype == "code":
            required_text(question.get("goal"), label + "的目标 goal")
            target = question.get("targetOutput")
            if not isinstance(target, list) or not target or any(not isinstance(line, str) for line in target):
                die(label + "的 targetOutput 必须是非空字符串行数组")
            test_cases = question.get("testCases")
            if not isinstance(test_cases, list) or len(test_cases) < 2:
                die(label + "的 testCases 必须至少包含 2 组检验；每组都要覆盖题目要求的不同输入或边界")
            for case_index, case in enumerate(test_cases):
                case_label = "%s 的第 %d 组检验" % (label, case_index + 1)
                if not isinstance(case, dict):
                    die(case_label + "必须是对象")
                required_text(case.get("name"), case_label + "的 name")
                overrides = case.get("overrides", {})
                if not isinstance(overrides, dict):
                    die(case_label + "的 overrides 必须是对象")
                for override_name in overrides:
                    if not isinstance(override_name, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", override_name):
                        die(case_label + "的 overrides 只能覆盖合法 Python 变量名")
                case_target = case.get("targetOutput")
                if not isinstance(case_target, list) or not case_target or any(not isinstance(line, str) for line in case_target):
                    die(case_label + "的 targetOutput 必须是非空字符串行数组")
            if "answer" in question or any(field in question for field in ("standardAnswer", "referenceCode", "solutionCode")):
                die(label + "为代码题，不得包含 answer、标准答案或参考代码字段")
            mode = question.get("mode")
            if mode is not None and mode not in {"write", "complete", "debug"}:
                die(label + "的 mode 只能是 write/complete/debug")
            if question.get("starterCode") is not None and not isinstance(question.get("starterCode"), str):
                die(label + "的 starterCode 必须是字符串")
            if starter_reaches_target(question.get("starterCode"), target):
                die(label + "的 starterCode 已经可以直接得到目标输出；初始代码只能提供变量、待补全部分或错误代码，不能包含完整答案")
            if question.get("forbidDirectOutput") is not None and not isinstance(question.get("forbidDirectOutput"), bool):
                die(label + "的 forbidDirectOutput 必须是 true 或 false")
            required_names = question.get("requiredNames")
            if required_names is not None and (not isinstance(required_names, list) or any(not isinstance(name, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name.strip()) for name in required_names)):
                die(label + "的 requiredNames 必须是合法 Python 变量名数组")
            required_operators = question.get("requiredOperators")
            if required_operators is not None and (not isinstance(required_operators, list) or any(operator_name not in {"+", "-", "*", "/", "//", "%", "**"} for operator_name in required_operators)):
                die(label + "的 requiredOperators 只能包含 +、-、*、/、//、%、**")
            continue
        required_text(question.get("explanation"), label + "的解析 explanation")
        if qtype in {"single", "multiple", "indeterminate"}:
            options = question.get("options")
            if not isinstance(options, dict) or len(options) < 2:
                die(label + "的 options 必须是至少含两个选项的对象")
            keys = list(options.keys())
            if any(not isinstance(key, str) or not re.fullmatch(r"[A-Z]", key) for key in keys):
                die(label + "的选项键必须是大写字母 A/B/C/D…")
            if keys != sorted(keys) or keys != [chr(65 + offset) for offset in range(len(keys))]:
                die(label + "的选项键必须从 A 起连续并按字母顺序排列")
            for key, value in options.items():
                required_text(value, label + "的选项 " + key)
            answer = "".join(sorted(set(re.sub(r"[^A-Z]", "", str(question.get("answer") or "").upper()))))
            if answer != str(question.get("answer") or "").strip().upper() or not answer:
                die(label + "的 answer 必须是已排序且不重复的大写选项字母")
            if any(key not in options for key in answer):
                die(label + "的 answer 引用了不存在的选项")
            if qtype == "single" and len(answer) != 1:
                die(label + "为单选题，answer 必须恰好包含一个选项")
            if qtype == "multiple" and len(answer) < 2:
                die(label + "为多选题，answer 必须至少包含两个选项")
            (single_answers if qtype == "single" else combined_answers).append(answer)
        elif str(question.get("answer") or "").strip() not in {"对", "错"}:
            die(label + "为判断题，answer 只能写“对”或“错”")
    if len(single_answers) >= 4:
        counts = [single_answers.count(letter) for letter in "ABCD"]
        if min(counts) == 0 or max(counts) - min(counts) > 1:
            die("单选题答案位置不平衡：A/B/C/D 必须尽量均匀分布")
    elif len(single_answers) > 1 and len(set(single_answers)) == 1:
        die("单选题答案位置重复集中在同一选项")
    if len(combined_answers) >= 3 and len(set(combined_answers)) < 2:
        die("多选/不定项答案组合过于单一")

def validate_demo_source(source, path):
    if re.search(r"<\\/script\s*>", source, re.I):
        die("演示文件不得手工写 <\\/script>，请正常写 </script>：%s" % path)
    if re.search(r"\b(?:alert|confirm|prompt)\s*\(", source):
        die("演示不得调用 alert()/confirm()/prompt()：%s" % path)
    if re.search(r"document\.cookie|\blocalStorage\b|\bsessionStorage\b|\bparent\s*\.", source):
        die("演示不得访问 Cookie、本地存储或父页面变量：%s" % path)
    if re.search(r"<script\b[^>]*\btype\s*=\s*['\"]?module|\bimport\s*(?:\(|[^;\n]+\bfrom\b)|\bexport\s+(?:default|const|let|var|function|class|\{)", source, re.I):
        die("演示不得使用 ES module/import/export：%s" % path)
    if re.search(r"<script\b[^>]*\bsrc\s*=|<link\b[^>]*\bhref\s*=|\b(?:fetch|XMLHttpRequest|WebSocket|EventSource)\b", source, re.I):
        die("演示必须自包含且不得主动联网：%s" % path)
    interactive = re.search(r"<(?:input|button|select|textarea)\b", source, re.I) or re.search(
        r"(?:addEventListener\s*\(\s*['\"](?:click|input|change|pointer|mouse|touch|key|drag)|on(?:click|input|change|pointer|mouse|touch|key|drag)\s*=)",
        source, re.I)
    if not interactive:
        die("演示缺少可操作控件或交互事件：%s" % path)
    for style in re.findall(r"<style\b[^>]*>([\s\S]*?)</style\s*>", source, re.I):
        for selector, declarations in re.findall(r"([^{}]+)\{([^{}]*)\}", style):
            if re.search(r"(?:\.fill\b|\.bar-fill\b|\.meter-fill\b|progress|progressbar)", selector, re.I) \
                    and re.search(r"\b(?:transition|animation)(?:-[\w-]+)?\s*:", declarations, re.I):
                die("进度指示元素不得使用 transition/animation 补间：%s" % path)

def safe_source_path(in_dir, value):
    value = str(value or "").strip()
    if not value:
        die("章节缺少 file 字段")
    if os.path.isabs(value):
        die("章节 file 不能使用输入目录之外的绝对路径：%s" % value)
    real_input = os.path.realpath(in_dir)
    candidate = os.path.abspath(os.path.join(in_dir, value))
    real_candidate = os.path.realpath(candidate)
    try:
        inside = os.path.commonpath([real_input, real_candidate]) == real_input
    except ValueError:
        inside = False
    if not inside:
        die("章节 file 不能越出输入目录：%s" % value)
    return candidate

def safe_chapter_name(index, item, source_path, used):
    raw = os.path.basename(str(item.get("file") or "")) or os.path.basename(source_path)
    stem, ext = os.path.splitext(raw)
    stem = re.sub(r"[^0-9A-Za-z\u3400-\u9fff._-]+", "_", stem).strip("._") or ("chapter-%02d" % (index + 1))
    if not ext or ext.lower() != ".md":
        ext = ".md"
    name = stem + ext.lower()
    if name in used:
        name = "%s-%02d%s" % (stem, index + 1, ext.lower())
    while name in used:
        name = "%s-%d%s" % (stem, len(used) + 1, ext.lower())
    used.add(name)
    return name

def _image_reference_path(value):
    raw = str(value or "").strip().strip("<>")
    if not raw or re.match(r"^(?:https?:|data:|blob:|javascript:|#)", raw, re.I):
        return ""
    if raw.lower().startswith("file://"):
        parsed = urllib.parse.urlsplit(raw)
        raw = urllib.parse.unquote(parsed.path or "")
        if re.match(r"^/[A-Za-z]:/", raw):
            raw = raw[1:]
    else:
        raw = urllib.parse.unquote(raw)
    raw = raw.split("#", 1)[0].split("?", 1)[0].strip()
    return raw

def _find_image(in_dir, source_path, reference):
    raw = _image_reference_path(reference)
    if not raw:
        return None
    candidates = []
    if os.path.isabs(raw):
        candidates.append(os.path.abspath(raw))
    else:
        candidates.append(os.path.abspath(os.path.join(os.path.dirname(source_path), raw)))
        candidates.append(os.path.abspath(os.path.join(in_dir, raw)))
    for candidate in candidates:
        if os.path.isfile(candidate) and os.path.splitext(candidate)[1].lower() in IMAGE_EXTENSIONS:
            return candidate
    return None

def materialize_chapter_images(text, in_dir, source_path, output_dir, link_prefix, registry, missing):
    """把教材正文中实际引用的本地图片复制到学习包，并返回可直接渲染的正文。"""
    image_dir = os.path.join(output_dir, "assets", "textbook-images")
    counter = [len(registry) + 1]

    def replacement(reference):
        direct = str(reference or "").strip().strip("<>")
        if re.match(r"^(?:https?:|blob:|javascript:)", direct, re.I):
            missing.add(direct)
            return reference
        source = _find_image(in_dir, source_path, reference)
        if not source:
            raw = _image_reference_path(reference)
            if raw and not re.match(r"^(?:https?:|data:|blob:)", str(reference or "").strip(), re.I):
                missing.add(str(reference).strip())
            return reference
        key = os.path.normcase(os.path.realpath(source))
        if key not in registry:
            ext = os.path.splitext(source)[1].lower()
            stem = os.path.splitext(os.path.basename(source))[0]
            stem = re.sub(r"[^0-9A-Za-z\u3400-\u9fff._-]+", "_", stem).strip("._") or "image"
            name = "%03d_%s%s" % (counter[0], stem, ext)
            counter[0] += 1
            target = os.path.join(image_dir, name)
            os.makedirs(image_dir, exist_ok=True)
            shutil.copyfile(source, target)
            registry[key] = "assets/textbook-images/" + name
        return link_prefix + registry[key]

    md_pattern = re.compile(r"(!\[[^\]]*\]\(\s*)(<[^>\r\n]+>|[^)>\r\n]+?)(\s*\))", re.I)
    text = md_pattern.sub(lambda match: match.group(1) + replacement(match.group(2)) + match.group(3), text)
    html_pattern = re.compile(r"(<img\b[^>]*\bsrc\s*=\s*)([\"'])([^\"']+)(\2)", re.I)
    return html_pattern.sub(lambda match: match.group(1) + match.group(2) + replacement(match.group(3)) + match.group(4), text)


def materialize_python_exercise_files(questions, in_dir, output_dir):
    source_root = os.path.realpath(os.path.join(in_dir, "python-files"))
    target_root = os.path.join(output_dir, "assets", "python-exercises")
    total_bytes, used_names = 0, set()
    for question_index, question in enumerate(questions):
        if question.get("type") != "code":
            continue
        requested = question.get("exerciseFiles")
        if requested is None:
            question["exerciseFiles"] = []
            continue
        if not isinstance(requested, list) or len(requested) > 10:
            die("questions.json 第 %d 题的 exerciseFiles 必须是最多 10 项的相对路径数组" % (question_index + 1))
        packed = []
        for file_index, item in enumerate(requested):
            raw = str(item.get("path") if isinstance(item, dict) else item or "").strip().replace("\\", "/")
            if not raw or raw.startswith("/") or re.match(r"^[A-Za-z]:", raw) or ".." in raw.split("/"):
                die("questions.json 第 %d 题的教材附件路径无效：%s" % (question_index + 1, raw))
            relative = raw[len("python-files/"):] if raw.startswith("python-files/") else raw
            source = os.path.realpath(os.path.join(source_root, relative.replace("/", os.sep)))
            try:
                inside = os.path.commonpath([source_root, source]) == source_root
            except ValueError:
                inside = False
            extension = os.path.splitext(source)[1].lower()
            if not inside or not os.path.isfile(source) or extension not in PYTHON_EXERCISE_EXTENSIONS:
                die("questions.json 第 %d 题的教材附件不存在、越界或类型不受支持：%s" % (question_index + 1, raw))
            size = os.path.getsize(source)
            total_bytes += size
            if total_bytes > MAX_PYTHON_EXERCISE_BYTES:
                die("全部 Python 教材附件合计不能超过 16MB")
            base = re.sub(r"[^0-9A-Za-z._\-\u3400-\u9fff]+", "_", os.path.basename(source))[:80] or ("file-%d" % (file_index + 1))
            candidate = "%03d_%s" % (len(used_names) + 1, base)
            while candidate.lower() in used_names:
                candidate = "%03d_%s" % (len(used_names) + 2, base)
            used_names.add(candidate.lower())
            os.makedirs(target_root, exist_ok=True)
            target = os.path.join(target_root, candidate)
            shutil.copyfile(source, target)
            packed.append({"name": os.path.basename(source), "path": "assets/python-exercises/" + candidate, "bytes": size})
        question["exerciseFiles"] = packed

def main():
    if len(sys.argv) < 3:
        die("用法：python scripts/inject.py <input_dir> <输出.html> [template.html]")
    in_dir, out_path = sys.argv[1], sys.argv[2]
    tpl_path = sys.argv[3] if len(sys.argv) > 3 else \
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "template.html")

    if not os.path.isdir(in_dir):
        die("输入路径不是目录：%s" % in_dir)

    in_dir = os.path.abspath(in_dir)
    demos_dir = os.path.join(in_dir, "demos")

    # ① 读取源文件
    meta = read_json(os.path.join(in_dir, "meta.json"))
    kpData = read_json(os.path.join(in_dir, "kp.json"))
    questions = read_json(os.path.join(in_dir, "questions.json"))

    # 基本字段校验
    if not isinstance(meta, dict):
        die("meta.json 必须是对象 {book, chapter, summary}")
    if not isinstance(kpData, list):
        die("kp.json 必须是数组 [{cat, items:[{name,desc}]}, ...]")
    if not isinstance(questions, list):
        die("questions.json 必须是数组 [{type, text, ...}, ...]")
    required_text(meta.get("book"), "meta.json 的教材名 book")
    if not kpData:
        die("kp.json 至少要包含一个知识点分类")
    validate_questions(questions)

    # L8.0：教材原文按章节拆成独立 Markdown 文件，同时把每章摘要注入页面，
    # 让悬浮章节切换器和 Codex 都能明确选择参考章节。
    chapter_sources = []
    declared_chapters = meta.get("chapters")
    if declared_chapters is not None:
        if not isinstance(declared_chapters, list) or not declared_chapters:
            die("meta.json 的 chapters 必须是非空数组")
        used_names, used_ids = set(), set()
        for index, item in enumerate(declared_chapters):
            if not isinstance(item, dict):
                die("meta.json chapters 第 %d 项必须是对象" % index)
            title = str(item.get("title") or item.get("chapter") or item.get("name") or "").strip()
            if not title:
                die("meta.json chapters 第 %d 项缺少 title/chapter" % index)
            summary = str(item.get("summary") or meta.get("summary") or "").strip()
            if not summary:
                die("meta.json chapters 第 %d 项缺少 summary" % index)
            source_path = safe_source_path(in_dir, item.get("file") or item.get("path"))
            text = read_text(source_path)
            if not text.strip():
                die("章节 Markdown 不能为空：%s" % source_path)
            chapter_id = str(item.get("id") or "chapter-%02d" % (index + 1)).strip()
            if not chapter_id or chapter_id in used_ids:
                die("meta.json chapters 第 %d 项的 id 为空或重复：%s" % (index, chapter_id))
            used_ids.add(chapter_id)
            output_name = safe_chapter_name(index, item, source_path, used_names)
            chapter_sources.append({
                "id": chapter_id,
                "aliases": item.get("aliases"),
                "version": item.get("version"),
                "title": title,
                "chapter": title,
                "summary": summary,
                "source_path": source_path,
                "output_rel": "chapters/" + output_name,
                "fulltext": text,
            })
    else:
        source_path = os.path.join(in_dir, "fulltext.md")
        text = read_text(source_path)
        if not text.strip():
            die("fulltext.md 不能为空")
        title = required_text(meta.get("chapter"), "meta.json 的章节名 chapter")
        chapter_sources.append({
            "id": str(meta.get("chapterId") or "chapter-01"),
            "aliases": meta.get("chapterAliases"),
            "version": meta.get("chapterVersion"),
            "title": title,
            "chapter": title,
            "summary": str(meta.get("summary") or "").strip(),
            "source_path": source_path,
            "output_rel": "chapters/chapter-01.md",
            "fulltext": text,
        })

    if not chapter_sources[0]["summary"]:
        die("教材必须提供章节摘要：meta.json summary 或 chapters[*].summary")
    active_index = meta.get("activeChapterIndex", 0)
    try:
        active_index = int(active_index)
    except Exception:
        active_index = 0
    active_index = max(0, min(len(chapter_sources) - 1, active_index))
    active = chapter_sources[active_index]

    # L8.0 图片修复：页面由独立启动器通过 /page 提供，不能依赖浏览器把原输入目录当作当前目录。
    # 统一把章节正文实际引用的本地图片复制进学习包，并分别生成页面路径和章节文件路径。
    output_dir = os.path.dirname(os.path.abspath(out_path)) or os.getcwd()
    os.makedirs(output_dir, exist_ok=True)
    image_registry, missing_images = {}, set()
    for item in chapter_sources:
        item["page_fulltext"] = materialize_chapter_images(item["fulltext"], in_dir, item["source_path"], output_dir, "", image_registry, missing_images)
        item["file_fulltext"] = materialize_chapter_images(item["fulltext"], in_dir, item["source_path"], output_dir, "../", image_registry, missing_images)
    if missing_images:
        die("教材正文含不存在或无法离线打包的图片：" + "、".join(sorted(missing_images)))
    materialize_python_exercise_files(questions, in_dir, output_dir)

    # ② 强制演示校验 + 组装 demo
    for ci, cat in enumerate(kpData):
        if not isinstance(cat, dict) or not str(cat.get("cat") or "").strip():
            die("kp.json 第 %d 个分类缺少 cat 字段" % ci)
        items = cat.get("items") or []
        if not isinstance(items, list) or not items:
            die("kp.json 第 %d 个分类的 items 必须是非空数组" % ci)
        for ii, it in enumerate(items):
            if not isinstance(it, dict) or not str(it.get("name") or "").strip():
                die("kp.json 第 %d 个分类的第 %d 个知识点缺少 name 字段" % (ci, ii))
            required_text(it.get("desc"), "kp.json 第 %d 个分类的第 %d 个知识点 desc" % (ci, ii))
            demo_path = os.path.join(demos_dir, "%d_%d.html" % (ci, ii))
            if not os.path.isfile(demo_path):
                die(
                    "演示缺失：kp.json 第 %d 个分类「%s」的第 %d 个知识点「%s」没有对应的演示文件 %s\n"
                    "L6.3 起演示是强制性的——每个知识点都必须有 demos/%d_%d.html。"
                    % (ci, cat.get("cat", ""), ii, it.get("name", ""), demo_path, ci, ii)
                )
            demo_html = read_text(demo_path)
            if not demo_html.strip():
                die("演示文件为空：%s（知识点「%s」必须有可运行的演示）" % (demo_path, it.get("name", "")))
            validate_demo_source(demo_html, demo_path)
            # ③ 自动转义 </script> —— AI 写演示时用正常 </script>，这里统一转义
            demo_html = re.sub(r"</script\s*>", "<\\/script>", demo_html, flags=re.I)
            it["demo"] = demo_html

    try:
        model_v2 = upgrade_and_validate(meta, kpData, questions, chapters=chapter_sources, python_mode=True)
    except LearningModelError as exc:
        die("数据模型 v2 / 题目质量门禁未通过：%s" % exc)

    # ④ 组装完整 data
    data = {
        **model_v2,
        "book": meta.get("book", ""),
        "chapter": active["chapter"],
        "summary": active["summary"],
        "fulltext": active["page_fulltext"],
        "activeChapterIndex": active_index,
        "chapters": [
            {
                "id": item["id"],
                "aliases": item["aliases"],
                "version": item["version"],
                "title": item["title"],
                "chapter": item["chapter"],
                "summary": item["summary"],
                "file": item["output_rel"],
                "fulltext": item["page_fulltext"],
            }
            for item in chapter_sources
        ],
        "kpData": kpData,
        "questions": questions,
    }

    # ⑤ learning-data 采用 Base64 传输。这样教材原文可以原样保留，
    #    demo 也可以包含正常的 HTML script 标签，不会提前关闭外层 script。
    pretty = json.dumps(data, ensure_ascii=False, indent=2)
    encoded = base64.b64encode(pretty.encode("utf-8")).decode("ascii")
    # 固定换行宽度，便于诊断，也避免一行过长影响浏览器调试器和复制。
    encoded_block = "\n".join(encoded[i:i + 120] for i in range(0, len(encoded), 120))

    # ⑥ 注入 learning-data 块
    with open(tpl_path, "r", encoding="utf-8") as f:
        tpl = f.read()
    pat = re.compile(
        r'(<script[^>]*id="learning-data"[^>]*>)(.*?)(</script>)',
        re.DOTALL,
    )
    if not pat.search(tpl):
        die('模板里找不到 id="learning-data" 的 script 块')
    match = pat.search(tpl)
    opening = match.group(1)
    if not re.search(r'\bdata-encoding\s*=\s*["\']base64["\']', opening, re.IGNORECASE):
        die('最新模板的 learning-data script 缺少 data-encoding="base64"，已停止注入')
    new_html = pat.sub(lambda m: m.group(1) + "\n" + encoded_block + "\n" + m.group(3), tpl, count=1)

    # ⑦ 写出学习页与章节文件。章节文件位于学习页目录内，启动器的工作区
    # 根就是该目录，Codex 可以按上下文给出的相对路径直接读取。
    chapters_output_dir = os.path.join(output_dir, "chapters")
    os.makedirs(chapters_output_dir, exist_ok=True)
    for item in chapter_sources:
        target = os.path.join(output_dir, item["output_rel"].replace("/", os.sep))
        with open(target, "w", encoding="utf-8") as chapter_file:
            chapter_file.write(item["file_fulltext"])
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(new_html)

    # ⑧ 写出独立运行入口。浏览器不读取账号文件，只连接本机回环桥；桥再通过
    #    Codex App Server 复用 Codex 已保存的 ChatGPT 登录状态。
    runtime_dir = os.path.join(output_dir, ".l7-codex-runtime")
    os.makedirs(runtime_dir, exist_ok=True)
    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    for runtime_name in ("launch.js", "codex-client.js", "codex-bridge.js", "start.vbs", "status-url.js"):
        source = os.path.join(scripts_dir, runtime_name)
        if not os.path.isfile(source):
            die("技能运行时缺少文件：%s" % source)
        shutil.copy2(source, os.path.join(runtime_dir, runtime_name))
    vendor_source = os.path.join(os.path.dirname(scripts_dir), "assets", "vendor")
    vendor_target = os.path.join(runtime_dir, "vendor")
    if not os.path.isdir(vendor_source):
        die("技能运行时缺少本地渲染依赖：%s" % vendor_source)
    if os.path.isdir(vendor_target):
        shutil.rmtree(vendor_target)
    shutil.copytree(vendor_source, vendor_target)

    output_name = os.path.basename(os.path.abspath(out_path))
    command_name = "启动_%s.cmd" % os.path.splitext(output_name)[0]
    command_path = os.path.join(output_dir, command_name)
    command = (
        "@echo off\r\n"
        "chcp 65001 >nul\r\n"
        "setlocal EnableExtensions\r\n"
        "where node.exe >nul 2>nul\r\n"
        "if errorlevel 1 (\r\n"
        "  echo 启动失败：未找到 Node.js。请先在 Codex 中让助手安装或配置本地启动环境。\r\n"
        "  pause\r\n"
        "  exit /b 1\r\n"
        ")\r\n"
        "set \"L7_RUNTIME=%%~dp0.l7-codex-runtime\"\r\n"
        "del /q \"%%L7_RUNTIME%%\\launch.status.json\" \"%%L7_RUNTIME%%\\launch.status.json.error.log\" >nul 2>nul\r\n"
        "wscript.exe //B //NoLogo \"%%L7_RUNTIME%%\\start.vbs\" \"node.exe\" \"%%L7_RUNTIME%%\\launch.js\" \"%%~dp0%s\" \"--status-file=%%L7_RUNTIME%%\\launch.status.json\" \"--no-open\"\r\n"
        "if errorlevel 1 goto launch_failed\r\n"
        "for /L %%%%I in (1,1,20) do (\r\n"
        "  if exist \"%%L7_RUNTIME%%\\launch.status.json\" goto launch_ready\r\n"
        "  if exist \"%%L7_RUNTIME%%\\launch.status.json.error.log\" goto launch_failed\r\n"
        "  ping 127.0.0.1 -n 2 >nul\r\n"
        ")\r\n"
        "echo 启动失败：本地服务在 20 秒内没有就绪。\r\n"
        ":launch_failed\r\n"
        "if exist \"%%L7_RUNTIME%%\\launch.status.json.error.log\" type \"%%L7_RUNTIME%%\\launch.status.json.error.log\"\r\n"
        "pause\r\n"
        "exit /b 1\r\n"
        ":launch_ready\r\n"
        "set \"L7_PAGE_URL=\"\r\n"
        "for /f \"usebackq delims=\" %%%%U in (`node.exe \"%%L7_RUNTIME%%\\status-url.js\" \"%%L7_RUNTIME%%\\launch.status.json\"`) do set \"L7_PAGE_URL=%%%%U\"\r\n"
        "if not defined L7_PAGE_URL goto open_failed\r\n"
        "start \"\" \"%%L7_PAGE_URL%%\"\r\n"
        "if errorlevel 1 goto open_failed\r\n"
        "endlocal\r\n"
        "exit /b 0\r\n"
        ":open_failed\r\n"
        "echo 本地服务已启动，但未能自动打开默认浏览器。\r\n"
        "echo 请查看：%%L7_RUNTIME%%\\launch.status.json\r\n"
        "pause\r\n"
        "endlocal\r\n"
        "exit /b 1\r\n"
    ) % output_name
    # 首两行只有 ASCII：先关闭命令回显并切换到 UTF-8，再解析后续中文。
    # 不写 BOM，避免部分 cmd.exe 把 BOM 当成首条命令的一部分，导致 @echo off 失效。
    with open(command_path, "w", encoding="utf-8", newline="") as f:
        f.write(command)

    # 统计
    n_kp = sum(len(c.get("items") or []) for c in kpData)
    print("✅ 已生成：%s（章节 %d 个 / 知识点 %d 个 / 演示 %d 个 / 题目 %d 道）"
          % (out_path, len(chapter_sources), n_kp, n_kp, len(questions)))
    print("✅ AI 启动入口：%s" % command_path)

if __name__ == "__main__":
    main()
