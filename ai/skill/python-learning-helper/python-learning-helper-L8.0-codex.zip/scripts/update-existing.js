#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');

const DATA_BLOCK = /<script[^>]*id="learning-data"[^>]*>[\s\S]*?<\/script>/i;

function copyRuntime(skillRoot, outputDir) {
  const runtime = path.join(outputDir, '.l7-codex-runtime');
  fs.mkdirSync(runtime, { recursive: true });
  const scripts = path.join(skillRoot, 'scripts');
  for (const name of ['launch.js', 'codex-client.js', 'codex-bridge.js', 'start.vbs', 'status-url.js']) {
    const source = path.join(scripts, name);
    if (!fs.existsSync(source)) throw new Error('技能运行时缺少文件：' + source);
    fs.copyFileSync(source, path.join(runtime, name));
  }
  const vendorSource = path.join(skillRoot, 'assets', 'vendor');
  const vendorTarget = path.join(runtime, 'vendor');
  fs.rmSync(vendorTarget, { recursive: true, force: true });
  fs.cpSync(vendorSource, vendorTarget, { recursive: true });
}

function materializeChapters(dataBlock, outputDir) {
  const match = dataBlock.match(/<script[^>]*id="learning-data"[^>]*>([\s\S]*?)<\/script>/i);
  if (!match) return;
  let raw = match[1].trim();
  const tag = match[0].slice(0, match[0].indexOf('>') + 1);
  if (/data-encoding\s*=\s*["']base64["']/i.test(tag)) raw = Buffer.from(raw.replace(/\s+/g, ''), 'base64').toString('utf8');
  let data;
  try { data = JSON.parse(raw); } catch (_) { return; }
  const chapters = Array.isArray(data.chapters) && data.chapters.length ? data.chapters : [{ file: 'chapters/chapter-01.md', fulltext: data.fulltext || '' }];
  const root = path.resolve(outputDir);
  for (const chapter of chapters) {
    const relative = String(chapter.file || '').replaceAll('/', path.sep);
    const target = path.resolve(root, relative);
    if (target !== root && !target.startsWith(root + path.sep)) throw new Error('章节文件路径越出学习包目录：' + relative);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, String(chapter.fulltext || ''), 'utf8');
  }
}

function updateExisting(htmlPath, templatePath) {
  const target = path.resolve(htmlPath);
  const skillRoot = path.resolve(__dirname, '..');
  const template = path.resolve(templatePath || path.join(skillRoot, 'assets', 'template.html'));
  if (!fs.existsSync(target) || path.extname(target).toLowerCase() !== '.html') throw new Error('找不到现有 L8.0-codex 学习页：' + target);
  if (!fs.existsSync(template)) throw new Error('找不到最新模板：' + template);
  const oldHtml = fs.readFileSync(target, 'utf8');
  const data = oldHtml.match(DATA_BLOCK);
  if (!data) throw new Error('现有学习页缺少 learning-data 数据块，已停止更新');
  const latest = fs.readFileSync(template, 'utf8');
  if (!DATA_BLOCK.test(latest)) throw new Error('最新模板缺少 learning-data 数据块，已停止更新');
  // 数据中常含 LaTeX 的 `$` 和交互演示脚本的 `$'`。直接把字符串作为
  // replace 的第二个参数会触发 JavaScript 的替换模式语法，必须用函数
  // 返回原文，才能做到逐字节保留 learning-data。
  const next = latest.replace(DATA_BLOCK, () => data[0]);
  if (!next.includes('data-tz-codex-skill="L8.0-codex"')) throw new Error('最新模板不是 L8.0-codex，已停止更新');
  const temporary = target + '.l7-update-' + process.pid + '.tmp';
  const backup = target + '.l7-update-' + process.pid + '.bak';
  fs.writeFileSync(temporary, next, 'utf8');
  fs.renameSync(target, backup);
  try {
    fs.renameSync(temporary, target);
    copyRuntime(skillRoot, path.dirname(target));
    materializeChapters(data[0], path.dirname(target));
    fs.rmSync(backup, { force: true });
  } catch (error) {
    try { fs.rmSync(target, { force: true }); } catch (_) {}
    try { fs.renameSync(backup, target); } catch (_) {}
    throw error;
  } finally {
    try { fs.rmSync(temporary, { force: true }); } catch (_) {}
  }
  return { path: target, bytes: Buffer.byteLength(next, 'utf8') };
}

if (require.main === module) {
  const file = process.argv[2];
  if (!file) {
    process.stderr.write('用法：node update-existing.js <现有L8.0-codex学习页.html> [最新template.html]\n');
    process.exitCode = 1;
  } else {
    try {
      const result = updateExisting(file, process.argv[3]);
      process.stdout.write('✅ 已更新现有学习页并保留教材数据：' + result.path + '（' + result.bytes + ' 字节）\n');
    } catch (error) {
      process.stderr.write('更新失败：' + String(error && error.message || error) + '\n');
      process.exitCode = 1;
    }
  }
}

module.exports = { DATA_BLOCK, copyRuntime, updateExisting };
