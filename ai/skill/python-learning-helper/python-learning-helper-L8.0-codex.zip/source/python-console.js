import { Terminal } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';

(function installPythonConsole(global) {
  'use strict';

  let terminal = null;
  let fitAddon = null;
  let inputBuffer = '';
  let handlers = {};
  let resizeObserver = null;

  function normalizeOutput(value) {
    return String(value == null ? '' : value).replace(/\r?\n/g, '\r\n');
  }

  function setHandlers(next) {
    handlers = next && typeof next === 'object' ? next : {};
  }

  function write(value, stream) {
    if (!terminal || value == null || value === '') return;
    const text = normalizeOutput(value);
    terminal.write(stream === 'stderr' ? '\x1b[31m' + text + '\x1b[0m' : text);
  }

  function writeln(value, stream) {
    write(String(value == null ? '' : value) + '\n', stream);
  }

  function fit() {
    if (!fitAddon) return;
    try { fitAddon.fit(); } catch (_) {}
  }

  function consumeInput(data) {
    if (!terminal) return;
    if (data === '\r' || data === '\n') {
      terminal.write('\r\n');
      const value = inputBuffer;
      inputBuffer = '';
      if (typeof handlers.onInput === 'function') handlers.onInput(value);
      return;
    }
    if (data === '\x03') {
      terminal.write('^C\r\n');
      inputBuffer = '';
      if (typeof handlers.onInterrupt === 'function') handlers.onInterrupt();
      return;
    }
    if (data === '\x04') {
      terminal.write('^D\r\n');
      inputBuffer = '';
      if (typeof handlers.onEof === 'function') handlers.onEof();
      return;
    }
    if (data === '\x7f' || data === '\b') {
      const chars = Array.from(inputBuffer);
      if (chars.length) {
        chars.pop();
        inputBuffer = chars.join('');
        terminal.write('\b \b');
      }
      return;
    }
    if (/^\x1b/.test(data) || /[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(data)) return;
    inputBuffer += data;
    terminal.write(data);
  }

  function mount(container, options) {
    if (!container) throw new Error('缺少 Python 控制台容器');
    if (terminal) return api;
    terminal = new Terminal({
      convertEol: true,
      cursorBlink: true,
      cursorStyle: 'bar',
      fontFamily: '"Cascadia Mono", "Microsoft YaHei UI", Consolas, monospace',
      fontSize: 13,
      lineHeight: 1.25,
      scrollback: 5000,
      scrollOnUserInput: true,
      allowProposedApi: false,
      theme: {
        background: '#101914',
        foreground: '#dcefe5',
        cursor: '#7ee2b8',
        selectionBackground: '#2d6a52aa',
        black: '#101914',
        red: '#ff8a80',
        green: '#7ee2b8',
        yellow: '#ffd180',
        blue: '#82b1ff',
        magenta: '#c5a3ff',
        cyan: '#80deea',
        white: '#eefaf3'
      }
    });
    fitAddon = new FitAddon();
    terminal.loadAddon(fitAddon);
    terminal.open(container);
    terminal.onData(consumeInput);
    container.addEventListener('pointerdown', () => terminal && terminal.focus());
    setHandlers(options);
    if (typeof ResizeObserver === 'function') {
      resizeObserver = new ResizeObserver(fit);
      resizeObserver.observe(container);
    }
    requestAnimationFrame(fit);
    writeln('Python 控制台已就绪。运行代码后，可直接在这里输入并按 Enter；向上滚动可查看运行历史。');
    return api;
  }

  function begin(title) {
    if (!terminal) return;
    inputBuffer = '';
    writeln('\n▶ ' + String(title || '运行 Python') + ' · ' + new Date().toLocaleString('zh-CN', { hour12: false }), 'status');
    terminal.focus();
  }

  function finish(result) {
    if (!terminal) return;
    const status = result && result.status || 'error';
    const label = status === 'success' ? '运行完成' : status === 'timeout' ? '运行超时' : status === 'stopped' ? '运行已停止' : '运行结束（有错误）';
    const detail = result && result.exitCode != null ? '，退出码 ' + result.exitCode : '';
    writeln('\n' + (status === 'success' ? '✓ ' : '■ ') + label + detail, status === 'success' ? 'stdout' : 'stderr');
  }

  function clear() {
    if (terminal) {
      terminal.clear();
      terminal.write('\x1b[2J\x1b[H');
    }
    inputBuffer = '';
  }

  function writeTrace(trace) {
    if (!terminal || !Array.isArray(trace) || !trace.length) return;
    writeln('\n🔎 逐行执行与变量变化（' + trace.length + ' 步）', 'status');
    trace.forEach((row, index) => {
      row = row || {};
      const changes = row.changes && Object.keys(row.changes).length
        ? '｜变量 ' + Object.keys(row.changes).map((name) => name + '=' + row.changes[name]).join('，')
        : '';
      const removed = Array.isArray(row.removed) && row.removed.length ? '｜移除 ' + row.removed.join('、') : '';
      const error = row.exception ? '｜异常 ' + row.exception.type + ': ' + row.exception.message : '';
      writeln(String(index + 1).padStart(3, '0') + '｜第 ' + String(row.line || '?') + ' 行｜' + String(row.event || 'line') + '｜' + String(row.function || '<module>') + changes + removed + error, error ? 'stderr' : 'status');
    });
  }

  function restoreHistory(records) {
    if (!terminal) return;
    clear();
    const list = Array.isArray(records) ? records.slice().reverse() : [];
    if (!list.length) {
      writeln('Python 控制台已就绪。尚无运行历史；运行代码后可直接输入并按 Enter。');
      return;
    }
    writeln('已恢复 ' + list.length + ' 次运行历史（旧记录在上，新记录在下）。');
    list.forEach((item) => {
      item = item || {};
      const source = String(item.source || 'Python 实验台');
      const at = item.at || item.time;
      let time = '';
      try { time = at ? new Date(at).toLocaleString('zh-CN', { hour12: false }) : ''; } catch (_) {}
      writeln('\n▶ [历史] ' + source + (time ? ' · ' + time : ''), 'status');
      if (item.code) {
        writeln('\x1b[36m# 运行时代码\x1b[0m');
        writeln(String(item.code));
      }
      if (item.stdout) write(String(item.stdout), 'stdout');
      if (item.stderr) write(String(item.stderr), 'stderr');
      writeTrace(item.trace);
      finish(item);
    });
    writeln('\n— 已恢复全部保存的运行历史；继续运行会追加在下方 —', 'status');
  }

  function focus() {
    if (terminal) terminal.focus();
  }

  function dispose() {
    if (resizeObserver) resizeObserver.disconnect();
    resizeObserver = null;
    if (terminal) terminal.dispose();
    terminal = null;
    fitAddon = null;
    handlers = {};
    inputBuffer = '';
  }

  const api = { mount, setHandlers, write, writeln, begin, finish, clear, writeTrace, restoreHistory, fit, focus, dispose };
  global.L8PythonConsole = api;
})(window);
